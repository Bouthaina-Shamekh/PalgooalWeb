-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 14, 2025 at 11:10 PM
-- Server version: 8.4.3
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `palgoalsnewtest`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` bigint UNSIGNED NOT NULL,
  `actor_type` enum('admin','client','system') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'system',
  `actor_id` bigint UNSIGNED DEFAULT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('laravel_cache_17ba0791499db908433b80f37c5fbc89b870084b', 'i:2;', 1760483238),
('laravel_cache_17ba0791499db908433b80f37c5fbc89b870084b:timer', 'i:1760483238;', 1760483238),
('laravel_cache_c525a5357e97fef8d3db25841c86da1a', 'i:1;', 1759781425),
('laravel_cache_c525a5357e97fef8d3db25841c86da1a:timer', 'i:1759781425;', 1759781425),
('laravel_cache_dp:balance:2', 'a:8:{s:2:\"ok\";b:1;s:6:\"reason\";s:2:\"ok\";s:7:\"message\";s:36:\"تم جلب الرصيد بنجاح.\";s:8:\"currency\";s:3:\"USD\";s:7:\"balance\";d:9000;s:11:\"duration_ms\";i:650;s:10:\"fetched_at\";s:25:\"2025-10-14T22:56:36+00:00\";s:5:\"cache\";s:3:\"hit\";}', 1760482656),
('laravel_cache_latest_blog_posts', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:5:{i:0;a:7:{s:5:\"title\";s:78:\"إعادة توجيه عناوين URL في ووردبريس| URL redirection\";s:3:\"url\";s:211:\"https://www.palgoals.com/blog/%D8%A5%D8%B9%D8%A7%D8%AF%D8%A9-%D8%AA%D9%88%D8%AC%D9%8A%D9%87-%D8%B9%D9%86%D8%A7%D9%88%D9%8A%D9%86-url-%D9%81%D9%8A-%D9%88%D9%88%D8%B1%D8%AF%D8%A8%D8%B1%D9%8A%D8%B3-url-redirection/\";s:11:\"description\";s:610:\"\nإعادة توجيه عناوين URL في ووردبريس تضمن توجيه الزوار من الروابط القديمة إلى الجديدة، مما يحسن تجربة المستخدم ويحافظ على ترتيب موقعك في محركات البحث. استخدام إعادة التوجيه 301 يمنع ظهور أخطاء 404 ويوجه الزوار تلقائيًا إلى المحتوى الصحيح، مما يعزز أداء موقعك.\nظهرت المقالة إعادة توجيه عناوين URL في ووردبريس| URL redirection أولاً على مدونة بال قول .\";s:4:\"date\";s:10:\"2023-03-09\";s:6:\"author\";s:7:\"support\";s:5:\"image\";s:176:\"https://www.palgoals.com/blog/wp-content/uploads/2023/03/%D8%A5%D8%B9%D8%A7%D8%AF%D8%A9-%D8%AA%D9%88%D8%AC%D9%8A%D9%87-%D8%B9%D9%86%D8%A7%D9%88%D9%8A%D9%86-URL-%D9%81%D9%8A.png\";s:10:\"categories\";a:5:{i:0;s:25:\"تصميم المواقع\";i:1;s:15:\"URL redirection\";i:2;s:9:\"WordPress\";i:3;s:25:\"إعادة توجيه 301\";i:4;s:38:\"إعادة توجيه عناوين URL\";}}i:1;a:7:{s:5:\"title\";s:57:\"ما الفرق بين WordPress.com و WordPress.org؟ \";s:3:\"url\";s:71:\"https://www.palgoals.com/blog/wordpress-com-%D9%88-wordpress-org%D8%9F/\";s:11:\"description\";s:321:\"\nهل تفكر في إنشاء موقعك الأول باستخدام نظام الووردبريس ( WordPress )، ولكنك لا تعرف الفرق بين wordpress.com و wordpress.org ؟ \nظهرت المقالة ما الفرق بين WordPress.com و WordPress.org؟  أولاً على مدونة بال قول .\";s:4:\"date\";s:10:\"2023-02-23\";s:6:\"author\";s:7:\"support\";s:5:\"image\";s:98:\"https://www.palgoals.com/blog/wp-content/uploads/2023/03/%D9%88%D8%B1%D8%AF%D8%A8%D8%B1%D8%B3.webp\";s:10:\"categories\";a:7:{i:0;s:18:\"الاستضافة\";i:1;s:25:\"تصميم المواقع\";i:2;s:9:\"WordPress\";i:3;s:13:\"WordPress.com\";i:4;s:13:\"WordPress.org\";i:5;s:25:\"استضافة مواقع\";i:6;s:29:\"نظام الووردبريس\";}}i:2;a:7:{s:5:\"title\";s:62:\" ما مدى أمان الاستضافة السحابية؟ \";s:3:\"url\";s:159:\"https://www.palgoals.com/blog/%D8%A3%D9%85%D8%A7%D9%86-%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D8%B6%D8%A7%D9%81%D8%A9-%D8%A7%D9%84%D8%B3%D8%AD%D8%A7%D8%A8%D9%8A%D8%A9/\";s:11:\"description\";s:795:\"\nإذا كنت مهتمًا بإنشاء موقع WordPress، فبالتأكيد ستحتاج إلى استضافة مواقع. وعندما يتعلق الأمر بالأنواع المختلفة لاستضافة المواقع، فإن الاستضافة السحابية هي واحدة من أسرع تقنيات الاستضافة نموًا لأنها تقدم بعض المزايا الفريدة على الأنواع الأخرى.  ولكن إذا كنت ستعتمد على “السحابة” لاستضافتك، فقد تتساءل بطبيعة الحال عن أمان الاستضافة السحابية. هل من الآمن استضافة […]\nظهرت المقالة  ما مدى أمان الاستضافة السحابية؟  أولاً على مدونة بال قول .\";s:4:\"date\";s:10:\"2023-02-16\";s:6:\"author\";s:7:\"support\";s:5:\"image\";s:118:\"https://www.palgoals.com/blog/wp-content/uploads/2023/02/%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D8%B6%D8%A7%D9%81%D8%A9-1.webp\";s:10:\"categories\";a:5:{i:0;s:18:\"الاستضافة\";i:1;s:13:\"cloud hosting\";i:2;s:44:\"أمان الاستضافة السحابية\";i:3;s:29:\"استضافة المواقع\";i:4;s:35:\"الاستضافة السحابية\";}}i:3;a:7:{s:5:\"title\";s:84:\" التسويق عبر المؤثرين والمشاهير (Influencer Marketing) \";s:3:\"url\";s:217:\"https://www.palgoals.com/blog/%D8%A7%D9%84%D8%AA%D8%B3%D9%88%D9%8A%D9%82-%D8%B9%D8%A8%D8%B1-%D8%A7%D9%84%D9%85%D8%A4%D8%AB%D8%B1%D9%8A%D9%86-%D9%88%D8%A7%D9%84%D9%85%D8%B4%D8%A7%D9%87%D9%8A%D8%B1-influencer-marketing/\";s:11:\"description\";s:712:\"\nما هو التسويق عبر المؤثرين؟ وكيف يختلف عن غيره من أشكال التسويق الالكتروني؟ ولماذا يجب أن يهتم به المسوقون؟ هل قمت من قبل بشراء منتج أو خدمة بناءاً على ترشيح صاحب قناة يوتيوب تتابعه أو مدون على انستقرام؟ إن كنت فعلت… فهذا يعني أنك وقعت تحت تأثير التسويق عبر المؤثرين.   ما هو التسويق عبر المؤثرين (Influencer […]\nظهرت المقالة  التسويق عبر المؤثرين والمشاهير (Influencer Marketing)  أولاً على مدونة بال قول .\";s:4:\"date\";s:10:\"2023-02-11\";s:6:\"author\";s:7:\"support\";s:5:\"image\";s:142:\"https://www.palgoals.com/blog/wp-content/uploads/2023/02/%D8%AA%D8%B3%D9%88%D9%8A%D9%82-3%D8%A7%D9%84%D9%83%D8%AA%D8%B1%D9%88%D9%86%D9%8A.webp\";s:10:\"categories\";a:4:{i:0;s:35:\"التسويق الالكتروني\";i:1;s:20:\"Influencer Marketing\";i:2;s:38:\"التسويق عبر المؤثرين\";i:3;s:38:\"التسويق عبر المشاهير\";}}i:4;a:7:{s:5:\"title\";s:74:\"كيفية انشاء حملة اعلانية ناجحة في 7 خطوات\";s:3:\"url\";s:231:\"https://www.palgoals.com/blog/%D9%83%D9%8A%D9%81%D9%8A%D8%A9-%D8%A7%D9%86%D8%B4%D8%A7%D8%A1-%D8%AD%D9%85%D9%84%D8%A9-%D8%A7%D8%B9%D9%84%D8%A7%D9%86%D9%8A%D8%A9-%D9%86%D8%A7%D8%AC%D8%AD%D8%A9-%D9%81%D9%8A-7-%D8%AE%D8%B7%D9%88%D8%A7/\";s:11:\"description\";s:748:\"\nحملة اعلانية ناجحة، هذا ما تحتاجه إذا كنت من رواد الأعمال أو من أصحاب المشاريع الناشئة ومالكي المتاجر الإلكترونية وتريد إطلاق منتجك بالسوق أو خلق وعي تجاه علامتك التجارية أو منتجك، إنشاء حملة اعلانية ناجحة تساعدك في تحقيق أهداف مبيعاتك او حتى تجاوز تلك الاهداف، كما يمكن أن تحول العملاء المحتملين الى عملاء حقيقيين.  ماذا تعني […]\nظهرت المقالة كيفية انشاء حملة اعلانية ناجحة في 7 خطوات أولاً على مدونة بال قول .\";s:4:\"date\";s:10:\"2023-02-02\";s:6:\"author\";s:7:\"support\";s:5:\"image\";s:142:\"https://www.palgoals.com/blog/wp-content/uploads/2023/02/%D8%AA%D8%B3%D9%88%D9%8A%D9%82-%D8%A7%D9%84%D9%83%D8%AA%D8%B1%D9%88%D9%86%D9%8A2.webp\";s:10:\"categories\";a:5:{i:0;s:35:\"التسويق الالكتروني\";i:1;s:20:\"Advertising Campaign\";i:2;s:25:\"اعلانات ممولة\";i:3;s:31:\"الحملة الإعلانية\";i:4;s:45:\"انشاء حملة اعلانية ناجحة\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', 1760486051),
('laravel_cache_translation.ar.dashboard.Action', 's:6:\"Action\";', 1760476834),
('laravel_cache_translation.ar.dashboard.Actiont', 's:6:\"Action\";', 1760467288),
('laravel_cache_translation.ar.dashboard.Add', 's:3:\"Add\";', 1759781436),
('laravel_cache_translation.ar.dashboard.Add_Languages', 's:13:\"Add Languages\";', 1760467288),
('laravel_cache_translation.ar.dashboard.Add_New_Translation', 's:19:\"Add New Translation\";', 1760128712),
('laravel_cache_translation.ar.dashboard.Add_Page', 's:8:\"Add Page\";', 1760476834),
('laravel_cache_translation.ar.dashboard.Add_Pages', 's:9:\"Add Pages\";', 1759778182),
('laravel_cache_translation.ar.dashboard.Add_Section', 's:11:\"Add Section\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Add_User', 's:8:\"Add User\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Aim_Characters', 's:58:\"Aim for 50-160 characters. Leave empty to reuse the title.\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Aim_for_50_160_characters_Leave_empty_to_reuse_the_title', 's:58:\"Aim for 50-160 characters. Leave empty to reuse the title.\";', 1759778183),
('laravel_cache_translation.ar.dashboard.All_Languages', 's:13:\"All Languages\";', 1760128712),
('laravel_cache_translation.ar.dashboard.All_Menus', 's:9:\"ALL Menus\";', 1759781889),
('laravel_cache_translation.ar.dashboard.All_Pages', 's:9:\"ALL Pages\";', 1760476834),
('laravel_cache_translation.ar.dashboard.All_Services', 's:12:\"ALL Services\";', 1759704547),
('laravel_cache_translation.ar.dashboard.All_templates', 's:13:\"All templates\";', 1760482957),
('laravel_cache_translation.ar.dashboard.All_Types', 's:9:\"All Types\";', 1760128712),
('laravel_cache_translation.ar.dashboard.Appearance', 's:10:\"Appearance\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Cancel', 's:6:\"Cancel\";', 1760128732),
('laravel_cache_translation.ar.dashboard.Cancel_Edit', 's:11:\"Cancel Edit\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Categories', 's:10:\"Categories\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Choose_from_media', 's:17:\"Choose from media\";', 1760123744),
('laravel_cache_translation.ar.dashboard.clients', 's:7:\"clients\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Code', 's:4:\"Code\";', 1760467288),
('laravel_cache_translation.ar.dashboard.confirm_delete', 's:14:\"Confirm Delete\";', 1760128712),
('laravel_cache_translation.ar.dashboard.CRM_management', 's:14:\"CRM management\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Current_Homepage', 's:16:\"Current Homepage\";', 1760476834),
('laravel_cache_translation.ar.dashboard.Dashboard', 's:9:\"Dashboard\";', 1760128712),
('laravel_cache_translation.ar.dashboard.Date', 's:4:\"Date\";', 1760476834),
('laravel_cache_translation.ar.dashboard.delete', 's:6:\"Delete\";', 1760128712),
('laravel_cache_translation.ar.dashboard.domain_providers', 's:16:\"domain providers\";', 1760482957),
('laravel_cache_translation.ar.dashboard.domain-tlds', 's:11:\"domain tlds\";', 1760482957),
('laravel_cache_translation.ar.dashboard.domains', 's:7:\"domains\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Draft', 's:5:\"Draft\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Edit_Page', 's:9:\"Edit Page\";', 1760123744),
('laravel_cache_translation.ar.dashboard.edit_translation', 's:16:\"Edit Translation\";', 1760128743),
('laravel_cache_translation.ar.dashboard.Export_CSV', 's:10:\"Export CSV\";', 1760128712),
('laravel_cache_translation.ar.dashboard.features_title', 's:0:\"\";', 1760483233),
('laravel_cache_translation.ar.dashboard.feedbacks', 's:11:\"testimonial\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Flag', 's:4:\"Flag\";', 1760467288),
('laravel_cache_translation.ar.dashboard.Flag_Image', 's:32:\"Flag Image URL (https://ex.com):\";', 1759781436),
('laravel_cache_translation.ar.dashboard.Flag_Image_URL:', 's:26:\"Flag Image URL (optional):\";', 1759781436),
('laravel_cache_translation.ar.dashboard.Frontend', 's:8:\"Frontend\";', 1760128712),
('laravel_cache_translation.ar.dashboard.General', 's:7:\"General\";', 1760128712),
('laravel_cache_translation.ar.dashboard.General_Setting', 's:15:\"General Setting\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Home', 's:16:\"الرئيسية\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Homepage', 's:8:\"Homepage\";', 1760476834),
('laravel_cache_translation.ar.dashboard.Import_CSV', 's:10:\"Import CSV\";', 1760128712),
('laravel_cache_translation.ar.dashboard.invoices', 's:8:\"invoices\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Key', 's:3:\"Key\";', 1760128712),
('laravel_cache_translation.ar.dashboard.Language_Code', 's:31:\"Language Code (ex: en, ar, fr):\";', 1759781436),
('laravel_cache_translation.ar.dashboard.Language_Name', 's:13:\"Language Name\";', 1759781436),
('laravel_cache_translation.ar.dashboard.Language_Name_(English):', 's:24:\"Language Name (English):\";', 1759781436),
('laravel_cache_translation.ar.dashboard.languages', 's:9:\"languages\";', 1760482957),
('laravel_cache_translation.ar.dashboard.languages_edit', 's:14:\"Languages Edit\";', 1760467288),
('laravel_cache_translation.ar.dashboard.Languages_List', 's:14:\"Languages List\";', 1760467288),
('laravel_cache_translation.ar.dashboard.Logout', 's:6:\"Logout\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Make_Homepage', 's:13:\"Make Homepage\";', 1760476834),
('laravel_cache_translation.ar.dashboard.media', 's:5:\"Media\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Menus', 's:5:\"Menus\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Meta_Description', 's:16:\"Meta Description\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Meta_Keywords', 's:13:\"Meta Keywords\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Meta_Title', 's:10:\"Meta Title\";', 1760123744),
('laravel_cache_translation.ar.dashboard.My_Account', 's:10:\"My Account\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Name', 's:4:\"Name\";', 1760467288),
('laravel_cache_translation.ar.dashboard.Native_Name', 's:11:\"Native Name\";', 1760467288),
('laravel_cache_translation.ar.dashboard.Native_Name:', 's:12:\"Native Name:\";', 1759781436),
('laravel_cache_translation.ar.dashboard.Navigation', 's:10:\"Navigation\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Open_Graph_Image_URL', 's:20:\"Open Graph Image URL\";', 1760123744),
('laravel_cache_translation.ar.dashboard.orders', 's:6:\"orders\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Page_Content', 's:12:\"Page Content\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Page_Title', 's:10:\"Page Title\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Pages', 's:5:\"Pages\";', 1760482957),
('laravel_cache_translation.ar.dashboard.plan-categories', 's:15:\"plan categories\";', 1760482957),
('laravel_cache_translation.ar.dashboard.plans', 's:5:\"plans\";', 1760482957),
('laravel_cache_translation.ar.dashboard.portfolios', 's:10:\"portfolios\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Preview', 's:7:\"Preview\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Publish', 's:7:\"Publish\";', 1759778183),
('laravel_cache_translation.ar.dashboard.Publish_Date', 's:12:\"Publish Date\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Published', 's:9:\"Published\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Publishing_Options', 's:18:\"Publishing Options\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Reset', 's:5:\"Reset\";', 1760128712),
('laravel_cache_translation.ar.dashboard.reviews', 's:7:\"reviews\";', 1760482957),
('laravel_cache_translation.ar.dashboard.RTL', 's:3:\"RTL\";', 1760467288),
('laravel_cache_translation.ar.dashboard.RTL:Yes_(language written from right to left):', 's:45:\"RTL:Yes (language written from right to left)\";', 1759781436),
('laravel_cache_translation.ar.dashboard.Save', 's:4:\"Save\";', 1760128732),
('laravel_cache_translation.ar.dashboard.Saving', 's:9:\"Saving...\";', 1759778183),
('laravel_cache_translation.ar.dashboard.Search', 's:6:\"Search\";', 1760128712),
('laravel_cache_translation.ar.dashboard.Search_keys...', 's:14:\"Search keys...\";', 1760128712),
('laravel_cache_translation.ar.dashboard.SEO_Meta', 's:8:\"SEO Meta\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Separate_Keywords', 's:51:\"Separate keywords with a comma or Arabic comma (?).\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Separate_keywords_with_a_comma_or_Arabic_comma', 's:51:\"Separate keywords with a comma or Arabic comma (?).\";', 1759778183),
('laravel_cache_translation.ar.dashboard.servers', 's:7:\"servers\";', 1760482957),
('laravel_cache_translation.ar.dashboard.services', 's:8:\"services\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Settings', 's:8:\"Settings\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Short_Description', 's:36:\"Short description for search engines\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Short_description_for_search_engines', 's:36:\"Short description for search engines\";', 1759778183),
('laravel_cache_translation.ar.dashboard.Site_settings', 's:13:\"Site settings\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Slug_Hint', 's:100:\"Use lowercase letters, numbers, and dashes only. Leave empty to auto-generate for the main language.\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Status', 's:6:\"Status\";', 1760476834),
('laravel_cache_translation.ar.dashboard.Status:Active', 's:13:\"Status:Active\";', 1759781436),
('laravel_cache_translation.ar.dashboard.subscriptions', 's:13:\"subscriptions\";', 1760482957),
('laravel_cache_translation.ar.dashboard.sync-logs', 's:9:\"sync-logs\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Taype_Name', 's:10:\"Taype Name\";', 1760128732),
('laravel_cache_translation.ar.dashboard.Template_management', 's:19:\"Template management\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Title', 's:5:\"Title\";', 1760476834),
('laravel_cache_translation.ar.dashboard.Translation_Values', 's:18:\"Translation Values\";', 1760128712),
('laravel_cache_translation.ar.dashboard.Type', 's:4:\"Type\";', 1760128712),
('laravel_cache_translation.ar.dashboard.Update', 's:6:\"Update\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Use_a_full_URL', 's:99:\"Use a full URL or a Storage link generated via asset()/Storage::url(). Recommended size 1200x630px.\";', 1760123744),
('laravel_cache_translation.ar.dashboard.Use_a_full_URL_or_a_Storage_link_generated_via_asset_Storage_url_Recommended_size_1200x630px', 's:99:\"Use a full URL or a Storage link generated via asset()/Storage::url(). Recommended size 1200x630px.\";', 1759778183),
('laravel_cache_translation.ar.dashboard.Users_show', 's:10:\"Users show\";', 1760482957),
('laravel_cache_translation.ar.dashboard.Value', 's:5:\"Value\";', 1760128712),
('laravel_cache_translation.ar.dashboard.You_are_editing_the_content', 's:33:\"You are editing the :name content\";', 1759778182),
('laravel_cache_translation.ar.frontend.Accepted_Payment_Methods', 's:31:\"نقبل وسائل الدفع:\";', 1760483233),
('laravel_cache_translation.ar.frontend.annually', 's:12:\"سنويًا\";', 1760128692),
('laravel_cache_translation.ar.frontend.Blog', 's:4:\"Blog\";', 1760483233),
('laravel_cache_translation.ar.Frontend.Checkout', 's:8:\"Checkout\";', 1760482691),
('laravel_cache_translation.ar.frontend.Contact_us', 's:19:\"تواصل معنا\";', 1760483233),
('laravel_cache_translation.ar.frontend.Domain', 's:6:\"Domain\";', 1760483233),
('laravel_cache_translation.ar.frontend.Home', 's:16:\"الرئيسية\";', 1760483233),
('laravel_cache_translation.ar.frontend.Hosting', 's:7:\"Hosting\";', 1760483233),
('laravel_cache_translation.ar.frontend.monthly', 's:12:\"شهريًا\";', 1760128692),
('laravel_cache_translation.ar.frontend.Our_Work', 's:8:\"Our Work\";', 1760483233),
('laravel_cache_translation.ar.frontend.page_default_title', 's:13:\"Untitled Page\";', 1760483233),
('laravel_cache_translation.ar.Frontend.Palgoals', 's:8:\"Palgoals\";', 1760482691),
('laravel_cache_translation.ar.frontend.Quick_Links', 's:21:\"روابط سريعة\";', 1760483233),
('laravel_cache_translation.ar.frontend.SEO_Optimization', 's:16:\"SEO Optimization\";', 1760483233),
('laravel_cache_translation.ar.frontend.Services', 's:14:\"خدماتنا\";', 1760483233),
('laravel_cache_translation.ar.frontend.Shared_Hosting', 's:14:\"Shared Hosting\";', 1760483233),
('laravel_cache_translation.ar.frontend.Templates', 's:9:\"Templates\";', 1760483233),
('laravel_cache_translation.ar.frontend.Web_Design', 's:10:\"Web Design\";', 1760483233),
('laravel_cache_translation.ar.frontend.WordPress_Hosting', 's:17:\"WordPress Hosting\";', 1760483233),
('laravel_cache_translation.ar.section.Add_Feature', 's:12:\"+Add Feature\";', 1759481649),
('laravel_cache_translation.ar.section.Available_plans', 's:21:\"Available plans count\";', 1760125879),
('laravel_cache_translation.ar.section.Brief_description', 's:17:\"Brief description\";', 1760125878),
('laravel_cache_translation.ar.section.Category slug', 's:24:\"Category slug (optional)\";', 1760125878),
('laravel_cache_translation.ar.section.Delete', 's:6:\"Delete\";', 1760125878),
('laravel_cache_translation.ar.section.Example:', 's:16:\"Example: 1, 2, 3\";', 1760125878),
('laravel_cache_translation.ar.section.First_button_text', 's:17:\"First button text\";', 1759481456),
('laravel_cache_translation.ar.section.First_button_Url', 's:16:\"First Button Url\";', 1759481456),
('laravel_cache_translation.ar.section.Link_see_more', 's:13:\"Link see more\";', 1759481456),
('laravel_cache_translation.ar.section.No_category_selected', 's:48:\"No category selected — all plans will be shown\";', 1760124042),
('laravel_cache_translation.ar.section.None', 's:10:\"-- None --\";', 1760125878),
('laravel_cache_translation.ar.section.Or provide slug', 's:42:\"Or provide category slug for finer control\";', 1760125878),
('laravel_cache_translation.ar.section.Order', 's:5:\"Order\";', 1760125878),
('laravel_cache_translation.ar.section.Preview', 's:7:\"Preview\";', 1760125878),
('laravel_cache_translation.ar.section.Save_changes', 's:12:\"Save changes\";', 1760125879),
('laravel_cache_translation.ar.section.Second_button_text', 's:18:\"Second Button text\";', 1759481456),
('laravel_cache_translation.ar.section.Second_button_Url', 's:17:\"Second Button Url\";', 1759481456),
('laravel_cache_translation.ar.section.Section_Arrangement', 's:19:\"Section Arrangement\";', 1760123744),
('laravel_cache_translation.ar.section.See_more_button', 's:15:\"See more button\";', 1759481456),
('laravel_cache_translation.ar.section.Select category', 's:15:\"Select category\";', 1760125878),
('laravel_cache_translation.ar.section.Slug_example', 's:16:\"e.g. web-hosting\";', 1760125878),
('laravel_cache_translation.ar.section.Title', 's:5:\"Title\";', 1760125878),
('laravel_cache_translation.en.dashboard.Action', 's:6:\"Action\";', 1760084750),
('laravel_cache_translation.en.dashboard.Actiont', 's:6:\"Action\";', 1760084738),
('laravel_cache_translation.en.dashboard.Add_Languages', 's:13:\"Add Languages\";', 1759781590),
('laravel_cache_translation.en.dashboard.Add_New_Translation', 's:19:\"Add New Translation\";', 1760084738),
('laravel_cache_translation.en.dashboard.Add_Page', 's:8:\"Add Page\";', 1760084749),
('laravel_cache_translation.en.dashboard.Add_Section', 's:11:\"Add Section\";', 1760084759),
('laravel_cache_translation.en.dashboard.Add_User', 's:8:\"Add User\";', 1760124447),
('laravel_cache_translation.en.dashboard.Aim_Characters', 's:58:\"Aim for 50-160 characters. Leave empty to reuse the title.\";', 1760084759),
('laravel_cache_translation.en.dashboard.All_Languages', 's:13:\"All Languages\";', 1760084738),
('laravel_cache_translation.en.dashboard.All_Menus', 's:9:\"ALL Menus\";', 1759781756),
('laravel_cache_translation.en.dashboard.All_Pages', 's:9:\"ALL Pages\";', 1760084749),
('laravel_cache_translation.en.dashboard.All_Services', 'N;', 1759534045),
('laravel_cache_translation.en.dashboard.All_templates', 's:13:\"All templates\";', 1760124446),
('laravel_cache_translation.en.dashboard.All_Types', 's:9:\"All Types\";', 1760084738),
('laravel_cache_translation.en.dashboard.Appearance', 's:10:\"Appearance\";', 1760124447),
('laravel_cache_translation.en.dashboard.Cancel', 's:6:\"Cancel\";', 1760084671),
('laravel_cache_translation.en.dashboard.Cancel_Edit', 's:11:\"Cancel Edit\";', 1760084759),
('laravel_cache_translation.en.dashboard.Categories', 's:10:\"Categories\";', 1760124446),
('laravel_cache_translation.en.dashboard.Choose_from_media', 's:17:\"Choose from media\";', 1760084759),
('laravel_cache_translation.en.dashboard.clients', 's:7:\"clients\";', 1760124446),
('laravel_cache_translation.en.dashboard.Code', 's:4:\"Code\";', 1759781590),
('laravel_cache_translation.en.dashboard.confirm_delete', 's:14:\"Confirm Delete\";', 1760084738),
('laravel_cache_translation.en.dashboard.CRM_management', 's:14:\"CRM management\";', 1760124446),
('laravel_cache_translation.en.dashboard.Current_Homepage', 's:16:\"Current Homepage\";', 1760084750),
('laravel_cache_translation.en.dashboard.Dashboard', 's:9:\"Dashboard\";', 1760084738),
('laravel_cache_translation.en.dashboard.Date', 's:4:\"Date\";', 1760084750),
('laravel_cache_translation.en.dashboard.delete', 's:6:\"Delete\";', 1760084738),
('laravel_cache_translation.en.dashboard.domain_providers', 's:16:\"domain providers\";', 1760124446),
('laravel_cache_translation.en.dashboard.domain-tlds', 's:11:\"domain tlds\";', 1760124446),
('laravel_cache_translation.en.dashboard.domains', 's:7:\"domains\";', 1760124446),
('laravel_cache_translation.en.dashboard.Draft', 's:5:\"Draft\";', 1760084759),
('laravel_cache_translation.en.dashboard.Edit_Page', 's:9:\"Edit Page\";', 1760084759),
('laravel_cache_translation.en.dashboard.edit_translation', 's:16:\"Edit Translation\";', 1760084738),
('laravel_cache_translation.en.dashboard.Export_CSV', 's:10:\"Export CSV\";', 1760084738),
('laravel_cache_translation.en.dashboard.features_title', 's:0:\"\";', 1760124446),
('laravel_cache_translation.en.dashboard.feedbacks', 's:11:\"testimonial\";', 1760124446),
('laravel_cache_translation.en.dashboard.Flag', 's:4:\"Flag\";', 1759781590),
('laravel_cache_translation.en.dashboard.Frontend', 's:8:\"Frontend\";', 1760084738),
('laravel_cache_translation.en.dashboard.General', 's:7:\"General\";', 1760084738),
('laravel_cache_translation.en.dashboard.General_Setting', 's:15:\"General Setting\";', 1760124447),
('laravel_cache_translation.en.dashboard.Homepage', 's:8:\"Homepage\";', 1760084749),
('laravel_cache_translation.en.dashboard.Import_CSV', 's:10:\"Import CSV\";', 1760084738),
('laravel_cache_translation.en.dashboard.invoices', 's:8:\"invoices\";', 1760124446),
('laravel_cache_translation.en.dashboard.Key', 's:3:\"Key\";', 1760084738),
('laravel_cache_translation.en.dashboard.languages', 's:9:\"languages\";', 1760124447),
('laravel_cache_translation.en.dashboard.languages_edit', 's:14:\"Languages Edit\";', 1759781590),
('laravel_cache_translation.en.dashboard.Languages_List', 's:14:\"Languages List\";', 1759781590),
('laravel_cache_translation.en.dashboard.Logout', 's:6:\"Logout\";', 1760124446),
('laravel_cache_translation.en.dashboard.Make_Homepage', 's:13:\"Make Homepage\";', 1760084750),
('laravel_cache_translation.en.dashboard.media', 's:5:\"Media\";', 1760124447),
('laravel_cache_translation.en.dashboard.Menus', 's:5:\"Menus\";', 1760124447),
('laravel_cache_translation.en.dashboard.Meta_Description', 's:16:\"Meta Description\";', 1760084759),
('laravel_cache_translation.en.dashboard.Meta_Keywords', 's:13:\"Meta Keywords\";', 1760084759),
('laravel_cache_translation.en.dashboard.Meta_Title', 's:10:\"Meta Title\";', 1760084759),
('laravel_cache_translation.en.dashboard.My_Account', 's:10:\"My Account\";', 1760124446),
('laravel_cache_translation.en.dashboard.Name', 's:4:\"Name\";', 1759781590),
('laravel_cache_translation.en.dashboard.Native_Name', 's:11:\"Native Name\";', 1759781590),
('laravel_cache_translation.en.dashboard.Navigation', 's:10:\"Navigation\";', 1760124446),
('laravel_cache_translation.en.dashboard.Open_Graph_Image_URL', 's:20:\"Open Graph Image URL\";', 1760084759),
('laravel_cache_translation.en.dashboard.orders', 's:6:\"orders\";', 1760124446),
('laravel_cache_translation.en.dashboard.Page_Content', 's:12:\"Page Content\";', 1760084759),
('laravel_cache_translation.en.dashboard.Page_Title', 's:10:\"Page Title\";', 1760084759),
('laravel_cache_translation.en.dashboard.Pages', 's:5:\"Pages\";', 1760124446),
('laravel_cache_translation.en.dashboard.plan-categories', 's:15:\"plan categories\";', 1760124446),
('laravel_cache_translation.en.dashboard.plans', 's:5:\"plans\";', 1760124446),
('laravel_cache_translation.en.dashboard.portfolios', 's:10:\"portfolios\";', 1760124446),
('laravel_cache_translation.en.dashboard.Preview', 's:7:\"Preview\";', 1760084759),
('laravel_cache_translation.en.dashboard.Publish_Date', 's:12:\"Publish Date\";', 1760084759),
('laravel_cache_translation.en.dashboard.Published', 's:9:\"Published\";', 1760084759),
('laravel_cache_translation.en.dashboard.Publishing_Options', 's:18:\"Publishing Options\";', 1760084759),
('laravel_cache_translation.en.dashboard.Reset', 's:5:\"Reset\";', 1760084738),
('laravel_cache_translation.en.dashboard.reviews', 's:7:\"reviews\";', 1760124446),
('laravel_cache_translation.en.dashboard.RTL', 's:3:\"RTL\";', 1759781590),
('laravel_cache_translation.en.dashboard.Save', 's:4:\"Save\";', 1760084671),
('laravel_cache_translation.en.dashboard.Search', 's:6:\"Search\";', 1760084738),
('laravel_cache_translation.en.dashboard.Search_keys...', 's:14:\"Search keys...\";', 1760084738),
('laravel_cache_translation.en.dashboard.SEO_Meta', 's:8:\"SEO Meta\";', 1760084759),
('laravel_cache_translation.en.dashboard.Separate_Keywords', 's:51:\"Separate keywords with a comma or Arabic comma (?).\";', 1760084759),
('laravel_cache_translation.en.dashboard.servers', 's:7:\"servers\";', 1760124446),
('laravel_cache_translation.en.dashboard.services', 's:8:\"services\";', 1760124446),
('laravel_cache_translation.en.dashboard.Settings', 's:8:\"Settings\";', 1760124446),
('laravel_cache_translation.en.dashboard.Short_Description', 's:36:\"Short description for search engines\";', 1760084759),
('laravel_cache_translation.en.dashboard.Site_settings', 's:13:\"Site settings\";', 1760124446),
('laravel_cache_translation.en.dashboard.Slug_Hint', 's:100:\"Use lowercase letters, numbers, and dashes only. Leave empty to auto-generate for the main language.\";', 1760084759),
('laravel_cache_translation.en.dashboard.Status', 's:6:\"Status\";', 1760084750),
('laravel_cache_translation.en.dashboard.subscriptions', 's:13:\"subscriptions\";', 1760124446),
('laravel_cache_translation.en.dashboard.sync-logs', 's:9:\"sync-logs\";', 1760124446),
('laravel_cache_translation.en.dashboard.Taype_Name', 's:10:\"Taype Name\";', 1760084671),
('laravel_cache_translation.en.dashboard.Template_management', 's:19:\"Template management\";', 1760124446),
('laravel_cache_translation.en.dashboard.Title', 's:5:\"Title\";', 1760084749),
('laravel_cache_translation.en.dashboard.Translation_Values', 's:18:\"Translation Values\";', 1760084738),
('laravel_cache_translation.en.dashboard.Type', 's:4:\"Type\";', 1760084738),
('laravel_cache_translation.en.dashboard.Update', 's:6:\"Update\";', 1760084759),
('laravel_cache_translation.en.dashboard.Use_a_full_URL', 's:99:\"Use a full URL or a Storage link generated via asset()/Storage::url(). Recommended size 1200x630px.\";', 1760084759),
('laravel_cache_translation.en.dashboard.Users_show', 's:10:\"Users show\";', 1760124447),
('laravel_cache_translation.en.dashboard.Value', 's:5:\"Value\";', 1760084738),
('laravel_cache_translation.en.frontend.Accepted_Payment_Methods', 's:24:\"Accepted Payment Methods\";', 1760128680),
('laravel_cache_translation.en.frontend.annually', 's:8:\"Annually\";', 1760128680),
('laravel_cache_translation.en.frontend.Blog', 's:4:\"Blog\";', 1760128680),
('laravel_cache_translation.en.Frontend.Checkout', 's:8:\"Checkout\";', 1760050521),
('laravel_cache_translation.en.frontend.Contact_us', 's:10:\"Contact Us\";', 1760128680),
('laravel_cache_translation.en.frontend.Domain', 's:6:\"Domain\";', 1760128680),
('laravel_cache_translation.en.frontend.Home', 's:4:\"Home\";', 1760128680),
('laravel_cache_translation.en.frontend.Hosting', 's:7:\"Hosting\";', 1760128680),
('laravel_cache_translation.en.frontend.monthly', 's:7:\"Monthly\";', 1760128680),
('laravel_cache_translation.en.frontend.Our_Work', 's:8:\"Our Work\";', 1760128680),
('laravel_cache_translation.en.frontend.page_default_title', 's:13:\"Untitled Page\";', 1760128680),
('laravel_cache_translation.en.Frontend.Palgoals', 's:8:\"Palgoals\";', 1760050521),
('laravel_cache_translation.en.frontend.Quick_Links', 's:11:\"Quick Links\";', 1760128680),
('laravel_cache_translation.en.frontend.SEO_Optimization', 's:16:\"SEO Optimization\";', 1760128680),
('laravel_cache_translation.en.frontend.Services', 's:8:\"Services\";', 1760128680),
('laravel_cache_translation.en.frontend.Shared_Hosting', 's:14:\"Shared Hosting\";', 1760128680),
('laravel_cache_translation.en.frontend.Templates', 's:9:\"Templates\";', 1760128680),
('laravel_cache_translation.en.frontend.Web_Design', 's:10:\"Web Design\";', 1760128680),
('laravel_cache_translation.en.frontend.WordPress_Hosting', 's:17:\"WordPress Hosting\";', 1760128680),
('laravel_cache_translation.en.section.Available_plans', 's:21:\"Available plans count\";', 1760085917),
('laravel_cache_translation.en.section.Brief_description', 's:17:\"Brief description\";', 1760085917),
('laravel_cache_translation.en.section.Category slug', 's:24:\"Category slug (optional)\";', 1760085917),
('laravel_cache_translation.en.section.Delete', 's:6:\"Delete\";', 1760085917),
('laravel_cache_translation.en.section.Example:', 's:16:\"Example: 1, 2, 3\";', 1760085917),
('laravel_cache_translation.en.section.No_category_selected', 'N;', 1759778888),
('laravel_cache_translation.en.section.None', 's:10:\"-- None --\";', 1760085917),
('laravel_cache_translation.en.section.Or provide slug', 's:42:\"Or provide category slug for finer control\";', 1760085917),
('laravel_cache_translation.en.section.Order', 's:5:\"Order\";', 1760085917),
('laravel_cache_translation.en.section.Preview', 's:7:\"Preview\";', 1760085917),
('laravel_cache_translation.en.section.Save_changes', 's:12:\"Save changes\";', 1760085917),
('laravel_cache_translation.en.section.Section_Arrangement', 's:19:\"Section Arrangement\";', 1760085306),
('laravel_cache_translation.en.section.Select category', 's:15:\"Select category\";', 1760085917),
('laravel_cache_translation.en.section.Slug_example', 's:16:\"e.g. web-hosting\";', 1760085917),
('laravel_cache_translation.en.section.Title', 's:5:\"Title\";', 1760085917),
('laravel_cache_translation.fr.dashboard.Actiont', 's:6:\"Action\";', 1759781559),
('laravel_cache_translation.fr.dashboard.Add_Languages', 's:13:\"Add Languages\";', 1759781559),
('laravel_cache_translation.fr.dashboard.Add_User', 's:8:\"Add User\";', 1759781502),
('laravel_cache_translation.fr.dashboard.All_Menus', 's:9:\"ALL Menus\";', 1759781501),
('laravel_cache_translation.fr.dashboard.All_Services', 'N;', 1759534052),
('laravel_cache_translation.fr.dashboard.All_templates', 's:13:\"All templates\";', 1759781501),
('laravel_cache_translation.fr.dashboard.Appearance', 's:10:\"Appearance\";', 1759781502),
('laravel_cache_translation.fr.dashboard.Categories', 's:10:\"Categories\";', 1759781501),
('laravel_cache_translation.fr.dashboard.clients', 's:7:\"clients\";', 1759781502),
('laravel_cache_translation.fr.dashboard.Code', 's:4:\"Code\";', 1759781559),
('laravel_cache_translation.fr.dashboard.CRM_management', 's:14:\"CRM management\";', 1759781502),
('laravel_cache_translation.fr.dashboard.domain_providers', 's:16:\"domain providers\";', 1759781502),
('laravel_cache_translation.fr.dashboard.domain-tlds', 's:11:\"domain tlds\";', 1759781502),
('laravel_cache_translation.fr.dashboard.domains', 's:7:\"domains\";', 1759781502),
('laravel_cache_translation.fr.dashboard.features_title', 's:0:\"\";', 1759781551),
('laravel_cache_translation.fr.dashboard.feedbacks', 's:11:\"testimonial\";', 1759781501),
('laravel_cache_translation.fr.dashboard.Flag', 's:4:\"Flag\";', 1759781559),
('laravel_cache_translation.fr.dashboard.General_Setting', 's:15:\"General Setting\";', 1759781502),
('laravel_cache_translation.fr.dashboard.Home', 's:4:\"Home\";', 1759781501),
('laravel_cache_translation.fr.dashboard.invoices', 's:8:\"invoices\";', 1759781502),
('laravel_cache_translation.fr.dashboard.languages', 's:9:\"languages\";', 1759781559),
('laravel_cache_translation.fr.dashboard.languages_edit', 's:14:\"Languages Edit\";', 1759781541),
('laravel_cache_translation.fr.dashboard.Languages_List', 's:14:\"Languages List\";', 1759781540),
('laravel_cache_translation.fr.dashboard.Logout', 's:6:\"Logout\";', 1759781501),
('laravel_cache_translation.fr.dashboard.media', 's:5:\"Media\";', 1759781502),
('laravel_cache_translation.fr.dashboard.Menus', 's:5:\"Menus\";', 1759781502),
('laravel_cache_translation.fr.dashboard.My_Account', 's:10:\"My Account\";', 1759781501),
('laravel_cache_translation.fr.dashboard.Name', 's:4:\"Name\";', 1759781559),
('laravel_cache_translation.fr.dashboard.Native_Name', 's:11:\"Native Name\";', 1759781559),
('laravel_cache_translation.fr.dashboard.Navigation', 's:10:\"Navigation\";', 1759781501),
('laravel_cache_translation.fr.dashboard.orders', 's:6:\"orders\";', 1759781502),
('laravel_cache_translation.fr.dashboard.Pages', 's:5:\"Pages\";', 1759781501),
('laravel_cache_translation.fr.dashboard.plan-categories', 's:15:\"plan categories\";', 1759781502),
('laravel_cache_translation.fr.dashboard.plans', 's:5:\"plans\";', 1759781502),
('laravel_cache_translation.fr.dashboard.portfolios', 's:10:\"portfolios\";', 1759781501),
('laravel_cache_translation.fr.dashboard.reviews', 's:7:\"reviews\";', 1759781501),
('laravel_cache_translation.fr.dashboard.RTL', 's:3:\"RTL\";', 1759781559),
('laravel_cache_translation.fr.dashboard.servers', 's:7:\"servers\";', 1759781502),
('laravel_cache_translation.fr.dashboard.services', 's:8:\"Services\";', 1759781501),
('laravel_cache_translation.fr.dashboard.Settings', 's:8:\"Settings\";', 1759781501),
('laravel_cache_translation.fr.dashboard.Site_settings', 's:13:\"Site settings\";', 1759781502),
('laravel_cache_translation.fr.dashboard.Status', 's:6:\"Status\";', 1759781559),
('laravel_cache_translation.fr.dashboard.subscriptions', 's:13:\"subscriptions\";', 1759781502),
('laravel_cache_translation.fr.dashboard.sync-logs', 's:9:\"sync-logs\";', 1759781502),
('laravel_cache_translation.fr.dashboard.Template_management', 's:19:\"Template management\";', 1759781501),
('laravel_cache_translation.fr.dashboard.Users_show', 's:10:\"Users show\";', 1759781502),
('laravel_cache_translation.fr.frontend.Accepted_Payment_Methods', 's:24:\"Accepted Payment Methods\";', 1759781489),
('laravel_cache_translation.fr.frontend.Blog', 'N;', 1759781489),
('laravel_cache_translation.fr.frontend.Contact_us', 's:10:\"Contact Us\";', 1759781489),
('laravel_cache_translation.fr.frontend.Domain', 'N;', 1759781489),
('laravel_cache_translation.fr.frontend.Home', 'N;', 1759781489),
('laravel_cache_translation.fr.frontend.Hosting', 'N;', 1759781489),
('laravel_cache_translation.fr.frontend.Our_Work', 'N;', 1759781489),
('laravel_cache_translation.fr.frontend.page_default_title', 's:13:\"Untitled Page\";', 1759781488),
('laravel_cache_translation.fr.frontend.Quick_Links', 'N;', 1759781489),
('laravel_cache_translation.fr.frontend.SEO_Optimization', 'N;', 1759781489),
('laravel_cache_translation.fr.frontend.Services', 'N;', 1759781489),
('laravel_cache_translation.fr.frontend.Shared_Hosting', 'N;', 1759781489),
('laravel_cache_translation.fr.frontend.Templates', 'N;', 1759781489),
('laravel_cache_translation.fr.frontend.Web_Design', 'N;', 1759781489),
('laravel_cache_translation.fr.frontend.WordPress_Hosting', 'N;', 1759781489);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category_templates`
--

CREATE TABLE `category_templates` (
  `id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category_template_translations`
--

CREATE TABLE `category_template_translations` (
  `id` bigint UNSIGNED NOT NULL,
  `category_template_id` bigint UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` bigint UNSIGNED NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `can_login` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'إذا كان false فلن يسمح بتسجيل الدخول',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `zip_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `first_name`, `last_name`, `email`, `password`, `company_name`, `phone`, `can_login`, `status`, `avatar`, `remember_token`, `created_at`, `updated_at`, `zip_code`, `country`, `city`, `address`) VALUES
(1, 'Mohammad', 'Ali', 'client@example.com', '$2y$12$xtBr1LsIxfTSIfAHwlJnkuzC7bB0jX1f8J.kCgyi5Mq1lwmvQiJaq', 'Acme Co', '0501234567', 1, 'active', 'images/clients/1.png', NULL, '2025-09-27 20:22:44', '2025-09-27 20:22:44', NULL, NULL, NULL, NULL),
(2, 'hazem', 'alyahya', 'info@palgoals.com', '$2y$12$I//CU78P7QKjncQ5vSDKB.eKwzyg3SJN1w4Wyn.p2U2GhRDj44obu', 'Acme Co', '0501234567', 1, 'active', 'images/clients/1.png', NULL, '2025-09-27 20:22:45', '2025-09-27 20:22:45', NULL, NULL, NULL, NULL),
(3, 'hazem', 'alyahya', 'palgooal@gmail.com', '$2y$12$go94nQymjg25azpn.p6/c.PJs6e77CrnhzjGlbMF50gtZiW/0Hhui', 'palgoals', '0599000932', 1, 'active', 'avatars/tvjNHcoghrdQWNOhkiA0EGKe7LpLIadH0CVhcpG5.png', NULL, '2025-09-29 17:20:26', '2025-09-29 17:20:26', '970', NULL, NULL, NULL),
(4, 'amer', 'mousa', 'amer.mousa@palgoals.com', '$2y$12$CEc0MjQu5ubHZlB2//guEOuodIdJ2j6WFXb4mI1rQ0xYHEEN8iJnG', '-', '0599753850', 1, 'active', NULL, NULL, '2025-10-14 19:58:02', '2025-10-14 19:58:02', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `client_contacts`
--

CREATE TABLE `client_contacts` (
  `id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('billing','tech','general') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `can_login` tinyint(1) NOT NULL DEFAULT '0',
  `password_hash` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `client_notes`
--

CREATE TABLE `client_notes` (
  `id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `admin_id` bigint UNSIGNED DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_value` decimal(10,2) NOT NULL,
  `expires_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coupon_subscription`
--

CREATE TABLE `coupon_subscription` (
  `id` bigint UNSIGNED NOT NULL,
  `coupon_id` bigint UNSIGNED NOT NULL,
  `subscription_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `domains`
--

CREATE TABLE `domains` (
  `id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `domain_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registration_date` date NOT NULL,
  `renewal_date` date DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `domains`
--

INSERT INTO `domains` (`id`, `client_id`, `domain_name`, `registrar`, `registration_date`, `renewal_date`, `status`, `created_at`, `updated_at`, `payment_method`) VALUES
(1, 3, '5555.palgoals.com', 'order-1', '2025-10-10', NULL, 'active', '2025-10-10 17:36:00', '2025-10-10 17:36:00', NULL),
(2, 4, 'actioncinemahub.com', 'namecheap', '2025-10-15', '2025-10-15', 'active', '2025-10-14 20:00:12', '2025-10-14 20:00:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `domain_providers`
--

CREATE TABLE `domain_providers` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpoint` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` text COLLATE utf8mb4_unicode_ci,
  `api_token` text COLLATE utf8mb4_unicode_ci,
  `api_key` text COLLATE utf8mb4_unicode_ci,
  `client_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `mode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'live',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `domain_providers`
--

INSERT INTO `domain_providers` (`id`, `name`, `type`, `endpoint`, `username`, `password`, `api_token`, `api_key`, `client_ip`, `is_active`, `mode`, `created_at`, `updated_at`) VALUES
(1, 'Enom Test Provider', 'enom', NULL, 'enom_test_user', 'eyJpdiI6IlBYWEphYUdEaHk3N0ZvZnNDL2lBOEE9PSIsInZhbHVlIjoiQVhmcDRlRGdxQ3lVMTVmaW91NHlMdz09IiwibWFjIjoiOTYwOTk1MzlkNDhkZjIzOTEyYjkxMTcyNzk4NmNhMTIyNzliNWNkZTdjNTA1YTE1YWFiY2QwYzc4M2FiNzM2YyIsInRhZyI6IiJ9', NULL, NULL, NULL, 1, 'test', '2025-09-27 20:22:45', '2025-09-27 20:22:45'),
(2, 'Namecheap Sandbox', 'namecheap', 'https://api.sandbox.namecheap.com/xml.response', 'palgoals2025', NULL, NULL, 'eyJpdiI6IjMrMHpLbWw2bS9YT3lYWVd6aFphUHc9PSIsInZhbHVlIjoid2hCZG0vZFlqTlRXVVVFZEFBZU5XNXN4TUxlQ2lqVlhBL2FqSnZ5U2lEbGdkS3V4VjUvN3piSFNnVytIMi8rZSIsIm1hYyI6IjlkYzkyM2RiN2Q5ZWM2ODE5ZGFjZWM5YWYwZjU4NjE2MGViODQ0OGQxZTgyOGMxOWRiODA5YjI3NWM0N2E5OWQiLCJ0YWciOiIifQ==', '127.0.0.1', 1, 'test', '2025-09-27 20:22:45', '2025-10-14 19:54:06'),
(3, 'Cloudflare Test Provider', 'cloudflare', 'https://api.cloudflare.com/client/v4', NULL, NULL, 'eyJpdiI6IjJSM3JkemRUNDJOTzlHaEY3dktScmc9PSIsInZhbHVlIjoidFJWR2gwVjRnV2tDeEdpMXJ1NzNUdnFKRWVDVktWd2hDN0U3dnpvaUlvWT0iLCJtYWMiOiIwNWJiZWI3YTRjYmRkNGI1ZGIzZWM5Njg3OGExOTZkZDM2ZmNiNWEzM2M5YTIzZDgyNzI3YTUzNTQ0MmZlYWQyIiwidGFnIjoiIn0=', NULL, NULL, 1, 'test', '2025-09-27 20:22:45', '2025-09-27 20:22:45');

-- --------------------------------------------------------

--
-- Table structure for table `domain_tlds`
--

CREATE TABLE `domain_tlds` (
  `id` bigint UNSIGNED NOT NULL,
  `provider_id` bigint UNSIGNED NOT NULL,
  `provider` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tld` varchar(63) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `supports_premium` tinyint(1) NOT NULL DEFAULT '0',
  `synced_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `in_catalog` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `domain_tlds`
--

INSERT INTO `domain_tlds` (`id`, `provider_id`, `provider`, `tld`, `currency`, `enabled`, `supports_premium`, `synced_at`, `created_at`, `updated_at`, `in_catalog`) VALUES
(1, 2, 'namecheap', 'com', 'USD', 1, 1, '2025-10-14 19:56:47', '2025-10-14 19:56:46', '2025-10-14 19:56:47', 1);

-- --------------------------------------------------------

--
-- Table structure for table `domain_tld_prices`
--

CREATE TABLE `domain_tld_prices` (
  `id` bigint UNSIGNED NOT NULL,
  `domain_tld_id` bigint UNSIGNED NOT NULL,
  `action` enum('register','renew','transfer','restore') COLLATE utf8mb4_unicode_ci NOT NULL,
  `years` tinyint UNSIGNED NOT NULL DEFAULT '1',
  `cost` decimal(10,2) DEFAULT NULL,
  `sale` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `domain_tld_prices`
--

INSERT INTO `domain_tld_prices` (`id`, `domain_tld_id`, `action`, `years`, `cost`, `sale`, `created_at`, `updated_at`) VALUES
(1, 1, 'register', 1, 13.98, 16.78, '2025-10-14 19:56:46', '2025-10-14 19:56:56'),
(2, 1, 'register', 2, 13.98, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(3, 1, 'register', 3, 13.98, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(4, 1, 'register', 4, 13.98, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(5, 1, 'register', 5, 13.98, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(6, 1, 'register', 6, 13.98, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(7, 1, 'register', 7, 13.98, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(8, 1, 'register', 8, 13.98, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(9, 1, 'register', 9, 13.98, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(10, 1, 'register', 10, 13.98, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(11, 1, 'renew', 1, 18.08, 21.70, '2025-10-14 19:56:46', '2025-10-14 19:56:56'),
(12, 1, 'renew', 2, 18.08, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(13, 1, 'renew', 3, 18.08, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(14, 1, 'renew', 4, 18.08, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(15, 1, 'renew', 5, 18.08, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(16, 1, 'renew', 6, 18.08, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(17, 1, 'renew', 7, 18.08, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(18, 1, 'renew', 8, 18.08, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(19, 1, 'renew', 9, 18.08, NULL, '2025-10-14 19:56:46', '2025-10-14 19:56:46'),
(20, 1, 'transfer', 1, 13.78, 16.54, '2025-10-14 19:56:47', '2025-10-14 19:56:56');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` bigint UNSIGNED NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `star` int DEFAULT NULL,
  `order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback_translations`
--

CREATE TABLE `feedback_translations` (
  `id` bigint UNSIGNED NOT NULL,
  `feedback` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `major` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feedback_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `general_settings`
--

CREATE TABLE `general_settings` (
  `id` bigint UNSIGNED NOT NULL,
  `site_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_discretion` text COLLATE utf8mb4_unicode_ci,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dark_logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sticky_logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dark_sticky_logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_dark_logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_language` bigint UNSIGNED DEFAULT NULL,
  `contact_info` json DEFAULT NULL,
  `social_links` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `general_settings`
--

INSERT INTO `general_settings` (`id`, `site_title`, `site_discretion`, `logo`, `dark_logo`, `sticky_logo`, `dark_sticky_logo`, `admin_logo`, `admin_dark_logo`, `favicon`, `default_language`, `contact_info`, `social_links`, `created_at`, `updated_at`) VALUES
(1, 'ssss', 'أنشئ موقعك أو متجرك الإلكتروني بكل سهولة مع بال قول — حلول استضافة، تصميم، ودعم متواصل.', NULL, NULL, NULL, NULL, 'general_settings/OHX8FSBU0KmEMhXlPBciBe2EqBv43bBB5mKWcUgA.png', NULL, 'general_settings/y1uH4clCELgVjawir1J1y8kx67K3Rg0RHuGS8TPH.png', 2, '{\"email\": \"info@palgoals.com\", \"phone\": \"970598663901+\", \"address\": \"\"}', '{\"twitter\": \"https://x.com/palgoals\", \"facebook\": \"https://www.facebook.com/palgoals/\", \"linkedin\": \"https://www.linkedin.com/company/palgoals\", \"whatsapp\": \"https://api.whatsapp.com/send?phone=970598663901\", \"instagram\": \"https://www.instagram.com/palgoals/\"}', '2025-09-27 20:22:44', '2025-10-03 14:09:13');

-- --------------------------------------------------------

--
-- Table structure for table `headers`
--

CREATE TABLE `headers` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `headers`
--

INSERT INTO `headers` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Main Header', '2025-09-28 19:56:34', '2025-09-28 19:56:34');

-- --------------------------------------------------------

--
-- Table structure for table `header_items`
--

CREATE TABLE `header_items` (
  `id` bigint UNSIGNED NOT NULL,
  `header_id` bigint UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'link',
  `page_id` bigint UNSIGNED DEFAULT NULL,
  `children` json DEFAULT NULL,
  `order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `header_items`
--

INSERT INTO `header_items` (`id`, `header_id`, `type`, `page_id`, `children`, `order`, `created_at`, `updated_at`) VALUES
(3, 1, 'page', 1, NULL, 0, '2025-10-03 05:49:09', '2025-10-03 05:49:09'),
(4, 1, 'dropdown', NULL, '[{\"type\": \"page\", \"labels\": {\"ar\": {\"url\": \"/استضافة-مشتركة\", \"label\": \"استضافة مشتركة\"}, \"en\": {\"url\": \"#\", \"label\": \"\"}, \"fr\": {\"url\": \"#\", \"label\": \"\"}}, \"page_id\": \"3\"}, {\"type\": \"page\", \"labels\": {\"ar\": {\"url\": \"/استضافة-ووردبريس\", \"label\": \"استضافة ووردبريس\"}, \"en\": {\"url\": \"#\", \"label\": \"\"}, \"fr\": {\"url\": \"#\", \"label\": \"\"}}, \"page_id\": \"4\"}]', 0, '2025-10-03 15:23:22', '2025-10-03 15:23:22'),
(5, 1, 'page', 5, NULL, 0, '2025-10-06 16:14:08', '2025-10-06 17:14:25'),
(6, 1, 'page', 6, NULL, 0, '2025-10-06 16:19:27', '2025-10-06 17:15:11');

-- --------------------------------------------------------

--
-- Table structure for table `header_item_translations`
--

CREATE TABLE `header_item_translations` (
  `id` bigint UNSIGNED NOT NULL,
  `header_item_id` bigint UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `header_item_translations`
--

INSERT INTO `header_item_translations` (`id`, `header_item_id`, `locale`, `label`, `url`, `created_at`, `updated_at`) VALUES
(7, 3, 'en', 'Home Page', '', '2025-10-03 05:49:09', '2025-10-03 05:49:09'),
(8, 3, 'ar', 'الرئيسية', '', '2025-10-03 05:49:09', '2025-10-03 05:49:09'),
(9, 3, 'fr', '', '', '2025-10-03 05:49:09', '2025-10-03 05:49:09'),
(10, 4, 'en', 'Hosting', '', '2025-10-03 15:23:22', '2025-10-06 16:23:19'),
(11, 4, 'ar', 'الاستضافة', '', '2025-10-03 15:23:22', '2025-10-03 15:23:22'),
(12, 4, 'fr', '', '', '2025-10-03 15:23:22', '2025-10-03 15:23:22'),
(13, 5, 'en', 'Domain registration', '/Domain-registration', '2025-10-06 16:14:08', '2025-10-06 17:14:25'),
(14, 5, 'ar', 'حجز الدومين', '/حجز-الدومين', '2025-10-06 16:14:08', '2025-10-06 17:14:25'),
(15, 5, 'fr', '', '', '2025-10-06 16:14:08', '2025-10-06 16:14:08'),
(16, 5, 'aa', '', '', '2025-10-06 16:14:08', '2025-10-06 16:14:08'),
(17, 6, 'en', 'Our business', '/our-business', '2025-10-06 16:19:27', '2025-10-06 17:15:11'),
(18, 6, 'ar', 'أعمالنا', '/أعمالنا', '2025-10-06 16:19:27', '2025-10-06 17:15:11'),
(19, 6, 'fr', '', '', '2025-10-06 16:19:27', '2025-10-06 16:19:27'),
(20, 6, 'aa', '', '', '2025-10-06 16:19:27', '2025-10-06 16:19:27'),
(21, 4, 'aa', '', '', '2025-10-06 16:23:19', '2025-10-06 16:23:19');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `order_id` bigint UNSIGNED DEFAULT NULL,
  `number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('draft','unpaid','paid','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `subtotal_cents` int NOT NULL DEFAULT '0',
  `discount_cents` int NOT NULL DEFAULT '0',
  `tax_cents` int NOT NULL DEFAULT '0',
  `total_cents` int NOT NULL DEFAULT '0',
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `due_date` date DEFAULT NULL,
  `paid_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `client_id`, `order_id`, `number`, `status`, `subtotal_cents`, `discount_cents`, `tax_cents`, `total_cents`, `currency`, `due_date`, `paid_date`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 'INV-ORD-20251010-F4QBQ6', 'unpaid', 0, 0, 0, 0, 'USD', '2025-10-13', NULL, '2025-10-10 17:35:16', '2025-10-10 17:36:00'),
(2, 4, NULL, 'INV-7WNSBP', 'unpaid', 0, 0, 0, 0, 'USD', '2025-10-15', NULL, '2025-10-14 20:00:12', '2025-10-14 20:00:12');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_items`
--

CREATE TABLE `invoice_items` (
  `id` bigint UNSIGNED NOT NULL,
  `invoice_id` bigint UNSIGNED NOT NULL,
  `item_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_id` bigint UNSIGNED DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` int UNSIGNED NOT NULL DEFAULT '1',
  `unit_price_cents` int NOT NULL DEFAULT '0',
  `total_cents` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `invoice_items`
--

INSERT INTO `invoice_items` (`id`, `invoice_id`, `item_type`, `reference_id`, `description`, `qty`, `unit_price_cents`, `total_cents`, `created_at`, `updated_at`) VALUES
(1, 1, 'subscription', NULL, '', 1, 75, 75, '2025-10-10 17:35:16', '2025-10-10 17:35:16'),
(2, 2, 'domain', 2, 'رسوم الدومين: actioncinemahub.com', 1, 0, 0, '2025-10-14 20:00:12', '2025-10-14 20:00:12');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `native` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `flag` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_rtl` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `native`, `code`, `flag`, `is_rtl`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'English', 'الإنجليزية', 'en', NULL, 0, 1, '2025-09-27 20:22:44', '2025-09-28 17:42:34'),
(2, 'Arabic', 'العربية', 'ar', NULL, 1, 1, '2025-09-27 20:22:44', '2025-09-28 17:42:42');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mime_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alt_text` text COLLATE utf8mb4_unicode_ci,
  `size` bigint UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploader_id` bigint UNSIGNED DEFAULT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `alt` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caption` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `name`, `file_name`, `path`, `file_path`, `thumbnail_path`, `mime_type`, `alt_text`, `size`, `type`, `uploader_id`, `user_id`, `alt`, `title`, `caption`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(34, 'domains.svg', NULL, NULL, 'uploads/media/KtrgSQawLbZ9bVyMA7GaxgEKg7MnkVMeDDy9Gr3R.svg', NULL, 'image/svg+xml', NULL, 2065, NULL, 11, NULL, NULL, NULL, NULL, NULL, '2025-10-05 19:18:31', '2025-10-05 19:18:31', NULL),
(35, 'Shared-hosting.svg', NULL, NULL, 'uploads/media/VUHu0tzH7Nqw62EjPHhTbgSwSUWljS2UKeiCTOmP.svg', NULL, 'image/svg+xml', NULL, 5112, NULL, 11, NULL, NULL, NULL, NULL, NULL, '2025-10-05 19:18:31', '2025-10-05 19:18:31', NULL),
(36, 'Special-programming.svg', NULL, NULL, 'uploads/media/IaJe7QmqscpjDfTigh85dEUOXpbEwL37QNzJvZKR.svg', NULL, 'image/svg+xml', NULL, 11983, NULL, 11, NULL, NULL, NULL, NULL, NULL, '2025-10-05 19:18:31', '2025-10-05 19:18:31', NULL),
(37, 'Website-design.svg', NULL, NULL, 'uploads/media/ngFFGMVwWGofl18z4Uk1zrDttaMZ3lpzXIfHAM7n.svg', NULL, 'image/svg+xml', NULL, 9529, NULL, 11, NULL, NULL, NULL, NULL, NULL, '2025-10-05 19:18:43', '2025-10-05 19:18:43', NULL),
(39, 'wordpress-hosting.svg', NULL, NULL, 'uploads/media/oqbfc1usigcKkvxz2Vh0wyhEy36BJiIY9Ypm3Cei.svg', NULL, 'image/svg+xml', NULL, 3728, NULL, 11, NULL, NULL, NULL, NULL, NULL, '2025-10-05 19:18:44', '2025-10-05 19:18:44', NULL),
(41, 'مؤسسة-مروان-01.webp', NULL, NULL, 'uploads/media/fJjT5UpdrZvXNueWNYSKXobNo72Nm8RP3aU5UUe1.webp', NULL, 'image/webp', NULL, 34870, NULL, 11, NULL, NULL, NULL, NULL, NULL, '2025-10-06 17:23:44', '2025-10-06 17:23:44', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_07_11_084313_create_role_users_table', 1),
(5, '2025_05_03_132311_create_plan_categories_table', 1),
(6, '2025_05_03_132312_create_plans_table', 1),
(7, '2025_05_03_132914_create_coupons_table', 1),
(8, '2025_06_02_115423_add_two_factor_columns_to_users_table', 1),
(9, '2025_06_05_192745_create_translation_values_table', 1),
(10, '2025_06_06_153733_create_languages_table', 1),
(11, '2025_06_11_203841_create_media_table', 1),
(12, '2025_06_17_113900_create_general_settings_table', 1),
(13, '2025_06_24_112044_create_services_table', 1),
(14, '2025_06_24_112103_create_service_translations_table', 1),
(15, '2025_06_25_111513_create_feedbacks_table', 1),
(16, '2025_06_25_111554_create_feedback_translations_table', 1),
(17, '2025_06_26_135224_create_pages_table', 1),
(18, '2025_06_26_140303_create_sections_table', 1),
(19, '2025_06_26_184000_create_page_translations_table', 1),
(20, '2025_06_26_193807_create_section_translations_table', 1),
(21, '2025_06_28_111512_create_portfolios_table', 1),
(22, '2025_06_28_111644_create_portfolio_translations_table', 1),
(26, '2025_07_28_132056_create_clients_table', 1),
(27, '2025_07_30_114900_add_cloum_to_clients_table', 1),
(28, '2025_07_30_205934_create_category_templates_table', 1),
(29, '2025_07_30_210108_create_category_template_translations_table', 1),
(30, '2025_07_30_210818_create_templates_table', 1),
(31, '2025_07_30_212224_create_template_translations_table', 1),
(32, '2025_08_03_133326_create_domains_table', 1),
(33, '2025_08_11_230628_create_template_reviews_table', 1),
(34, '2025_08_11_231918_add_rating_columns_to_templates_table', 1),
(35, '2025_08_17_123121_add_cloums_to_domains_table', 1),
(36, '2025_08_17_132647_create_subscriptions_table', 1),
(37, '2025_08_18_123531_create_coupon_subscription_table', 1),
(38, '2025_08_18_132758_create_invoices_table', 1),
(39, '2025_08_18_133155_create_sites_table', 1),
(40, '2025_08_19_155848_add_cloums_to_clients_tables', 1),
(41, '2025_08_19_160005_create_client_contacts_table', 1),
(42, '2025_08_19_160031_create_client_notes_table', 1),
(43, '2025_08_19_160120_create_activity_logs_table', 1),
(44, '2025_08_22_000001_create_orders_table', 1),
(45, '2025_08_22_150000_create_servers_table', 1),
(46, '2025_08_22_160000_alter_password_to_text_in_servers_table', 1),
(47, '2025_08_22_203100_alter_api_token_column_in_servers_table', 1),
(48, '2025_08_23_114349_rebuild_invoices_tables', 1),
(49, '2025_08_29_000002_make_domain_fields_nullable_in_subscriptions_table', 1),
(50, '2025_08_29_120000_add_last_sync_message_to_subscriptions_table', 1),
(51, '2025_08_30_000000_create_domain_providers_table', 1),
(52, '2025_09_05_000000_create_domain_tlds_table', 1),
(53, '2025_09_05_000001_create_domain_tld_prices_table', 1),
(54, '2025_09_06_000002_add_in_catalog_to_domain_tlds', 1),
(55, '2025_09_12_000001_create_order_items_table', 1),
(56, '2025_09_16_000001_drop_template_id_from_domains_table', 1),
(57, '2025_09_22_120000_add_server_package_to_plans_table', 1),
(58, '2025_09_22_130000_add_server_package_to_subscriptions_table', 1),
(59, '2025_09_26_150630_update_slug_nullable_on_page_translations_table', 1),
(60, '2025_09_26_161500_add_published_at_to_pages_table', 1),
(65, '2025_06_29_221233_create_headers_table', 2),
(66, '2025_06_29_221310_create_header_items_table', 2),
(67, '2025_06_29_221338_create_header_item_translations_table', 2),
(68, '2024_12_01_000000_enhance_media_table', 3),
(69, '2025_10_02_082705_add_contact_info_and_social_links_to_general_settings_table', 4),
(70, '2025_09_24_120001_add_featured_columns_and_transform_plan_features', 5),
(71, '2025_10_08_000001_add_featured_label_to_plan_translations_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED DEFAULT NULL,
  `order_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','active','cancelled','fraud') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `client_id`, `order_number`, `status`, `type`, `notes`, `created_at`, `updated_at`) VALUES
(1, 3, 'ORD-20251010-F4QBQ6', 'active', 'subscription', 'طلب عبر صفحة checkout', '2025-10-10 17:35:16', '2025-10-10 17:36:00');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint UNSIGNED NOT NULL,
  `order_id` bigint UNSIGNED NOT NULL,
  `domain` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_option` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_cents` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `domain`, `item_option`, `price_cents`, `meta`, `created_at`, `updated_at`) VALUES
(1, 1, '5555.palgoals.com', 'register', 0, NULL, '2025-10-10 17:35:16', '2025-10-10 17:35:16');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` bigint UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_home` tinyint(1) NOT NULL DEFAULT '0',
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `is_active`, `is_home`, `published_at`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2025-09-28 18:06:00', '2025-09-27 20:22:44', '2025-10-03 05:46:41'),
(3, 1, 0, '2025-10-03 15:22:00', '2025-10-03 15:22:06', '2025-10-06 16:27:34'),
(4, 1, 0, '2025-10-03 15:22:00', '2025-10-03 15:22:42', '2025-10-06 16:28:07'),
(5, 1, 0, '2025-10-06 16:01:00', '2025-10-06 16:01:20', '2025-10-06 16:28:30'),
(6, 1, 0, '2025-10-06 16:15:00', '2025-10-06 16:15:31', '2025-10-06 16:21:46');

-- --------------------------------------------------------

--
-- Table structure for table `page_translations`
--

CREATE TABLE `page_translations` (
  `id` bigint UNSIGNED NOT NULL,
  `page_id` bigint UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `meta_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_keywords` json DEFAULT NULL,
  `og_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page_translations`
--

INSERT INTO `page_translations` (`id`, `page_id`, `locale`, `slug`, `title`, `content`, `meta_title`, `meta_description`, `meta_keywords`, `og_image`, `created_at`, `updated_at`) VALUES
(1, 1, 'ar', NULL, 'الرئيسية', '', 'الصفحة الرئيسية', 'بال قول تقدم حلول الاستضافة والتسويق الرقمي باللغة العربية.', '[\"استضافة\", \"تصميم مواقع\", \"برمجة\"]', 'http://127.0.0.1:8000/storage/uploads/media/wjUzO7P26SlOQHAk9hbYA6depdIATpDfdE0m3bGw.png', '2025-09-27 20:22:44', '2025-10-03 05:46:41'),
(2, 1, 'en', NULL, 'Home Page', '', 'Home', 'Palgoals delivers hosting and digital services for businesses.', '[\"hosting\", \"web design\", \"digital services\"]', NULL, '2025-09-27 20:22:44', '2025-09-28 18:06:31'),
(5, 1, 'fr', NULL, '', '', '', NULL, NULL, NULL, '2025-09-28 18:06:31', '2025-09-28 18:06:31'),
(6, 3, 'en', 'Shared-hosting', 'Shared hosting', '', 'Shared hosting', NULL, NULL, NULL, '2025-10-03 15:22:06', '2025-10-06 16:27:34'),
(7, 3, 'ar', 'استضافة-مشتركة', 'استضافة مشتركة', '', 'استضافة مشتركة', NULL, NULL, NULL, '2025-10-03 15:22:06', '2025-10-03 15:22:06'),
(8, 3, 'fr', NULL, '', '', '', NULL, NULL, NULL, '2025-10-03 15:22:06', '2025-10-03 15:22:06'),
(9, 4, 'en', 'wordPress-Hosting', 'WordPress Hosting', '', 'WordPress Hosting', NULL, NULL, NULL, '2025-10-03 15:22:42', '2025-10-06 16:28:07'),
(10, 4, 'ar', 'استضافة-ووردبريس', 'استضافة ووردبريس', '', 'استضافة ووردبريس', NULL, NULL, NULL, '2025-10-03 15:22:42', '2025-10-03 15:22:42'),
(11, 4, 'fr', NULL, '', '', '', NULL, NULL, NULL, '2025-10-03 15:22:42', '2025-10-03 15:22:42'),
(12, 5, 'en', 'Domain-registration', 'Domain registration', '', 'Domain registration', NULL, NULL, NULL, '2025-10-06 16:01:20', '2025-10-06 16:28:30'),
(13, 5, 'ar', 'حجز-الدومين', 'حجز الدومين', '', 'حجز الدومين', NULL, NULL, NULL, '2025-10-06 16:01:20', '2025-10-06 16:01:20'),
(14, 5, 'fr', NULL, '', '', '', NULL, NULL, NULL, '2025-10-06 16:01:20', '2025-10-06 16:01:20'),
(15, 5, 'aa', NULL, '', '', '', NULL, NULL, NULL, '2025-10-06 16:01:20', '2025-10-06 16:01:20'),
(16, 6, 'en', 'our-business', 'Our business', '', 'Our business', NULL, NULL, NULL, '2025-10-06 16:15:31', '2025-10-06 16:21:46'),
(17, 6, 'ar', 'أعمالنا', 'أعمالنا', '', 'أعمالنا', NULL, NULL, NULL, '2025-10-06 16:15:31', '2025-10-06 16:15:31'),
(18, 6, 'fr', NULL, '', '', '', NULL, NULL, NULL, '2025-10-06 16:15:31', '2025-10-06 16:15:31'),
(19, 6, 'aa', NULL, '', '', '', NULL, NULL, NULL, '2025-10-06 16:15:31', '2025-10-06 16:15:31'),
(20, 3, 'aa', NULL, '', '', '', NULL, NULL, NULL, '2025-10-06 16:27:34', '2025-10-06 16:27:34'),
(21, 4, 'aa', NULL, '', '', '', NULL, NULL, NULL, '2025-10-06 16:28:07', '2025-10-06 16:28:07');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monthly_price_cents` int UNSIGNED DEFAULT NULL,
  `annual_price_cents` int UNSIGNED DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `featured_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_category_id` bigint UNSIGNED DEFAULT NULL,
  `server_id` bigint UNSIGNED DEFAULT NULL,
  `server_package` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint UNSIGNED DEFAULT NULL,
  `updated_by` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plans`
--

INSERT INTO `plans` (`id`, `name`, `slug`, `monthly_price_cents`, `annual_price_cents`, `is_active`, `is_featured`, `featured_label`, `plan_category_id`, `server_id`, `server_package`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Silver bouquet', 'plu', 75, 699, 1, 0, NULL, 1, 1, 'plu', NULL, NULL, '2025-10-07 13:26:14', '2025-10-09 19:37:51'),
(2, 'الباقة البرونزية', 'الباقة-البرونزية', 599, 5499, 1, 1, 'شائع', 1, 1, 'plu', NULL, NULL, '2025-10-07 13:33:53', '2025-10-09 20:16:09'),
(3, 'Golden Package', 'الباقة-الذهبية', 1099, 10999, 1, 0, NULL, 1, 1, 'plu', NULL, NULL, '2025-10-09 19:24:47', '2025-10-09 19:38:46');

-- --------------------------------------------------------

--
-- Table structure for table `plan_categories`
--

CREATE TABLE `plan_categories` (
  `id` bigint UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `position` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plan_categories`
--

INSERT INTO `plan_categories` (`id`, `is_active`, `position`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 0, '2025-10-07 13:16:36', '2025-10-10 07:30:19', NULL),
(2, 1, 0, '2025-10-07 13:16:56', '2025-10-07 13:16:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `plan_category_translations`
--

CREATE TABLE `plan_category_translations` (
  `id` bigint UNSIGNED NOT NULL,
  `plan_category_id` bigint UNSIGNED NOT NULL,
  `locale` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plan_category_translations`
--

INSERT INTO `plan_category_translations` (`id`, `plan_category_id`, `locale`, `title`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 'en', 'web hosting', 'web-hosting', '5555', '2025-10-07 13:16:36', '2025-10-10 07:30:19'),
(2, 1, 'ar', 'استضافة مشتركة', 'astdaf-mshtrk', '', '2025-10-07 13:16:36', '2025-10-07 13:16:36'),
(3, 2, 'en', 'wordpress hosting', 'wordpress-hosting', '', '2025-10-07 13:16:56', '2025-10-07 13:16:56'),
(4, 2, 'ar', 'استضافة الورد برس', 'astdaf-ord-brs', '', '2025-10-07 13:16:56', '2025-10-07 13:16:56');

-- --------------------------------------------------------

--
-- Table structure for table `plan_translations`
--

CREATE TABLE `plan_translations` (
  `id` bigint UNSIGNED NOT NULL,
  `plan_id` bigint UNSIGNED NOT NULL,
  `locale` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `featured_label` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `features` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plan_translations`
--

INSERT INTO `plan_translations` (`id`, `plan_id`, `locale`, `title`, `description`, `featured_label`, `features`, `created_at`, `updated_at`) VALUES
(1, 1, 'ar', 'الباقة الفضة', 'ارخص استضافة مواقع', 'شائع', '{\"annual\": [{\"text\": \"التخزين 500 ميجا SSD\", \"available\": true}, {\"text\": \"الباندويث 50 جيجا\", \"available\": true}, {\"text\": \"دومين - غير متاح\", \"available\": false}, {\"text\": \"البريد الإلكتروني غير محدود\", \"available\": true}, {\"text\": \"قواعد البيانات غير محدود\", \"available\": true}, {\"text\": \"لوحة التحكم سي بانل\", \"available\": true}, {\"text\": \"شهادة الحماية SSL\", \"available\": true}, {\"text\": \"الدعم الفني 24/7\", \"available\": true}, {\"text\": \"حماية استعادة الأموال 30 يوم\", \"available\": true}], \"monthly\": [{\"text\": \"التخزين 500 ميجا SSD\", \"available\": true}, {\"text\": \"الباندويث 50 جيجا\", \"available\": true}, {\"text\": \"دومين - غير متاح\", \"available\": false}, {\"text\": \"البريد الإلكتروني غير محدود\", \"available\": true}, {\"text\": \"قواعد البيانات غير محدود\", \"available\": true}, {\"text\": \"لوحة التحكم سي بانل\", \"available\": true}, {\"text\": \"شهادة الحماية SSL\", \"available\": true}, {\"text\": \"الدعم الفني 24/7\", \"available\": true}, {\"text\": \"حماية استعادة الأموال 30 يوم\", \"available\": true}]}', '2025-10-07 13:26:14', '2025-10-09 17:54:05'),
(2, 2, 'ar', 'الباقة البرونزية', 'الحل المثالي للمبتدئين', 'شائع', '{\"annual\": [{\"text\": \"التخزين 5 جيجا SSD\", \"available\": true}, {\"text\": \"الباندويث 80 جيجا\", \"available\": true}, {\"text\": \"دومين - غير متاح\", \"available\": false}, {\"text\": \"البريد الإلكتروني غير محدود\", \"available\": true}, {\"text\": \"قواعد البيانات غير محدود\", \"available\": true}, {\"text\": \"لوحة التحكم سي بانل\", \"available\": true}, {\"text\": \"شهادة الحماية SSL\", \"available\": true}, {\"text\": \"الدعم الفني 24/7\", \"available\": true}, {\"text\": \"حماية استعادة الأموال 30 يوم\", \"available\": true}], \"monthly\": [{\"text\": \"التخزين 5 جيجا SSD\", \"available\": true}, {\"text\": \"الباندويث 80 جيجا\", \"available\": true}, {\"text\": \"دومين - غير متاح\", \"available\": false}, {\"text\": \"البريد الإلكتروني غير محدود\", \"available\": true}, {\"text\": \"قواعد البيانات غير محدود\", \"available\": true}, {\"text\": \"لوحة التحكم سي بانل\", \"available\": true}, {\"text\": \"شهادة الحماية SSL\", \"available\": true}, {\"text\": \"الدعم الفني 24/7\", \"available\": true}, {\"text\": \"حماية استعادة الأموال 30 يوم\", \"available\": true}]}', '2025-10-07 13:33:53', '2025-10-09 20:16:09'),
(3, 1, 'en', 'Silver bouquet', 'Cheapest website hosting', 'Most Popular', '{\"annual\": [{\"text\": \"500MB SSD storage\", \"available\": true}, {\"text\": \"Bandwidth 50 GB\", \"available\": true}, {\"text\": \"Domain - Not Available\", \"available\": false}, {\"text\": \"Unlimited email\", \"available\": true}, {\"text\": \"Unlimited databases\", \"available\": true}, {\"text\": \"cPanel control panel\", \"available\": true}, {\"text\": \"SSL Certificate\", \"available\": true}, {\"text\": \"24/7 technical support\", \"available\": true}, {\"text\": \"30-day money-back protection\", \"available\": true}], \"monthly\": [{\"text\": \"500MB SSD storage\", \"available\": true}, {\"text\": \"Bandwidth 50 GB\", \"available\": true}, {\"text\": \"Domain - Not Available\", \"available\": false}, {\"text\": \"Unlimited email\", \"available\": true}, {\"text\": \"Unlimited databases\", \"available\": true}, {\"text\": \"cPanel control panel\", \"available\": true}, {\"text\": \"SSL Certificate\", \"available\": true}, {\"text\": \"24/7 technical support\", \"available\": true}, {\"text\": \"30-day money-back protection\", \"available\": true}]}', '2025-10-07 13:56:15', '2025-10-09 19:37:51'),
(4, 2, 'en', 'Bronze Package', 'The perfect solution for beginners', 'Most Popular', '{\"annual\": [{\"text\": \"5GB SSD storage\", \"available\": true}, {\"text\": \"Bandwidth 80 GB\", \"available\": true}, {\"text\": \"Domain - Not Available\", \"available\": false}, {\"text\": \"Unlimited email\", \"available\": true}, {\"text\": \"Unlimited databases\", \"available\": true}, {\"text\": \"cPanel control panel\", \"available\": true}, {\"text\": \"SSL Certificate\", \"available\": true}, {\"text\": \"24/7 technical support\", \"available\": true}, {\"text\": \"30-day money-back protection\", \"available\": true}], \"monthly\": [{\"text\": \"5GB SSD storage\", \"available\": true}, {\"text\": \"Bandwidth 80 GB\", \"available\": true}, {\"text\": \"Domain - Not Available\", \"available\": false}, {\"text\": \"Unlimited email\", \"available\": true}, {\"text\": \"Unlimited databases\", \"available\": true}, {\"text\": \"cPanel control panel\", \"available\": true}, {\"text\": \"SSL Certificate\", \"available\": true}, {\"text\": \"24/7 technical support\", \"available\": true}, {\"text\": \"30-day money-back protection\", \"available\": true}]}', '2025-10-07 14:46:09', '2025-10-09 19:35:38'),
(5, 3, 'ar', 'الباقة الذهبية', 'خطة مثالية للمواقع الشخصية', NULL, '{\"annual\": [{\"text\": \"التخزين 10 جيجا SSD\", \"available\": true}, {\"text\": \"الباندويث 100 جيجا\", \"available\": true}, {\"text\": \"دومين مجاني - سنة\", \"available\": true}, {\"text\": \"البريد الإلكتروني غير محدود\", \"available\": true}, {\"text\": \"قواعد البيانات غير محدود\", \"available\": true}, {\"text\": \"لوحة التحكم سي بانل\", \"available\": true}, {\"text\": \"شهادة الحماية SSL\", \"available\": true}, {\"text\": \"الدعم الفني 24/7\", \"available\": true}, {\"text\": \"حماية استعادة الأموال 30 يوم\", \"available\": true}], \"monthly\": [{\"text\": \"التخزين 10 جيجا SSD\", \"available\": true}, {\"text\": \"الباندويث 100 جيجا\", \"available\": true}, {\"text\": \"دومين مجاني - سنة\", \"available\": true}, {\"text\": \"البريد الإلكتروني غير محدود\", \"available\": true}, {\"text\": \"قواعد البيانات غير محدود\", \"available\": true}, {\"text\": \"لوحة التحكم سي بانل\", \"available\": true}, {\"text\": \"شهادة الحماية SSL\", \"available\": true}, {\"text\": \"الدعم الفني 24/7\", \"available\": true}, {\"text\": \"حماية استعادة الأموال 30 يوم\", \"available\": true}]}', '2025-10-09 19:24:47', '2025-10-09 19:29:44'),
(6, 3, 'en', 'Golden Package', 'Perfect plan for personal websites', NULL, '{\"annual\": [{\"text\": \"10GB SSD storage\", \"available\": true}, {\"text\": \"Bandwidth 100 GB\", \"available\": true}, {\"text\": \"Free domain - 1 year\", \"available\": true}, {\"text\": \"Unlimited email\", \"available\": true}, {\"text\": \"Unlimited databases\", \"available\": true}, {\"text\": \"cPanel control panel\", \"available\": true}, {\"text\": \"SSL Certificate\", \"available\": true}, {\"text\": \"24/7 technical support\", \"available\": true}, {\"text\": \"30-day money-back protection\", \"available\": true}], \"monthly\": [{\"text\": \"10GB SSD storage\", \"available\": true}, {\"text\": \"Bandwidth 100 GB\", \"available\": true}, {\"text\": \"Free domain - 1 year\", \"available\": true}, {\"text\": \"Unlimited email\", \"available\": true}, {\"text\": \"Unlimited databases\", \"available\": true}, {\"text\": \"cPanel control panel\", \"available\": true}, {\"text\": \"SSL Certificate\", \"available\": true}, {\"text\": \"24/7 technical support\", \"available\": true}, {\"text\": \"30-day money-back protection\", \"available\": true}]}', '2025-10-09 19:38:46', '2025-10-09 19:43:53');

-- --------------------------------------------------------

--
-- Table structure for table `portfolios`
--

CREATE TABLE `portfolios` (
  `id` bigint UNSIGNED NOT NULL,
  `default_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` json DEFAULT NULL,
  `delivery_date` date NOT NULL,
  `order` int NOT NULL,
  `implementation_period_days` int DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `portfolios`
--

INSERT INTO `portfolios` (`id`, `default_image`, `images`, `delivery_date`, `order`, `implementation_period_days`, `slug`, `client`, `created_at`, `updated_at`) VALUES
(3, 'uploads/media/fJjT5UpdrZvXNueWNYSKXobNo72Nm8RP3aU5UUe1.webp', '\"[\\\"uploads/media/fJjT5UpdrZvXNueWNYSKXobNo72Nm8RP3aU5UUe1.webp\\\"]\"', '2025-10-06', 1, 10, 'alaanoan', 'شركة النجاح', '2025-10-06 17:25:01', '2025-10-06 17:25:01');

-- --------------------------------------------------------

--
-- Table structure for table `portfolio_translations`
--

CREATE TABLE `portfolio_translations` (
  `id` bigint UNSIGNED NOT NULL,
  `portfolio_id` bigint UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `materials` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `portfolio_translations`
--

INSERT INTO `portfolio_translations` (`id`, `portfolio_id`, `locale`, `title`, `description`, `type`, `materials`, `link`, `status`, `created_at`, `updated_at`) VALUES
(9, 3, 'en', 'العنوان', 'الوصف', 'النوع', 'المواد', 'الرابط', 'Completed', '2025-10-06 17:25:01', '2025-10-06 17:25:01'),
(10, 3, 'ar', 'تصميم وتطوير موقع مؤسسة مروان', 'تم تنفيذ هذا المشروع باحترافية عالية باستخدام أحدث تقنيات تطوير المواقع وتصميم واجهات المستخدم، مع مراعاة تجربة المستخدم وسرعة الأداء. يشمل الموقع لوحة تحكم مخصصة، دعم متعدد اللغات، وتكامل مع وسائل الدفع الإلكتروني.', 'النوع', 'تصميم واجهات', 'http://127.0.0.1:8000/admin/portfolios/create', 'مكتمل', '2025-10-06 17:25:01', '2025-10-06 17:25:01');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `role_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `ability` enum('allow','deny') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'deny'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` bigint UNSIGNED NOT NULL,
  `page_id` bigint UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `page_id`, `key`, `order`, `created_at`, `updated_at`) VALUES
(2, 1, 'hero', 1, '2025-09-28 18:06:07', '2025-09-28 18:06:07'),
(3, 1, 'features', 2, '2025-10-02 20:04:30', '2025-10-02 20:04:30'),
(4, 1, 'services', 3, '2025-10-02 20:05:03', '2025-10-02 20:05:03'),
(5, 1, 'templates', 4, '2025-10-02 20:05:36', '2025-10-02 20:05:36'),
(7, 1, 'home-works', 5, '2025-10-02 20:07:36', '2025-10-02 20:07:36'),
(8, 1, 'testimonials', 6, '2025-10-02 20:08:28', '2025-10-02 20:08:28'),
(9, 1, 'blog', 7, '2025-10-02 20:09:01', '2025-10-02 20:09:01'),
(10, 3, 'banner', 1, '2025-10-03 15:28:56', '2025-10-03 15:28:56'),
(11, 3, 'hosting-plans', 2, '2025-10-03 15:30:22', '2025-10-03 15:30:22'),
(12, 5, 'search-domain', 1, '2025-10-06 16:01:39', '2025-10-06 16:01:39'),
(13, 6, 'banner', 1, '2025-10-06 16:15:52', '2025-10-06 16:15:52'),
(14, 6, 'works', 2, '2025-10-06 16:16:10', '2025-10-06 16:16:10');

-- --------------------------------------------------------

--
-- Table structure for table `section_translations`
--

CREATE TABLE `section_translations` (
  `id` bigint UNSIGNED NOT NULL,
  `section_id` bigint UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `section_translations`
--

INSERT INTO `section_translations` (`id`, `section_id`, `locale`, `title`, `content`, `created_at`, `updated_at`) VALUES
(1, 2, 'en', '', '{\"hero\": [], \"subtitle\": \"\", \"button_url-1\": \"\", \"button_url-2\": \"\", \"button_text-1\": \"\", \"button_text-2\": \"\"}', '2025-10-02 20:04:18', '2025-10-02 20:04:18'),
(2, 2, 'ar', 'أطلق موقعك الخاص خلال 5 دقائق وبأقل تكلفة', '{\"hero\": [], \"subtitle\": \"أنشئ موقع احترافي بسرعة على أقوى منصة عربية لتصميم المواقع، مع لوحة تحكم كاملة، ونطاق واستضافة مجانية.\", \"button_url-1\": \"#\", \"button_url-2\": \"#\", \"button_text-1\": \"ابدأ الآن مجانًا\", \"button_text-2\": \"استعرض القوالب\"}', '2025-10-02 20:04:18', '2025-10-02 20:04:18'),
(3, 2, 'fr', '', '{\"hero\": [], \"subtitle\": \"\", \"button_url-1\": \"\", \"button_url-2\": \"\", \"button_text-1\": \"\", \"button_text-2\": \"\"}', '2025-10-02 20:04:18', '2025-10-02 20:04:18'),
(4, 3, 'en', '', '{\"features\": [], \"subtitle\": \"\"}', '2025-10-02 20:04:30', '2025-10-03 05:54:07'),
(5, 3, 'ar', 'لماذا تختار بال قول ؟', '{\"features\": [{\"icon\": \"<svg xmlns=\\\"http://www.w3.org/2000/svg\\\" fill=\\\"none\\\" viewBox=\\\"0 0 24 24\\\" stroke-width=\\\"1.5\\\" stroke=\\\"currentColor\\\" class=\\\"w-6 h-6 text-pretty\\\">                   <path stroke-linecap=\\\"round\\\" stroke-linejoin=\\\"round\\\" d=\\\"M15.59 14.37a6 6 0 0 1-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 0 0 6.16-12.12A14.98 14.98 0 0 0 9.631 8.41m5.96 5.96a14.926 14.926 0 0 1-5.841 2.58m-.119-8.54a6 6 0 0 0-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 0 0-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 0 1-2.448-2.448 14.9 14.9 0 0 1 .06-.312m-2.24 2.39a4.493 4.493 0 0 0-1.757 4.306 4.493 4.493 0 0 0 4.306-1.758M16.5 9a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Z\\\"></path>                 </svg>\", \"title\": \"إطلاق سريع\", \"description\": \"اطلق موقعك خلال دقائق، دون أي تعقيد تقني.\"}, {\"icon\": \"<svg xmlns=\\\"http://www.w3.org/2000/svg\\\" fill=\\\"none\\\" viewBox=\\\"0 0 24 24\\\" stroke-width=\\\"1.5\\\" stroke=\\\"currentColor\\\" class=\\\"w-6 h-6 text-primary\\\">                   <path stroke-linecap=\\\"round\\\" stroke-linejoin=\\\"round\\\" d=\\\"M8.625 9.75a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375m-13.5 3.01c0 1.6 1.123 2.994 2.707 3.227 1.087.16 2.185.283 3.293.369V21l4.184-4.183a1.14 1.14 0 0 1 .778-.332 48.294 48.294 0 0 0 5.83-.498c1.585-.233 2.708-1.626 2.708-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0 0 12 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018Z\\\"></path>                 </svg>\", \"title\": \"دعم فني متواصل\", \"description\": \"نرافقك خطوة بخطوة، بفريق جاهز دائمًا لمساعدتك.\"}, {\"icon\": \"<svg xmlns=\\\"http://www.w3.org/2000/svg\\\" fill=\\\"none\\\" viewBox=\\\"0 0 24 24\\\" stroke-width=\\\"1.5\\\" stroke=\\\"currentColor\\\" class=\\\"w-6 h-6 text-primary\\\">                   <path stroke-linecap=\\\"round\\\" stroke-linejoin=\\\"round\\\" d=\\\"M3.75 3v11.25A2.25 2.25 0 0 0 6 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0 1 18 16.5h-2.25m-7.5 0h7.5m-7.5 0-1 3m8.5-3 1 3m0 0 .5 1.5m-.5-1.5h-9.5m0 0-.5 1.5m.75-9 3-3 2.148 2.148A12.061 12.061 0 0 1 16.5 7.605\\\"></path>                 </svg>\", \"title\": \"لوحة تحكم سهلة\", \"description\": \"تحكم في كل تفاصيل موقعك بسهولة من خلال واجهة مريحة وسريعة.\"}, {\"icon\": \"<svg xmlns=\\\"http://www.w3.org/2000/svg\\\" fill=\\\"none\\\" viewBox=\\\"0 0 24 24\\\" stroke-width=\\\"1.5\\\" stroke=\\\"currentColor\\\" class=\\\"w-6 h-6 text-primary\\\">                   <path stroke-linecap=\\\"round\\\" stroke-linejoin=\\\"round\\\" d=\\\"M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z\\\"></path>                 </svg>\", \"title\": \"أمان وموثوقية\", \"description\": \"نحمي بياناتك بأعلى معايير الأمان ونسخ احتياطي مستمر.\"}, {\"icon\": \"<svg xmlns=\\\"http://www.w3.org/2000/svg\\\" fill=\\\"none\\\" viewBox=\\\"0 0 24 24\\\" stroke-width=\\\"1.5\\\" stroke=\\\"currentColor\\\" class=\\\"w-6 h-6 text-primary\\\">                   <path stroke-linecap=\\\"round\\\" stroke-linejoin=\\\"round\\\" d=\\\"M10.5 1.5H8.25A2.25 2.25 0 0 0 6 3.75v16.5a2.25 2.25 0 0 0 2.25 2.25h7.5A2.25 2.25 0 0 0 18 20.25V3.75a2.25 2.25 0 0 0-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 18.75h3\\\"></path>                 </svg>\", \"title\": \"تصميم متجاوب\", \"description\": \"موقعك يظهر بأفضل شكل على الجوال، التابلت، والكمبيوتر.\"}, {\"icon\": \"<svg xmlns=\\\"http://www.w3.org/2000/svg\\\" fill=\\\"none\\\" viewBox=\\\"0 0 24 24\\\" stroke-width=\\\"1.5\\\" stroke=\\\"currentColor\\\" class=\\\"w-6 h-6 text-primary\\\">                   <path stroke-linecap=\\\"round\\\" stroke-linejoin=\\\"round\\\" d=\\\"m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z\\\"></path>                 </svg>\", \"title\": \"تحسين محركات البحث\", \"description\": \"هيكلية مدروسة تساعد موقعك في الظهور على Google وجذب الزوار.\"}], \"subtitle\": \"نقدّم لك كل ما تحتاجه لإطلاق موقع احترافي بكل سهولة – من الاستضافة والدومين إلى التصميم والدعم، في مكان واحد وبسرعة.\"}', '2025-10-02 20:04:30', '2025-10-03 05:54:07'),
(6, 3, 'fr', '', '{\"features\": [], \"subtitle\": \"\"}', '2025-10-02 20:04:30', '2025-10-03 05:54:07'),
(7, 4, 'en', '', '{\"services\": [], \"subtitle\": \"\"}', '2025-10-02 20:05:03', '2025-10-02 20:05:22'),
(8, 4, 'ar', 'خدمات رقمية متكاملة تنطلق بك نحو النجاح', '{\"services\": [], \"subtitle\": \"كل ما تحتاجه لبناء مشروعك الرقمي بنجاح: تصميم احترافي، استضافة سريعة، تسويق فعّال، ودعم فني مستمر – حلول متكاملة من فريق واحد.\"}', '2025-10-02 20:05:03', '2025-10-02 20:05:22'),
(9, 4, 'fr', '', '{\"services\": [], \"subtitle\": \"\"}', '2025-10-02 20:05:03', '2025-10-02 20:05:22'),
(10, 5, 'en', '', '{\"subtitle\": \"\", \"templates\": []}', '2025-10-02 20:05:36', '2025-10-02 20:06:03'),
(11, 5, 'ar', 'قوالب ووردبريس احترافية مع استضافة ودومين', '{\"subtitle\": \"احصل على موقع متكامل خلال دقائق باختيار قالب احترافي يشمل الاستضافة والدومين والدعم الفني.\", \"templates\": []}', '2025-10-02 20:05:36', '2025-10-02 20:06:03'),
(12, 5, 'fr', '', '{\"subtitle\": \"\", \"templates\": []}', '2025-10-02 20:05:36', '2025-10-02 20:06:03'),
(16, 7, 'en', '', '{\"subtitle\": \"\", \"homeWorks\": [], \"button_url-1\": \"\", \"button_text-1\": \"\"}', '2025-10-02 20:07:36', '2025-10-02 20:08:13'),
(17, 7, 'ar', 'أحدث أعمالنا', '{\"subtitle\": \"نعتز بثقة أكثر من 1000 عميل أطلقوا مواقعهم الإلكترونية معنا، وها هي نماذج حقيقية من مشاريع نفذناها باحترافية.\", \"homeWorks\": [], \"button_url-1\": \"#\", \"button_text-1\": \"مشاهدة المزيد\"}', '2025-10-02 20:07:36', '2025-10-02 20:08:13'),
(18, 7, 'fr', '', '{\"subtitle\": \"\", \"homeWorks\": [], \"button_url-1\": \"\", \"button_text-1\": \"\"}', '2025-10-02 20:07:36', '2025-10-02 20:08:13'),
(19, 8, 'en', '', '{\"subtitle\": \"\", \"testimonials\": []}', '2025-10-02 20:08:28', '2025-10-02 20:08:44'),
(20, 8, 'ar', 'ماذا يقول عملاؤنا عن Palgoals؟', '{\"subtitle\": \"إليك آراء حقيقية من عملائنا حول خدمات تصميم المواقع واستضافة Palgoals، حيث صنعنا الفرق في أعمالهم الرقمية.\", \"testimonials\": []}', '2025-10-02 20:08:28', '2025-10-02 20:08:44'),
(21, 8, 'fr', '', '{\"subtitle\": \"\", \"testimonials\": []}', '2025-10-02 20:08:28', '2025-10-02 20:08:44'),
(22, 9, 'en', '', '{\"blogs\": [], \"subtitle\": \"\", \"button_url-1\": \"\", \"button_text-1\": \"\"}', '2025-10-02 20:09:01', '2025-10-02 20:09:35'),
(23, 9, 'ar', 'أحدث من المدونة', '{\"blogs\": [], \"subtitle\": \"أدوات ونصائح تساعدك على تطوير أعمالك الرقمية والبقاء على اطلاع بأحدث الاتجاهات\", \"button_url-1\": \"#\", \"button_text-1\": \"مشاهدة المزيد\"}', '2025-10-02 20:09:01', '2025-10-02 20:09:35'),
(24, 9, 'fr', '', '{\"blogs\": [], \"subtitle\": \"\", \"button_url-1\": \"\", \"button_text-1\": \"\"}', '2025-10-02 20:09:01', '2025-10-02 20:09:35'),
(25, 10, 'en', 'Launch your site now with blazing-fast, reliable hosting.', '{\"banners\": [], \"subtitle\": \"Enjoy shared hosting that combines high performance, top-tier security, and 24/7 expert support — the ultimate solution for website owners and online stores.\"}', '2025-10-03 15:28:56', '2025-10-10 05:34:24'),
(26, 10, 'ar', 'ابدأ موقعك الآن مع استضافة موثوقة وسريعة', '{\"banners\": [], \"subtitle\": \"تع بخدمة استضافة مشتركة تجمع بين الأداء العالي، الأمان، والدعم الفني المتواصل – الحل الأمثل لأصحاب المواقع والمتاجر الإلكترونية.\"}', '2025-10-03 15:28:56', '2025-10-10 05:34:24'),
(27, 10, 'fr', '', '{\"banners\": [], \"subtitle\": \"\"}', '2025-10-03 15:28:56', '2025-10-03 15:29:25'),
(28, 11, 'en', 'Pricing that grows with you.', '{\"subtitle\": \"Choose the right plan and start your journey with powerful performance, advanced features, and continuous support.\", \"hosting-plans\": [], \"plan_category_id\": 1, \"plan_category_slug\": null}', '2025-10-03 15:30:22', '2025-10-10 16:27:42'),
(29, 11, 'ar', 'التسعير الذي ينمو معك', '{\"subtitle\": \"اختر الخطة المناسبة وابدأ رحلتك معنا بأداء قوي، وميزات متقدمة، ودعم متواصل.\", \"hosting-plans\": [], \"plan_category_id\": 1, \"plan_category_slug\": null}', '2025-10-03 15:30:22', '2025-10-10 16:50:23'),
(30, 11, 'fr', '', '{\"subtitle\": \"\", \"hosting-plans\": [], \"plan_category_id\": null, \"plan_category_slug\": null}', '2025-10-03 15:30:22', '2025-10-03 15:30:44'),
(31, 12, 'en', '', '[]', '2025-10-06 16:01:39', '2025-10-06 16:01:39'),
(32, 12, 'ar', '', '[]', '2025-10-06 16:01:39', '2025-10-06 16:01:39'),
(33, 12, 'fr', '', '[]', '2025-10-06 16:01:39', '2025-10-06 16:01:39'),
(34, 12, 'aa', '', '[]', '2025-10-06 16:01:39', '2025-10-06 16:01:39'),
(35, 13, 'en', '', '{\"banners\": [], \"subtitle\": \"\"}', '2025-10-06 16:15:52', '2025-10-06 16:18:12'),
(36, 13, 'ar', ' أعمالنا الرقمية المميزة', '{\"banners\": [], \"subtitle\": \"استكشف مجموعة من المشاريع الرقمية التي نفذناها باحترافية عالية وجودة تصميم متقدمة لعملائنا في مختلف القطاعات.\"}', '2025-10-06 16:15:52', '2025-10-06 16:18:12'),
(37, 13, 'fr', '', '{\"banners\": [], \"subtitle\": \"\"}', '2025-10-06 16:15:52', '2025-10-06 16:18:12'),
(38, 13, 'aa', '', '{\"banners\": [], \"subtitle\": \"\"}', '2025-10-06 16:15:52', '2025-10-06 16:18:12'),
(39, 14, 'en', '', '{\"works\": [], \"subtitle\": \"\"}', '2025-10-06 16:16:10', '2025-10-06 16:18:39'),
(40, 14, 'ar', 'أحدث أعمالنا', '{\"works\": [], \"subtitle\": \"استعرض بعضاً من المشاريع التي قمنا بتنفيذها بجودة عالية وتصاميم مخصصة.\"}', '2025-10-06 16:16:10', '2025-10-06 16:18:39'),
(41, 14, 'fr', '', '{\"works\": [], \"subtitle\": \"\"}', '2025-10-06 16:16:10', '2025-10-06 16:18:39'),
(42, 14, 'aa', '', '{\"works\": [], \"subtitle\": \"\"}', '2025-10-06 16:16:10', '2025-10-06 16:18:39');

-- --------------------------------------------------------

--
-- Table structure for table `servers`
--

CREATE TABLE `servers` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cpanel',
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hostname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` text COLLATE utf8mb4_unicode_ci,
  `api_token` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `servers`
--

INSERT INTO `servers` (`id`, `name`, `type`, `ip`, `hostname`, `username`, `password`, `api_token`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'server.palgoals.com', 'cpanel', '5.9.172.153', 'server.palgoals.com', 'root', 'eyJpdiI6Iisrc1ZtaWhMME41eUQyR3FXbGRzNFE9PSIsInZhbHVlIjoiV09HclhqTGFMQVhOTXptUGNPVW5wclhCVHNjZzBDSnAvMk5ZeVBzNW1GZz0iLCJtYWMiOiIzYjAyNzEwY2Y5Mzk0Njk4NmIxYTBmOWI4NDE4ZjE5ZjRkODc4YTI5MTg5MzFlYTMwNTdlMjZhZDVhNGIxNDcyIiwidGFnIjoiIn0=', 'eyJpdiI6IkpTVk52M0tXZU83Y0trRkN0c1JjUVE9PSIsInZhbHVlIjoiZTl1SU9IdDdDRU9CUGkrREU0c2pWV2l5TGN2VkltUmNPWEVQc2FzMGVNWmdEalZ0S0s1SnhuUTJpcyt3OCtlYiIsIm1hYyI6IjZiODYyNmQ1ZDhlZTUxOGYwNmE4ZjQ1MzRkODBlMjA4OTU5MWY4OGEyYjM1MjBkMWQ2MjJjZjI5MTAzOTI5YzMiLCJ0YWciOiIifQ==', 1, '2025-10-07 13:22:59', '2025-10-07 13:22:59');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` bigint UNSIGNED NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int NOT NULL DEFAULT '0',
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `icon`, `order`, `url`, `created_at`, `updated_at`) VALUES
(1, 'uploads/media/VUHu0tzH7Nqw62EjPHhTbgSwSUWljS2UKeiCTOmP.svg', 0, NULL, '2025-09-27 20:22:44', '2025-10-05 19:19:49'),
(2, 'uploads/media/oqbfc1usigcKkvxz2Vh0wyhEy36BJiIY9Ypm3Cei.svg', 1, '#', '2025-09-27 20:22:44', '2025-10-05 19:20:42'),
(3, 'uploads/media/KtrgSQawLbZ9bVyMA7GaxgEKg7MnkVMeDDy9Gr3R.svg', 2, NULL, '2025-09-27 20:22:44', '2025-10-05 19:21:29'),
(4, 'uploads/media/ngFFGMVwWGofl18z4Uk1zrDttaMZ3lpzXIfHAM7n.svg', 3, NULL, '2025-09-27 20:22:44', '2025-10-05 19:22:11'),
(5, 'uploads/media/IaJe7QmqscpjDfTigh85dEUOXpbEwL37QNzJvZKR.svg', 4, NULL, '2025-09-27 20:22:44', '2025-10-05 19:22:30');

-- --------------------------------------------------------

--
-- Table structure for table `service_translations`
--

CREATE TABLE `service_translations` (
  `id` bigint UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_translations`
--

INSERT INTO `service_translations` (`id`, `locale`, `title`, `description`, `service_id`, `created_at`, `updated_at`) VALUES
(1, 'ar', 'الاستضافة المشتركة', 'استضافة قوية واقتصادية لموقعك، مع شهادة SSL مجانية وسرعة تشغيل عالية.', 1, '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(2, 'en', 'Website Design', 'Responsive and custom designs that reflect your brand and give a professional user experience.', 1, '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(3, 'ar', 'استضافة ووردبريس', 'احجز اسم موقعك بسهولة واختر من بين مجموعة واسعة من الامتدادات العالمية.', 2, '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(4, 'en', 'WordPress Hosting', 'Easily register your domain name and choose from a wide variety of global extensions.', 2, '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(5, 'ar', 'حجز اسم نطاق (دومين)', 'تمتع بأداء عالٍ وأمان كامل لموقعك على ووردبريس مع دعم فني دائم.', 3, '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(6, 'en', 'Domain name reservation', 'High-performance and secure hosting for your WordPress site with full-time support.', 3, '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(7, 'ar', 'تصميم مواقع', 'استضافة قوية واقتصادية لموقعك، مع شهادة SSL مجانية وسرعة تشغيل عالية.', 4, '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(8, 'en', 'Website design', 'Reliable and affordable hosting with free SSL and fast performance.', 4, '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(9, 'ar', 'برمجيات خاصة', 'استضافة قوية واقتصادية لموقعك، مع شهادة SSL مجانية وسرعة تشغيل عالية.', 5, '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(10, 'en', 'Special software', 'Reliable and affordable hosting with free SSL and fast performance.', 5, '2025-09-27 20:22:44', '2025-09-27 20:22:44');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('j5ssU87rjA29jvIhaIlbIzr6soGKoqg9WySFqZFU', 11, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoiWkx1Y01mRWVzUGd6UHdzYTExVHZIdWI4aG45eUsxSGVBZzl4Z3U1TiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE5OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYXBpL2RvbWFpbnMvY2hlY2s/ZG9tYWlucz1hY3RuY25taGJpby5jb20lMkNhY3RuY25taGIuY29tJTJDYWN0bmNubWhiaHViLmNvbSUyQ2FjdG5jbm1oYm1lZGlhLmNvbSUyQ2FjdG5jbm1oYmx5LmNvbSUyQ2FjdGlvbmNpbmVtYWh1YmFpLmNvbSUyQ2FjdGlvbmNpbmVtYWh1YmFseS5jb20lMkNhY3Rpb25jaW5lbWFodWJpZnkuY29tJTJDYWN0aW9uY2luZW1haHViaW8uY29tJTJDYWN0aW9uY2luZW1haHVibHkuY29tJTJDYWN0bmNubWhiZGV2LmNvbSUyQ2FjdGlvbmNpbmVtYWh1YmRldi5jb20mdD0xNzYwNDgzMTc5Njc5Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTE7czoyMToicGFsZ29hbHNfY2FydF9kb21haW5zIjthOjE6e2k6MDthOjM6e3M6NjoiZG9tYWluIjtzOjE5OiJhY3Rpb25jaW5lbWFodWIuY29tIjtzOjY6Im9wdGlvbiI7czo4OiJyZWdpc3RlciI7czoxMToicHJpY2VfY2VudHMiO3M6MToiMCI7fX1zOjUzOiJsb2dpbl9jbGllbnRfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTo0O30=', 1760483180);

-- --------------------------------------------------------

--
-- Table structure for table `sites`
--

CREATE TABLE `sites` (
  `id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `domain_id` bigint UNSIGNED NOT NULL,
  `plan_id` bigint UNSIGNED NOT NULL,
  `subscription_id` bigint UNSIGNED NOT NULL,
  `provisioning_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpanel_username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpanel_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpanel_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provisioned_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `plan_id` bigint UNSIGNED NOT NULL,
  `status` enum('pending','active','suspended','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `billing_cycle` enum('monthly','annually') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'annually',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `server_id` bigint UNSIGNED DEFAULT NULL,
  `server_package` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_due_date` date DEFAULT NULL,
  `starts_at` date DEFAULT NULL,
  `ends_at` date DEFAULT NULL,
  `domain_option` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `domain_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `last_sync_message` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `client_id`, `plan_id`, `status`, `billing_cycle`, `price`, `username`, `server_id`, `server_package`, `next_due_date`, `starts_at`, `ends_at`, `domain_option`, `domain_name`, `created_at`, `updated_at`, `last_sync_message`) VALUES
(1, 3, 1, 'pending', 'annually', 0.75, NULL, 1, NULL, '2025-11-10', '2025-10-10', NULL, 'new', '5555.palgoals.com', '2025-10-10 17:35:16', '2025-10-10 17:35:16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE `templates` (
  `id` bigint UNSIGNED NOT NULL,
  `category_template_id` bigint UNSIGNED NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` double NOT NULL DEFAULT '0',
  `rating_count` int UNSIGNED NOT NULL DEFAULT '0',
  `rating_avg` decimal(3,2) NOT NULL DEFAULT '0.00',
  `discount_price` decimal(10,2) DEFAULT NULL,
  `discount_ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `plan_id` bigint UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template_reviews`
--

CREATE TABLE `template_reviews` (
  `id` bigint UNSIGNED NOT NULL,
  `template_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `client_id` bigint UNSIGNED DEFAULT NULL,
  `author_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` tinyint UNSIGNED NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template_translations`
--

CREATE TABLE `template_translations` (
  `id` bigint UNSIGNED NOT NULL,
  `template_id` bigint UNSIGNED NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `preview_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `translation_values`
--

CREATE TABLE `translation_values` (
  `id` bigint UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `translation_values`
--

INSERT INTO `translation_values` (`id`, `key`, `locale`, `value`, `created_at`, `updated_at`) VALUES
(1, 'frontend.page_default_title', 'ar', 'Untitled Page', '2025-09-27 20:22:48', '2025-09-27 20:22:48'),
(2, 'General.palgoals', 'ar', 'palgoals', '2025-09-27 20:22:49', '2025-09-27 20:22:49'),
(3, 'General.goals', 'ar', 'discretion', '2025-09-27 20:22:49', '2025-09-27 20:22:49'),
(4, 'dashboard.features_title', 'ar', '', '2025-09-27 20:22:49', '2025-09-27 20:22:49'),
(5, 'frontend.page_default_title', 'en', 'Untitled Page', '2025-09-27 20:22:56', '2025-09-27 20:22:56'),
(6, 'General.palgoals', 'en', 'palgoals', '2025-09-27 20:22:56', '2025-09-27 20:22:56'),
(7, 'General.goals', 'en', 'discretion', '2025-09-27 20:22:56', '2025-09-27 20:22:56'),
(8, 'dashboard.features_title', 'en', '', '2025-09-27 20:22:56', '2025-09-27 20:22:56'),
(9, 'dashboard.Home', 'en', 'Home', '2025-09-27 20:23:09', '2025-09-27 20:23:09'),
(10, 'dashboard.Home', 'ar', 'الرئيسية', '2025-09-27 20:23:09', '2025-10-10 17:38:03'),
(11, 'dashboard.All_Pages', 'en', 'ALL Pages', '2025-09-27 20:23:09', '2025-09-27 20:23:09'),
(12, 'dashboard.All_Pages', 'ar', 'ALL Pages', '2025-09-27 20:23:09', '2025-09-27 20:23:09'),
(13, 'dashboard.Add_Page', 'en', 'Add Page', '2025-09-27 20:23:09', '2025-09-27 20:23:09'),
(14, 'dashboard.Add_Page', 'ar', 'Add Page', '2025-09-27 20:23:09', '2025-09-27 20:23:09'),
(15, 'dashboard.Title', 'en', 'Title', '2025-09-27 20:23:09', '2025-09-27 20:23:09'),
(16, 'dashboard.Title', 'ar', 'Title', '2025-09-27 20:23:09', '2025-09-27 20:23:09'),
(17, 'dashboard.Homepage', 'en', 'Homepage', '2025-09-27 20:23:09', '2025-09-27 20:23:09'),
(18, 'dashboard.Homepage', 'ar', 'Homepage', '2025-09-27 20:23:09', '2025-09-27 20:23:09'),
(19, 'dashboard.Status', 'en', 'Status', '2025-09-27 20:23:09', '2025-09-27 20:23:09'),
(20, 'dashboard.Status', 'ar', 'Status', '2025-09-27 20:23:09', '2025-09-27 20:23:09'),
(21, 'dashboard.Date', 'en', 'Date', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(22, 'dashboard.Date', 'ar', 'Date', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(23, 'dashboard.Action', 'en', 'Action', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(24, 'dashboard.Action', 'ar', 'Action', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(25, 'dashboard.Current_Homepage', 'en', 'Current Homepage', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(26, 'dashboard.Current_Homepage', 'ar', 'Current Homepage', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(27, 'dashboard.My_Account', 'en', 'My Account', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(28, 'dashboard.My_Account', 'ar', 'My Account', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(29, 'dashboard.Settings', 'en', 'Settings', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(30, 'dashboard.Settings', 'ar', 'Settings', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(31, 'dashboard.Logout', 'en', 'Logout', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(32, 'dashboard.Logout', 'ar', 'Logout', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(33, 'dashboard.Navigation', 'en', 'Navigation', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(34, 'dashboard.Navigation', 'ar', 'Navigation', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(35, 'dashboard.Pages', 'en', 'Pages', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(36, 'dashboard.Pages', 'ar', 'Pages', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(37, 'dashboard.Template_management', 'en', 'Template management', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(38, 'dashboard.Template_management', 'ar', 'Template management', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(39, 'dashboard.All_templates', 'en', 'All templates', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(40, 'dashboard.All_templates', 'ar', 'All templates', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(41, 'dashboard.Categories', 'en', 'Categories', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(42, 'dashboard.Categories', 'ar', 'Categories', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(43, 'dashboard.reviews', 'en', 'reviews', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(44, 'dashboard.reviews', 'ar', 'reviews', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(45, 'dashboard.services', 'en', 'services', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(46, 'dashboard.services', 'ar', 'services', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(47, 'dashboard.feedbacks', 'en', 'testimonial', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(48, 'dashboard.feedbacks', 'ar', 'testimonial', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(49, 'dashboard.portfolios', 'en', 'portfolios', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(50, 'dashboard.portfolios', 'ar', 'portfolios', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(51, 'dashboard.clients', 'en', 'clients', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(52, 'dashboard.clients', 'ar', 'clients', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(53, 'dashboard.domains', 'en', 'domains', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(54, 'dashboard.domains', 'ar', 'domains', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(55, 'dashboard.plans', 'en', 'plans', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(56, 'dashboard.plans', 'ar', 'plans', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(57, 'dashboard.plan-categories', 'en', 'plan categories', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(58, 'dashboard.plan-categories', 'ar', 'plan categories', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(59, 'dashboard.subscriptions', 'en', 'subscriptions', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(60, 'dashboard.subscriptions', 'ar', 'subscriptions', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(61, 'dashboard.invoices', 'en', 'invoices', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(62, 'dashboard.invoices', 'ar', 'invoices', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(63, 'dashboard.orders', 'en', 'orders', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(64, 'dashboard.orders', 'ar', 'orders', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(65, 'dashboard.CRM_management', 'en', 'CRM management', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(66, 'dashboard.CRM_management', 'ar', 'CRM management', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(67, 'dashboard.servers', 'en', 'servers', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(68, 'dashboard.servers', 'ar', 'servers', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(69, 'dashboard.domain_providers', 'en', 'domain providers', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(70, 'dashboard.domain_providers', 'ar', 'domain providers', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(71, 'dashboard.domain-tlds', 'en', 'domain tlds', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(72, 'dashboard.domain-tlds', 'ar', 'domain tlds', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(73, 'dashboard.sync-logs', 'en', 'sync-logs', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(74, 'dashboard.sync-logs', 'ar', 'sync-logs', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(75, 'dashboard.Site_settings', 'en', 'Site settings', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(76, 'dashboard.Site_settings', 'ar', 'Site settings', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(77, 'dashboard.media', 'en', 'Media', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(78, 'dashboard.media', 'ar', 'Media', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(79, 'dashboard.Appearance', 'en', 'Appearance', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(80, 'dashboard.Appearance', 'ar', 'Appearance', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(81, 'dashboard.Menus', 'en', 'Menus', '2025-09-27 20:23:10', '2025-09-27 20:23:10'),
(82, 'dashboard.Menus', 'ar', 'Menus', '2025-09-27 20:23:11', '2025-09-27 20:23:11'),
(83, 'dashboard.languages', 'en', 'languages', '2025-09-27 20:23:11', '2025-09-27 20:23:11'),
(84, 'dashboard.languages', 'ar', 'languages', '2025-09-27 20:23:11', '2025-09-27 20:23:11'),
(85, 'dashboard.Users_show', 'en', 'Users show', '2025-09-27 20:23:11', '2025-09-27 20:23:11'),
(86, 'dashboard.Users_show', 'ar', 'Users show', '2025-09-27 20:23:11', '2025-09-27 20:23:11'),
(87, 'dashboard.Add_User', 'en', 'Add User', '2025-09-27 20:23:11', '2025-09-27 20:23:11'),
(88, 'dashboard.Add_User', 'ar', 'Add User', '2025-09-27 20:23:11', '2025-09-27 20:23:11'),
(89, 'dashboard.General_Setting', 'en', 'General Setting', '2025-09-27 20:23:11', '2025-09-27 20:23:11'),
(90, 'dashboard.General_Setting', 'ar', 'General Setting', '2025-09-27 20:23:11', '2025-09-27 20:23:11'),
(91, 'dashboard.Edit_Page', 'ar', 'Edit Page', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(92, 'dashboard.Add_Section', 'ar', 'Add Section', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(93, 'dashboard.Page_Title', 'ar', 'Page Title', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(94, 'dashboard.Slug_Hint', 'ar', 'Use lowercase letters, numbers, and dashes only. Leave empty to auto-generate for the main language.', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(95, 'dashboard.Page_Content', 'ar', 'Page Content', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(96, 'dashboard.SEO_Meta', 'ar', 'SEO Meta', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(97, 'dashboard.Meta_Title', 'ar', 'Meta Title', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(98, 'dashboard.Meta_Description', 'ar', 'Meta Description', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(99, 'dashboard.Short_Description', 'ar', 'Short description for search engines', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(100, 'dashboard.Aim_Characters', 'ar', 'Aim for 50-160 characters. Leave empty to reuse the title.', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(101, 'dashboard.Meta_Keywords', 'ar', 'Meta Keywords', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(102, 'dashboard.Separate_Keywords', 'ar', 'Separate keywords with a comma or Arabic comma (?).', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(103, 'dashboard.Open_Graph_Image_URL', 'ar', 'Open Graph Image URL', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(104, 'dashboard.Choose_from_media', 'ar', 'Choose from media', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(105, 'dashboard.Use_a_full_URL', 'ar', 'Use a full URL or a Storage link generated via asset()/Storage::url(). Recommended size 1200x630px.', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(106, 'dashboard.Preview', 'ar', 'Preview', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(107, 'dashboard.Publishing_Options', 'ar', 'Publishing Options', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(108, 'dashboard.Draft', 'ar', 'Draft', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(109, 'dashboard.Published', 'ar', 'Published', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(110, 'dashboard.Publish_Date', 'ar', 'Publish Date', '2025-09-27 20:24:33', '2025-09-27 20:24:33'),
(111, 'dashboard.Update', 'ar', 'Update', '2025-09-27 20:24:34', '2025-09-27 20:24:34'),
(112, 'dashboard.Cancel_Edit', 'ar', 'Cancel Edit', '2025-09-27 20:24:34', '2025-09-27 20:24:34'),
(113, 'section.Delete', 'ar', 'Delete', '2025-09-27 20:24:42', '2025-09-27 20:24:42'),
(114, 'section.Section_Arrangement', 'ar', 'Section Arrangement', '2025-09-27 20:24:42', '2025-09-27 20:24:42'),
(115, 'section.Example:', 'ar', 'Example: 1, 2, 3', '2025-09-27 20:24:42', '2025-09-27 20:24:42'),
(116, 'section.Title', 'ar', 'Title', '2025-09-27 20:24:42', '2025-09-27 20:24:42'),
(117, 'section.Brief_description', 'ar', 'Brief description', '2025-09-27 20:24:42', '2025-09-27 20:24:42'),
(118, 'section.First_button_text', 'ar', 'First button text', '2025-09-27 20:24:42', '2025-09-27 20:24:42'),
(119, 'section.First_button_Url', 'ar', 'First Button Url', '2025-09-27 20:24:42', '2025-09-27 20:24:42'),
(120, 'section.Second_button_text', 'ar', 'Second Button text', '2025-09-27 20:24:42', '2025-09-27 20:24:42'),
(121, 'section.Second_button_Url', 'ar', 'Second Button Url', '2025-09-27 20:24:42', '2025-09-27 20:24:42'),
(122, 'section.Save_changes', 'ar', 'Save changes', '2025-09-27 20:24:42', '2025-09-27 20:24:42'),
(123, 'dashboard.Add_Pages', 'ar', 'Add Pages', '2025-09-27 20:27:13', '2025-09-27 20:27:13'),
(124, 'dashboard.You_are_editing_the_content', 'ar', 'You are editing the :name content', '2025-09-27 20:27:14', '2025-09-27 20:27:14'),
(125, 'dashboard.Short_description_for_search_engines', 'ar', 'Short description for search engines', '2025-09-27 20:27:14', '2025-09-27 20:27:14'),
(126, 'dashboard.Aim_for_50_160_characters_Leave_empty_to_reuse_the_title', 'ar', 'Aim for 50-160 characters. Leave empty to reuse the title.', '2025-09-27 20:27:14', '2025-09-27 20:27:14'),
(127, 'dashboard.Separate_keywords_with_a_comma_or_Arabic_comma', 'ar', 'Separate keywords with a comma or Arabic comma (?).', '2025-09-27 20:27:14', '2025-09-27 20:27:14'),
(128, 'dashboard.Use_a_full_URL_or_a_Storage_link_generated_via_asset_Storage_url_Recommended_size_1200x630px', 'ar', 'Use a full URL or a Storage link generated via asset()/Storage::url(). Recommended size 1200x630px.', '2025-09-27 20:27:14', '2025-09-27 20:27:14'),
(129, 'dashboard.Publish', 'ar', 'Publish', '2025-09-27 20:27:14', '2025-09-27 20:27:14'),
(130, 'dashboard.Saving', 'ar', 'Saving...', '2025-09-27 20:27:14', '2025-09-27 20:27:14'),
(131, 'dashboard.Make_Homepage', 'ar', 'Make Homepage', '2025-09-27 20:27:49', '2025-09-27 20:27:49'),
(132, 'dashboard.Languages_List', 'ar', 'Languages List', '2025-09-28 15:43:06', '2025-09-28 15:43:06'),
(133, 'dashboard.Add_Languages', 'ar', 'Add Languages', '2025-09-28 15:43:06', '2025-09-28 15:43:06'),
(134, 'dashboard.Name', 'ar', 'Name', '2025-09-28 15:43:06', '2025-09-28 15:43:06'),
(135, 'dashboard.Native_Name', 'ar', 'Native Name', '2025-09-28 15:43:06', '2025-09-28 15:43:06'),
(136, 'dashboard.Code', 'ar', 'Code', '2025-09-28 15:43:06', '2025-09-28 15:43:06'),
(137, 'dashboard.Flag', 'ar', 'Flag', '2025-09-28 15:43:06', '2025-09-28 15:43:06'),
(138, 'dashboard.RTL', 'ar', 'RTL', '2025-09-28 15:43:06', '2025-09-28 15:43:06'),
(139, 'dashboard.Actiont', 'ar', 'Action', '2025-09-28 15:43:06', '2025-09-28 15:43:06'),
(140, 'dashboard.languages_edit', 'ar', 'Languages Edit', '2025-09-28 15:43:06', '2025-09-28 15:43:06'),
(141, 'dashboard.All_Menus', 'ar', 'ALL Menus', '2025-09-28 15:44:43', '2025-09-28 15:44:43'),
(142, 'dashboard.Translation_Values', 'ar', 'Translation Values', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(143, 'dashboard.Add_New_Translation', 'ar', 'Add New Translation', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(144, 'dashboard.All_Languages', 'ar', 'All Languages', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(145, 'dashboard.All_Types', 'ar', 'All Types', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(146, 'dashboard.Dashboard', 'ar', 'Dashboard', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(147, 'dashboard.Frontend', 'ar', 'Frontend', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(148, 'dashboard.General', 'ar', 'General', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(149, 'dashboard.Search_keys...', 'ar', 'Search keys...', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(150, 'dashboard.Search', 'ar', 'Search', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(151, 'dashboard.Reset', 'ar', 'Reset', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(152, 'dashboard.Export_CSV', 'ar', 'Export CSV', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(153, 'dashboard.Import_CSV', 'ar', 'Import CSV', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(154, 'dashboard.Key', 'ar', 'Key', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(155, 'dashboard.Value', 'ar', 'Value', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(156, 'dashboard.Type', 'ar', 'Type', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(157, 'dashboard.edit_translation', 'ar', 'Edit Translation', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(158, 'dashboard.confirm_delete', 'ar', 'Confirm Delete', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(159, 'dashboard.delete', 'ar', 'Delete', '2025-09-28 17:42:22', '2025-09-28 17:42:22'),
(160, 'dashboard.Language_Name_(English):', 'ar', 'Language Name (English):', '2025-09-28 17:42:27', '2025-09-28 17:42:27'),
(161, 'dashboard.Language_Name', 'ar', 'Language Name', '2025-09-28 17:42:27', '2025-09-28 17:42:27'),
(162, 'dashboard.Native_Name:', 'ar', 'Native Name:', '2025-09-28 17:42:27', '2025-09-28 17:42:27'),
(163, 'dashboard.Language_Code', 'ar', 'Language Code (ex: en, ar, fr):', '2025-09-28 17:42:28', '2025-09-28 17:42:28'),
(164, 'dashboard.Flag_Image_URL:', 'ar', 'Flag Image URL (optional):', '2025-09-28 17:42:28', '2025-09-28 17:42:28'),
(165, 'dashboard.Flag_Image', 'ar', 'Flag Image URL (https://ex.com):', '2025-09-28 17:42:28', '2025-09-28 17:42:28'),
(166, 'dashboard.RTL:Yes_(language written from right to left):', 'ar', 'RTL:Yes (language written from right to left)', '2025-09-28 17:42:28', '2025-09-28 17:42:28'),
(167, 'dashboard.Status:Active', 'ar', 'Status:Active', '2025-09-28 17:42:28', '2025-09-28 17:42:28'),
(168, 'dashboard.Cancel', 'ar', 'Cancel', '2025-09-28 17:42:28', '2025-09-28 17:42:28'),
(169, 'dashboard.Add', 'ar', 'Add', '2025-09-28 17:43:21', '2025-09-28 17:43:21'),
(170, 'frontend.page_default_title', 'fr', 'Untitled Page', '2025-09-28 17:44:51', '2025-09-28 17:44:51'),
(171, 'General.palgoals', 'fr', 'palgoals', '2025-09-28 17:44:51', '2025-09-28 17:44:51'),
(172, 'General.goals', 'fr', 'discretion', '2025-09-28 17:44:51', '2025-09-28 17:44:51'),
(173, 'dashboard.All_Services', 'ar', 'ALL Services', '2025-09-30 17:08:17', '2025-09-30 17:08:17'),
(174, 'frontend.Contact_us', 'ar', 'تواصل معنا', '2025-10-02 17:58:03', '2025-10-02 20:01:55'),
(175, 'frontend.Quick_Links', 'ar', 'روابط سريعة', '2025-10-02 17:59:56', '2025-10-02 20:00:27'),
(176, 'frontend.Home', 'ar', 'الرئيسية', '2025-10-02 17:59:56', '2025-10-02 20:02:44'),
(177, 'frontend.Hosting', 'ar', 'Hosting', '2025-10-02 17:59:56', '2025-10-02 17:59:56'),
(178, 'frontend.Domain', 'ar', 'Domain', '2025-10-02 17:59:56', '2025-10-02 17:59:56'),
(179, 'frontend.Templates', 'ar', 'Templates', '2025-10-02 17:59:56', '2025-10-02 17:59:56'),
(180, 'frontend.Our_Work', 'ar', 'Our Work', '2025-10-02 17:59:56', '2025-10-02 17:59:56'),
(181, 'frontend.Blog', 'ar', 'Blog', '2025-10-02 17:59:56', '2025-10-02 17:59:56'),
(182, 'frontend.Services', 'ar', 'خدماتنا', '2025-10-02 17:59:56', '2025-10-02 20:01:21'),
(183, 'frontend.Web_Design', 'ar', 'Web Design', '2025-10-02 17:59:56', '2025-10-02 17:59:56'),
(184, 'frontend.WordPress_Hosting', 'ar', 'WordPress Hosting', '2025-10-02 17:59:56', '2025-10-02 17:59:56'),
(185, 'frontend.Shared_Hosting', 'ar', 'Shared Hosting', '2025-10-02 17:59:56', '2025-10-02 17:59:56'),
(186, 'frontend.SEO_Optimization', 'ar', 'SEO Optimization', '2025-10-02 17:59:56', '2025-10-02 17:59:56'),
(187, 'frontend.Quick_Links', 'en', 'Quick Links', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(188, 'frontend.Home', 'en', 'Home', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(189, 'frontend.Hosting', 'en', 'Hosting', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(190, 'frontend.Domain', 'en', 'Domain', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(191, 'frontend.Templates', 'en', 'Templates', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(192, 'frontend.Our_Work', 'en', 'Our Work', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(193, 'frontend.Blog', 'en', 'Blog', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(194, 'frontend.Contact_Us', 'en', 'Contact Us', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(195, 'frontend.Services', 'en', 'Services', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(196, 'frontend.Web_Design', 'en', 'Web Design', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(197, 'frontend.WordPress_Hosting', 'en', 'WordPress Hosting', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(198, 'frontend.Shared_Hosting', 'en', 'Shared Hosting', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(199, 'frontend.SEO_Optimization', 'en', 'SEO Optimization', '2025-10-02 18:01:47', '2025-10-02 18:01:47'),
(200, 'frontend.Accepted_Payment_Methods', 'en', 'Accepted Payment Methods', '2025-10-02 18:02:33', '2025-10-02 18:03:30'),
(201, 'frontend.Accepted_Payment_Methods', 'ar', 'نقبل وسائل الدفع:', '2025-10-02 18:02:33', '2025-10-02 18:02:33'),
(202, 'dashboard.Translation_Values', 'en', 'Translation Values', '2025-10-02 18:03:13', '2025-10-02 18:03:13'),
(203, 'dashboard.Add_New_Translation', 'en', 'Add New Translation', '2025-10-02 18:03:13', '2025-10-02 18:03:13'),
(204, 'dashboard.All_Languages', 'en', 'All Languages', '2025-10-02 18:03:13', '2025-10-02 18:03:13'),
(205, 'dashboard.All_Types', 'en', 'All Types', '2025-10-02 18:03:13', '2025-10-02 18:03:13'),
(206, 'dashboard.Dashboard', 'en', 'Dashboard', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(207, 'dashboard.Frontend', 'en', 'Frontend', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(208, 'dashboard.General', 'en', 'General', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(209, 'dashboard.Search_keys...', 'en', 'Search keys...', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(210, 'dashboard.Search', 'en', 'Search', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(211, 'dashboard.Reset', 'en', 'Reset', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(212, 'dashboard.Export_CSV', 'en', 'Export CSV', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(213, 'dashboard.Import_CSV', 'en', 'Import CSV', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(214, 'dashboard.Key', 'en', 'Key', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(215, 'dashboard.Value', 'en', 'Value', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(216, 'dashboard.Type', 'en', 'Type', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(217, 'dashboard.Actiont', 'en', 'Action', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(218, 'dashboard.edit_translation', 'en', 'Edit Translation', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(219, 'dashboard.confirm_delete', 'en', 'Confirm Delete', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(220, 'dashboard.delete', 'en', 'Delete', '2025-10-02 18:03:14', '2025-10-02 18:03:14'),
(221, 'dashboard.Taype_Name', 'en', 'Taype Name', '2025-10-02 18:03:19', '2025-10-02 18:03:19'),
(222, 'dashboard.Taype_Name', 'ar', 'Taype Name', '2025-10-02 18:03:19', '2025-10-02 18:03:19'),
(223, 'dashboard.Cancel', 'en', 'Cancel', '2025-10-02 18:03:19', '2025-10-02 18:03:19'),
(224, 'dashboard.Save', 'en', 'Save', '2025-10-02 18:03:19', '2025-10-02 18:03:19'),
(225, 'dashboard.Save', 'ar', 'Save', '2025-10-02 18:03:19', '2025-10-02 18:03:19'),
(226, 'frontend.Accepted_Payment_Methods', 'fr', 'Accepted Payment Methods', '2025-10-02 19:59:39', '2025-10-02 19:59:39'),
(227, 'section.Add_Feature', 'ar', '+Add Feature', '2025-10-02 20:04:31', '2025-10-02 20:04:31'),
(228, 'section.See_more_button', 'ar', 'See more button', '2025-10-02 20:07:36', '2025-10-02 20:07:36'),
(229, 'section.Link_see_more', 'ar', 'Link see more', '2025-10-02 20:07:36', '2025-10-02 20:07:36'),
(230, 'section.Order', 'ar', 'Order', '2025-10-03 15:30:23', '2025-10-03 15:30:23'),
(231, 'section.Select category', 'ar', 'Select category', '2025-10-03 15:30:23', '2025-10-03 15:30:23'),
(232, 'section.None', 'ar', '-- None --', '2025-10-03 15:30:23', '2025-10-03 15:30:23'),
(233, 'section.Or provide slug', 'ar', 'Or provide category slug for finer control', '2025-10-03 15:30:23', '2025-10-03 15:30:23'),
(234, 'section.Category slug', 'ar', 'Category slug (optional)', '2025-10-03 15:30:23', '2025-10-03 15:30:23'),
(235, 'section.Slug_example', 'ar', 'e.g. web-hosting', '2025-10-03 15:30:23', '2025-10-03 15:30:23'),
(236, 'section.Preview', 'ar', 'Preview', '2025-10-03 15:30:23', '2025-10-03 15:30:23'),
(237, 'section.No_category_selected', 'ar', 'No category selected — all plans will be shown', '2025-10-03 15:30:23', '2025-10-03 15:30:23'),
(238, 'section.Available_plans', 'ar', 'Available plans count', '2025-10-03 15:30:23', '2025-10-03 15:30:23'),
(239, 'dashboard.All_Services', 'en', 'ALL Services', '2025-10-03 20:26:25', '2025-10-03 20:26:25'),
(240, 'dashboard.Home', 'fr', 'Home', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(241, 'dashboard.services', 'fr', 'Services', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(242, 'dashboard.All_Services', 'fr', 'ALL Services', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(243, 'dashboard.features_title', 'fr', '', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(244, 'dashboard.My_Account', 'fr', 'My Account', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(245, 'dashboard.Settings', 'fr', 'Settings', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(246, 'dashboard.Logout', 'fr', 'Logout', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(247, 'dashboard.Navigation', 'fr', 'Navigation', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(248, 'dashboard.Pages', 'fr', 'Pages', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(249, 'dashboard.Template_management', 'fr', 'Template management', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(250, 'dashboard.All_templates', 'fr', 'All templates', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(251, 'dashboard.Categories', 'fr', 'Categories', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(252, 'dashboard.reviews', 'fr', 'reviews', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(253, 'dashboard.feedbacks', 'fr', 'testimonial', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(254, 'dashboard.portfolios', 'fr', 'portfolios', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(255, 'dashboard.clients', 'fr', 'clients', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(256, 'dashboard.domains', 'fr', 'domains', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(257, 'dashboard.plans', 'fr', 'plans', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(258, 'dashboard.plan-categories', 'fr', 'plan categories', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(259, 'dashboard.subscriptions', 'fr', 'subscriptions', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(260, 'dashboard.invoices', 'fr', 'invoices', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(261, 'dashboard.orders', 'fr', 'orders', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(262, 'dashboard.CRM_management', 'fr', 'CRM management', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(263, 'dashboard.servers', 'fr', 'servers', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(264, 'dashboard.domain_providers', 'fr', 'domain providers', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(265, 'dashboard.domain-tlds', 'fr', 'domain tlds', '2025-10-03 20:26:32', '2025-10-03 20:26:32'),
(266, 'dashboard.sync-logs', 'fr', 'sync-logs', '2025-10-03 20:26:33', '2025-10-03 20:26:33'),
(267, 'dashboard.Site_settings', 'fr', 'Site settings', '2025-10-03 20:26:33', '2025-10-03 20:26:33'),
(268, 'dashboard.media', 'fr', 'Media', '2025-10-03 20:26:33', '2025-10-03 20:26:33'),
(269, 'dashboard.Appearance', 'fr', 'Appearance', '2025-10-03 20:26:33', '2025-10-03 20:26:33'),
(270, 'dashboard.Menus', 'fr', 'Menus', '2025-10-03 20:26:33', '2025-10-03 20:26:33'),
(271, 'dashboard.languages', 'fr', 'languages', '2025-10-03 20:26:33', '2025-10-03 20:26:33'),
(272, 'dashboard.Users_show', 'fr', 'Users show', '2025-10-03 20:26:33', '2025-10-03 20:26:33'),
(273, 'dashboard.Add_User', 'fr', 'Add User', '2025-10-03 20:26:33', '2025-10-03 20:26:33'),
(274, 'dashboard.General_Setting', 'fr', 'General Setting', '2025-10-03 20:26:33', '2025-10-03 20:26:33'),
(275, 'dashboard.Make_Homepage', 'en', 'Make Homepage', '2025-10-06 16:00:34', '2025-10-06 16:00:34'),
(276, 'dashboard.Edit_Page', 'en', 'Edit Page', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(277, 'dashboard.Add_Section', 'en', 'Add Section', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(278, 'dashboard.Page_Title', 'en', 'Page Title', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(279, 'dashboard.Slug_Hint', 'en', 'Use lowercase letters, numbers, and dashes only. Leave empty to auto-generate for the main language.', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(280, 'dashboard.Page_Content', 'en', 'Page Content', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(281, 'dashboard.SEO_Meta', 'en', 'SEO Meta', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(282, 'dashboard.Meta_Title', 'en', 'Meta Title', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(283, 'dashboard.Meta_Description', 'en', 'Meta Description', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(284, 'dashboard.Short_Description', 'en', 'Short description for search engines', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(285, 'dashboard.Aim_Characters', 'en', 'Aim for 50-160 characters. Leave empty to reuse the title.', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(286, 'dashboard.Meta_Keywords', 'en', 'Meta Keywords', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(287, 'dashboard.Separate_Keywords', 'en', 'Separate keywords with a comma or Arabic comma (?).', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(288, 'dashboard.Open_Graph_Image_URL', 'en', 'Open Graph Image URL', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(289, 'dashboard.Choose_from_media', 'en', 'Choose from media', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(290, 'dashboard.Use_a_full_URL', 'en', 'Use a full URL or a Storage link generated via asset()/Storage::url(). Recommended size 1200x630px.', '2025-10-06 16:21:26', '2025-10-06 16:21:26'),
(291, 'dashboard.Preview', 'en', 'Preview', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(292, 'dashboard.Publishing_Options', 'en', 'Publishing Options', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(293, 'dashboard.Draft', 'en', 'Draft', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(294, 'dashboard.Published', 'en', 'Published', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(295, 'dashboard.Publish_Date', 'en', 'Publish Date', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(296, 'dashboard.Update', 'en', 'Update', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(297, 'dashboard.Cancel_Edit', 'en', 'Cancel Edit', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(298, 'section.Delete', 'en', 'Delete', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(299, 'section.Section_Arrangement', 'en', 'Section Arrangement', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(300, 'section.Example:', 'en', 'Example: 1, 2, 3', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(301, 'section.Title', 'en', 'Title', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(302, 'section.Brief_description', 'en', 'Brief description', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(303, 'section.Save_changes', 'en', 'Save changes', '2025-10-06 16:21:27', '2025-10-06 16:21:27'),
(304, 'dashboard.All_Menus', 'en', 'ALL Menus', '2025-10-06 16:24:50', '2025-10-06 16:24:50'),
(305, 'section.Order', 'en', 'Order', '2025-10-06 16:27:08', '2025-10-06 16:27:08'),
(306, 'section.Select category', 'en', 'Select category', '2025-10-06 16:27:08', '2025-10-06 16:27:08'),
(307, 'section.None', 'en', '-- None --', '2025-10-06 16:27:08', '2025-10-06 16:27:08'),
(308, 'section.Or provide slug', 'en', 'Or provide category slug for finer control', '2025-10-06 16:27:08', '2025-10-06 16:27:08'),
(309, 'section.Category slug', 'en', 'Category slug (optional)', '2025-10-06 16:27:08', '2025-10-06 16:27:08'),
(310, 'section.Slug_example', 'en', 'e.g. web-hosting', '2025-10-06 16:27:08', '2025-10-06 16:27:08'),
(311, 'section.Preview', 'en', 'Preview', '2025-10-06 16:27:08', '2025-10-06 16:27:08'),
(312, 'section.No_category_selected', 'en', 'No category selected — all plans will be shown', '2025-10-06 16:27:08', '2025-10-06 16:27:08'),
(313, 'section.Available_plans', 'en', 'Available plans count', '2025-10-06 16:27:09', '2025-10-06 16:27:09'),
(314, 'dashboard.Languages_List', 'en', 'Languages List', '2025-10-06 16:29:38', '2025-10-06 16:29:38'),
(315, 'dashboard.Add_Languages', 'en', 'Add Languages', '2025-10-06 16:29:38', '2025-10-06 16:29:38'),
(316, 'dashboard.Name', 'en', 'Name', '2025-10-06 16:29:38', '2025-10-06 16:29:38'),
(317, 'dashboard.Native_Name', 'en', 'Native Name', '2025-10-06 16:29:38', '2025-10-06 16:29:38'),
(318, 'dashboard.Code', 'en', 'Code', '2025-10-06 16:29:38', '2025-10-06 16:29:38'),
(319, 'dashboard.Flag', 'en', 'Flag', '2025-10-06 16:29:38', '2025-10-06 16:29:38'),
(320, 'dashboard.RTL', 'en', 'RTL', '2025-10-06 16:29:38', '2025-10-06 16:29:38'),
(321, 'dashboard.languages_edit', 'en', 'Languages Edit', '2025-10-06 16:29:38', '2025-10-06 16:29:38'),
(322, 'frontend.Quick_Links', 'fr', 'Quick Links', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(323, 'frontend.Home', 'fr', 'Home', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(324, 'frontend.Hosting', 'fr', 'Hosting', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(325, 'frontend.Domain', 'fr', 'Domain', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(326, 'frontend.Templates', 'fr', 'Templates', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(327, 'frontend.Our_Work', 'fr', 'Our Work', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(328, 'frontend.Blog', 'fr', 'Blog', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(329, 'frontend.Contact_Us', 'fr', 'Contact Us', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(330, 'frontend.Services', 'fr', 'Services', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(331, 'frontend.Web_Design', 'fr', 'Web Design', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(332, 'frontend.WordPress_Hosting', 'fr', 'WordPress Hosting', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(333, 'frontend.Shared_Hosting', 'fr', 'Shared Hosting', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(334, 'frontend.SEO_Optimization', 'fr', 'SEO Optimization', '2025-10-06 17:10:29', '2025-10-06 17:10:29'),
(335, 'dashboard.All_Menus', 'fr', 'ALL Menus', '2025-10-06 17:10:41', '2025-10-06 17:10:41'),
(336, 'dashboard.Languages_List', 'fr', 'Languages List', '2025-10-06 17:11:20', '2025-10-06 17:11:20'),
(337, 'dashboard.Add_Languages', 'fr', 'Add Languages', '2025-10-06 17:11:20', '2025-10-06 17:11:20'),
(338, 'dashboard.Name', 'fr', 'Name', '2025-10-06 17:11:20', '2025-10-06 17:11:20'),
(339, 'dashboard.Native_Name', 'fr', 'Native Name', '2025-10-06 17:11:20', '2025-10-06 17:11:20'),
(340, 'dashboard.Code', 'fr', 'Code', '2025-10-06 17:11:21', '2025-10-06 17:11:21'),
(341, 'dashboard.Flag', 'fr', 'Flag', '2025-10-06 17:11:21', '2025-10-06 17:11:21'),
(342, 'dashboard.RTL', 'fr', 'RTL', '2025-10-06 17:11:21', '2025-10-06 17:11:21'),
(343, 'dashboard.Status', 'fr', 'Status', '2025-10-06 17:11:21', '2025-10-06 17:11:21'),
(344, 'dashboard.Actiont', 'fr', 'Action', '2025-10-06 17:11:21', '2025-10-06 17:11:21'),
(345, 'dashboard.languages_edit', 'fr', 'Languages Edit', '2025-10-06 17:11:21', '2025-10-06 17:11:21'),
(346, 'Frontend.Checkout', 'ar', 'Checkout', '2025-10-07 19:27:49', '2025-10-07 19:27:49'),
(347, 'Frontend.Palgoals', 'ar', 'Palgoals', '2025-10-07 19:27:49', '2025-10-07 19:27:49'),
(348, 'Frontend.Checkout', 'en', 'Checkout', '2025-10-09 19:54:21', '2025-10-09 19:54:21'),
(349, 'Frontend.Palgoals', 'en', 'Palgoals', '2025-10-09 19:54:21', '2025-10-09 19:54:21'),
(350, 'frontend.monthly', 'ar', 'شهريًا', '2025-10-10 05:22:32', '2025-10-10 05:24:02'),
(351, 'frontend.annually', 'ar', 'سنويًا', '2025-10-10 05:22:33', '2025-10-10 05:24:38'),
(352, 'frontend.monthly', 'en', 'Monthly', '2025-10-10 05:22:59', '2025-10-10 05:24:02'),
(353, 'frontend.annually', 'en', 'Annually', '2025-10-10 05:22:59', '2025-10-10 05:24:38');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `super_admin` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `two_factor_confirmed_at`, `super_admin`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Theodora Wisoky', 'langosh.providenci@example.com', '2025-09-27 20:22:43', '$2y$12$zRxsjsz2gHFYBebf1964gOOmeJfFkhn2TPsj40YiuKxqyp3e42Qe.', NULL, NULL, NULL, 0, 'zXm2PXhcjA', '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(2, 'Ruth Bernier', 'claud61@example.net', '2025-09-27 20:22:44', '$2y$12$zRxsjsz2gHFYBebf1964gOOmeJfFkhn2TPsj40YiuKxqyp3e42Qe.', NULL, NULL, NULL, 0, 'LDf2BRe69q', '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(3, 'Dr. Martina Watsica I', 'waters.dianna@example.net', '2025-09-27 20:22:44', '$2y$12$zRxsjsz2gHFYBebf1964gOOmeJfFkhn2TPsj40YiuKxqyp3e42Qe.', NULL, NULL, NULL, 0, 'dKzCA3VL2b', '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(4, 'Georgette Kessler MD', 'tjerde@example.net', '2025-09-27 20:22:44', '$2y$12$zRxsjsz2gHFYBebf1964gOOmeJfFkhn2TPsj40YiuKxqyp3e42Qe.', NULL, NULL, NULL, 0, 'SPY3sAOu80', '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(5, 'Troy Mitchell', 'nicolette92@example.com', '2025-09-27 20:22:44', '$2y$12$zRxsjsz2gHFYBebf1964gOOmeJfFkhn2TPsj40YiuKxqyp3e42Qe.', NULL, NULL, NULL, 0, 'KWVNA8hdaF', '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(6, 'Monserrat Nicolas', 'reynolds.lelia@example.org', '2025-09-27 20:22:44', '$2y$12$zRxsjsz2gHFYBebf1964gOOmeJfFkhn2TPsj40YiuKxqyp3e42Qe.', NULL, NULL, NULL, 0, 'SrhuNiClMt', '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(7, 'Ms. Jada Thiel', 'njaskolski@example.com', '2025-09-27 20:22:44', '$2y$12$zRxsjsz2gHFYBebf1964gOOmeJfFkhn2TPsj40YiuKxqyp3e42Qe.', NULL, NULL, NULL, 0, '4Hdzw7AZHs', '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(8, 'Amanda Heaney', 'omer.moen@example.net', '2025-09-27 20:22:44', '$2y$12$zRxsjsz2gHFYBebf1964gOOmeJfFkhn2TPsj40YiuKxqyp3e42Qe.', NULL, NULL, NULL, 0, 'NH5tiyIaal', '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(9, 'Audrey Schaefer', 'cooper.sauer@example.com', '2025-09-27 20:22:44', '$2y$12$zRxsjsz2gHFYBebf1964gOOmeJfFkhn2TPsj40YiuKxqyp3e42Qe.', NULL, NULL, NULL, 0, '5IxvWrTjOa', '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(10, 'Mr. Santiago Bergstrom', 'helena.barton@example.net', '2025-09-27 20:22:44', '$2y$12$zRxsjsz2gHFYBebf1964gOOmeJfFkhn2TPsj40YiuKxqyp3e42Qe.', NULL, NULL, NULL, 0, 'KCjXbvggb5', '2025-09-27 20:22:44', '2025-09-27 20:22:44'),
(11, 'Administrator', 'admin@gmail.com', '2025-09-27 20:22:44', '$2y$12$G5Oln1mUniDWGnPkYL9Xi.spwc8Mdv2Qk/51J2Fe3jOtIKsA4VTAi', NULL, NULL, NULL, 1, 'IrQSVYXSKZevjkyyQAoKK2U5iV8HiGRUjR8vmlEMOUqrU1mUKWAqm6zaN86u', '2025-09-27 20:22:44', '2025-09-27 20:22:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `activity_logs_actor_type_actor_id_index` (`actor_type`,`actor_id`),
  ADD KEY `activity_logs_action_index` (`action`),
  ADD KEY `activity_logs_created_at_index` (`created_at`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `category_templates`
--
ALTER TABLE `category_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_template_translations`
--
ALTER TABLE `category_template_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_template_locale_unique` (`category_template_id`,`locale`),
  ADD UNIQUE KEY `category_template_translations_slug_unique` (`slug`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clients_email_unique` (`email`);

--
-- Indexes for table `client_contacts`
--
ALTER TABLE `client_contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_contacts_client_id_role_index` (`client_id`,`role`),
  ADD KEY `client_contacts_email_index` (`email`);

--
-- Indexes for table `client_notes`
--
ALTER TABLE `client_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_notes_client_id_created_at_index` (`client_id`,`created_at`),
  ADD KEY `client_notes_admin_id_index` (`admin_id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `coupons_code_unique` (`code`);

--
-- Indexes for table `coupon_subscription`
--
ALTER TABLE `coupon_subscription`
  ADD PRIMARY KEY (`id`),
  ADD KEY `coupon_subscription_coupon_id_foreign` (`coupon_id`),
  ADD KEY `coupon_subscription_subscription_id_foreign` (`subscription_id`);

--
-- Indexes for table `domains`
--
ALTER TABLE `domains`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `domains_domain_name_unique` (`domain_name`),
  ADD KEY `domains_client_id_foreign` (`client_id`);

--
-- Indexes for table `domain_providers`
--
ALTER TABLE `domain_providers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `domain_providers_type_index` (`type`),
  ADD KEY `domain_providers_is_active_index` (`is_active`),
  ADD KEY `domain_providers_mode_index` (`mode`);

--
-- Indexes for table `domain_tlds`
--
ALTER TABLE `domain_tlds`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `domain_tlds_provider_id_tld_unique` (`provider_id`,`tld`),
  ADD KEY `domain_tlds_provider_id_index` (`provider_id`),
  ADD KEY `domain_tlds_provider_index` (`provider`),
  ADD KEY `domain_tlds_tld_index` (`tld`),
  ADD KEY `domain_tlds_in_catalog_index` (`in_catalog`);

--
-- Indexes for table `domain_tld_prices`
--
ALTER TABLE `domain_tld_prices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `domain_tld_prices_domain_tld_id_action_years_unique` (`domain_tld_id`,`action`,`years`),
  ADD KEY `domain_tld_prices_domain_tld_id_index` (`domain_tld_id`),
  ADD KEY `domain_tld_prices_action_index` (`action`),
  ADD KEY `domain_tld_prices_years_index` (`years`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback_translations`
--
ALTER TABLE `feedback_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `feedback_translations_feedback_id_foreign` (`feedback_id`);

--
-- Indexes for table `general_settings`
--
ALTER TABLE `general_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `general_settings_default_language_foreign` (`default_language`);

--
-- Indexes for table `headers`
--
ALTER TABLE `headers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `header_items`
--
ALTER TABLE `header_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `header_items_header_id_foreign` (`header_id`),
  ADD KEY `header_items_page_id_foreign` (`page_id`);

--
-- Indexes for table `header_item_translations`
--
ALTER TABLE `header_item_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `header_item_translations_header_item_id_foreign` (`header_item_id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoices_number_unique` (`number`),
  ADD KEY `invoices_client_id_foreign` (`client_id`),
  ADD KEY `invoices_order_id_foreign` (`order_id`);

--
-- Indexes for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_items_invoice_id_foreign` (`invoice_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `orders_order_number_unique` (`order_number`),
  ADD KEY `orders_client_id_status_index` (`client_id`,`status`),
  ADD KEY `orders_type_index` (`type`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_items_order_id_domain_unique` (`order_id`,`domain`),
  ADD KEY `order_items_domain_index` (`domain`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page_translations_page_id_locale_unique` (`page_id`,`locale`),
  ADD UNIQUE KEY `page_translations_slug_locale_unique` (`slug`,`locale`),
  ADD KEY `page_translations_locale_slug_index` (`locale`,`slug`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plans_slug_unique` (`slug`),
  ADD KEY `plans_is_active_index` (`is_active`),
  ADD KEY `plans_monthly_price_cents_annual_price_cents_index` (`monthly_price_cents`,`annual_price_cents`),
  ADD KEY `plans_plan_category_id_index` (`plan_category_id`),
  ADD KEY `plans_server_id_index` (`server_id`),
  ADD KEY `plans_server_package_index` (`server_package`),
  ADD KEY `fk_plans_created_by` (`created_by`),
  ADD KEY `fk_plans_updated_by` (`updated_by`);

--
-- Indexes for table `plan_categories`
--
ALTER TABLE `plan_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plan_category_translations`
--
ALTER TABLE `plan_category_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plan_category_translations_plan_category_id_locale_unique` (`plan_category_id`,`locale`),
  ADD UNIQUE KEY `plan_category_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `plan_category_translations_locale_slug_index` (`locale`,`slug`);

--
-- Indexes for table `plan_translations`
--
ALTER TABLE `plan_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plan_translations_plan_id_locale_unique` (`plan_id`,`locale`);

--
-- Indexes for table `portfolios`
--
ALTER TABLE `portfolios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `portfolios_slug_unique` (`slug`);

--
-- Indexes for table `portfolio_translations`
--
ALTER TABLE `portfolio_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `portfolio_translations_portfolio_id_foreign` (`portfolio_id`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`role_name`,`user_id`),
  ADD KEY `role_user_user_id_foreign` (`user_id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sections_page_id_foreign` (`page_id`);

--
-- Indexes for table `section_translations`
--
ALTER TABLE `section_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `section_translations_section_id_foreign` (`section_id`);

--
-- Indexes for table `servers`
--
ALTER TABLE `servers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_translations`
--
ALTER TABLE `service_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_translations_service_id_foreign` (`service_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `sites`
--
ALTER TABLE `sites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sites_client_id_foreign` (`client_id`),
  ADD KEY `sites_domain_id_foreign` (`domain_id`),
  ADD KEY `sites_plan_id_foreign` (`plan_id`),
  ADD KEY `sites_subscription_id_foreign` (`subscription_id`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subscriptions_client_id_foreign` (`client_id`),
  ADD KEY `subscriptions_plan_id_foreign` (`plan_id`),
  ADD KEY `subscriptions_server_package_index` (`server_package`);

--
-- Indexes for table `templates`
--
ALTER TABLE `templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `templates_category_template_id_foreign` (`category_template_id`),
  ADD KEY `templates_plan_id_foreign` (`plan_id`);

--
-- Indexes for table `template_reviews`
--
ALTER TABLE `template_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `template_reviews_user_id_foreign` (`user_id`),
  ADD KEY `template_reviews_client_id_foreign` (`client_id`),
  ADD KEY `template_reviews_template_id_approved_created_at_index` (`template_id`,`approved`,`created_at`),
  ADD KEY `template_reviews_template_id_rating_index` (`template_id`,`rating`);

--
-- Indexes for table `template_translations`
--
ALTER TABLE `template_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `template_translations_template_id_locale_slug_unique` (`template_id`,`locale`,`slug`);

--
-- Indexes for table `translation_values`
--
ALTER TABLE `translation_values`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `translation_values_key_locale_unique` (`key`,`locale`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `category_templates`
--
ALTER TABLE `category_templates`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `category_template_translations`
--
ALTER TABLE `category_template_translations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `client_contacts`
--
ALTER TABLE `client_contacts`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `client_notes`
--
ALTER TABLE `client_notes`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coupon_subscription`
--
ALTER TABLE `coupon_subscription`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `domains`
--
ALTER TABLE `domains`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `domain_providers`
--
ALTER TABLE `domain_providers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `domain_tlds`
--
ALTER TABLE `domain_tlds`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `domain_tld_prices`
--
ALTER TABLE `domain_tld_prices`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback_translations`
--
ALTER TABLE `feedback_translations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `general_settings`
--
ALTER TABLE `general_settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `headers`
--
ALTER TABLE `headers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `header_items`
--
ALTER TABLE `header_items`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `header_item_translations`
--
ALTER TABLE `header_item_translations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `invoice_items`
--
ALTER TABLE `invoice_items`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `page_translations`
--
ALTER TABLE `page_translations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `plan_categories`
--
ALTER TABLE `plan_categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `plan_category_translations`
--
ALTER TABLE `plan_category_translations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `plan_translations`
--
ALTER TABLE `plan_translations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `portfolios`
--
ALTER TABLE `portfolios`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `portfolio_translations`
--
ALTER TABLE `portfolio_translations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `section_translations`
--
ALTER TABLE `section_translations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `servers`
--
ALTER TABLE `servers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `service_translations`
--
ALTER TABLE `service_translations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `sites`
--
ALTER TABLE `sites`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `templates`
--
ALTER TABLE `templates`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `template_reviews`
--
ALTER TABLE `template_reviews`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `template_translations`
--
ALTER TABLE `template_translations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `translation_values`
--
ALTER TABLE `translation_values`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=354;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `category_template_translations`
--
ALTER TABLE `category_template_translations`
  ADD CONSTRAINT `category_template_translations_category_template_id_foreign` FOREIGN KEY (`category_template_id`) REFERENCES `category_templates` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `client_contacts`
--
ALTER TABLE `client_contacts`
  ADD CONSTRAINT `client_contacts_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `client_notes`
--
ALTER TABLE `client_notes`
  ADD CONSTRAINT `client_notes_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `coupon_subscription`
--
ALTER TABLE `coupon_subscription`
  ADD CONSTRAINT `coupon_subscription_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `coupon_subscription_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `domains`
--
ALTER TABLE `domains`
  ADD CONSTRAINT `domains_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `domain_tlds`
--
ALTER TABLE `domain_tlds`
  ADD CONSTRAINT `domain_tlds_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `domain_providers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `domain_tld_prices`
--
ALTER TABLE `domain_tld_prices`
  ADD CONSTRAINT `domain_tld_prices_domain_tld_id_foreign` FOREIGN KEY (`domain_tld_id`) REFERENCES `domain_tlds` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `feedback_translations`
--
ALTER TABLE `feedback_translations`
  ADD CONSTRAINT `feedback_translations_feedback_id_foreign` FOREIGN KEY (`feedback_id`) REFERENCES `feedbacks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `general_settings`
--
ALTER TABLE `general_settings`
  ADD CONSTRAINT `general_settings_default_language_foreign` FOREIGN KEY (`default_language`) REFERENCES `languages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `header_items`
--
ALTER TABLE `header_items`
  ADD CONSTRAINT `header_items_header_id_foreign` FOREIGN KEY (`header_id`) REFERENCES `headers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `header_items_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `header_item_translations`
--
ALTER TABLE `header_item_translations`
  ADD CONSTRAINT `header_item_translations_header_item_id_foreign` FOREIGN KEY (`header_item_id`) REFERENCES `header_items` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `invoices_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD CONSTRAINT `invoice_items_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD CONSTRAINT `page_translations_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `plans`
--
ALTER TABLE `plans`
  ADD CONSTRAINT `fk_plans_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_plans_plan_category` FOREIGN KEY (`plan_category_id`) REFERENCES `plan_categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_plans_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `plan_category_translations`
--
ALTER TABLE `plan_category_translations`
  ADD CONSTRAINT `plan_category_translations_plan_category_id_foreign` FOREIGN KEY (`plan_category_id`) REFERENCES `plan_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `plan_translations`
--
ALTER TABLE `plan_translations`
  ADD CONSTRAINT `plan_translations_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `portfolio_translations`
--
ALTER TABLE `portfolio_translations`
  ADD CONSTRAINT `portfolio_translations_portfolio_id_foreign` FOREIGN KEY (`portfolio_id`) REFERENCES `portfolios` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sections`
--
ALTER TABLE `sections`
  ADD CONSTRAINT `sections_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `section_translations`
--
ALTER TABLE `section_translations`
  ADD CONSTRAINT `section_translations_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `service_translations`
--
ALTER TABLE `service_translations`
  ADD CONSTRAINT `service_translations_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sites`
--
ALTER TABLE `sites`
  ADD CONSTRAINT `sites_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sites_domain_id_foreign` FOREIGN KEY (`domain_id`) REFERENCES `domains` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sites_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sites_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD CONSTRAINT `subscriptions_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `subscriptions_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE RESTRICT;

--
-- Constraints for table `templates`
--
ALTER TABLE `templates`
  ADD CONSTRAINT `templates_category_template_id_foreign` FOREIGN KEY (`category_template_id`) REFERENCES `category_templates` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `templates_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `template_reviews`
--
ALTER TABLE `template_reviews`
  ADD CONSTRAINT `template_reviews_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `template_reviews_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `templates` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `template_reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `template_translations`
--
ALTER TABLE `template_translations`
  ADD CONSTRAINT `template_translations_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `templates` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
