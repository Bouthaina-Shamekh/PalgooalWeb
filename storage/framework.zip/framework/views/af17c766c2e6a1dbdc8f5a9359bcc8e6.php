<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>">Home</a></li>
                <li class="breadcrumb-item" aria-current="page">Plan Categories</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">Plan Categories</h2>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card table-card">
                <div class="card-header flex items-center justify-between">
                    <h5 class="mb-0">Categories List</h5>
                    <a href="<?php echo e(route('dashboard.plan_categories.create')); ?>" class="btn btn-primary">Add Category</a>
                </div>
                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover w-full">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Slug</th>
                                    <th>Active</th>
                                    <th>Title (<?php echo e(app()->getLocale()); ?>)</th>
                                    <th>Description (<?php echo e(app()->getLocale()); ?>)</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $trans = $cat->translation();
                                        $activeClass = $cat->is_active
                                            ? 'bg-green-500 text-white border border-green-400'
                                            : 'bg-red-500 text-white border border-red-400';
                                        $activeText = $cat->is_active ? 'تعطيل' : 'تفعيل';
                                    ?>
                                    <tr>
                                        <td><?php echo e($cat->id); ?></td>
                                        <td><?php echo e($trans?->slug ?? '-'); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('dashboard.plan_categories.toggle', $cat->id)); ?>" method="POST" style="display:inline-block">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="px-2 py-1 rounded text-xs font-bold focus:outline-none transition-all <?php echo e($activeClass); ?>">
                                                    <?php echo e($activeText); ?>

                                                </button>
                                            </form>
                                        </td>
                                        <td><?php echo e($trans?->title ?? '-'); ?></td>
                                        <td><?php echo e($trans?->description ?? '-'); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('dashboard.plan_categories.edit', $cat->id)); ?>" class="btn btn-sm btn-secondary">Edit</a>
                                            <form action="<?php echo e(route('dashboard.plan_categories.destroy', $cat->id)); ?>" method="POST" style="display:inline-block" onsubmit="return confirm('Delete?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-gray-500 py-8">No categories found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-4">
                        <?php echo e($categories->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\plan_categories\index.blade.php ENDPATH**/ ?>