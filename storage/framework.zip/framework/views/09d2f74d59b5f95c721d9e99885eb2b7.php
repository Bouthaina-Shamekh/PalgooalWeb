﻿<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Plans</a></li>
                <li class="breadcrumb-item" aria-current="page">Plans List</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">Plans List</h2>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card table-card">
                <?php if(session('connection_result')): ?>
                    <div class="alert alert-info mb-4"><?php echo e(session('connection_result')); ?></div>
                <?php endif; ?>

                <div class="card-header">
                    <div class="sm:flex items-center justify-between">
                        <h5 class="mb-3 sm:mb-0">Plans List</h5>
                        <a href="<?php echo e(route('dashboard.plans.create')); ?>" class="btn btn-primary">Add Plan</a>
                    </div>
                </div>

                
                <div class="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between mb-4 px-4">
                    <input type="text" wire:model.live.debounce.300ms="search" placeholder="Search plans..."
                        class="w-full sm:w-80 border rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/30" />

                    <div class="flex items-center gap-2">
                        <label class="text-sm text-gray-500">Per page</label>
                        <select wire:model="perPage"
                            class="border rounded-xl px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-primary/30">
                            <option value="5">5</option>
                            <option value="10">10</option>
                            <option value="25">25</option>
                        </select>
                    </div>
                </div>

                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover w-full">
                            <thead>
                                <tr>
                                    <th class="text-right">#</th>
                                    <th class="text-right">Name</th>
                                    <th class="text-right">Category</th>
                                    <th class="text-right">Server</th>
                                    <th class="text-right">Price</th>
                                    <th class="text-right">Featured</th>
                                    <th class="text-right">Status</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $rowIndex = ($plans->firstItem() ?? 1) + $index;
                                        $translation = $plan->translations
                                            ->where('locale', app()->getLocale())
                                            ->first();
                                        $categoryTranslation =
                                            $plan->category?->translations->firstWhere('locale', app()->getLocale()) ??
                                            $plan->category?->translations->first();

                                        $monthly = $plan->monthly_price_cents
                                            ? '$' . number_format($plan->monthly_price_cents / 100, 2)
                                            : null;
                                        $annual = $plan->annual_price_cents
                                            ? '$' . number_format($plan->annual_price_cents / 100, 2)
                                            : null;
                                    ?>
                                    <tr>
                                        <td><?php echo e($rowIndex); ?></td>
                                        <td class="font-semibold">
                                            <?php echo e($translation?->title ?? $plan->slug); ?>

                                            <div class="text-xs text-gray-500"><?php echo e($plan->slug); ?></div>
                                            <?php if($plan->is_featured): ?>
                                                <span
                                                    class="mt-1 inline-flex items-center gap-1 rounded-full bg-primary/10 text-primary text-[11px] px-2 py-0.5">
                                                    <i class="ti ti-star-filled text-xs"></i>
                                                    <?php echo e($plan->featured_label ?? __('Most Popular')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($categoryTranslation?->title ?? '-'); ?></td>
                                        <td><?php echo e($plan->server?->name ?? '-'); ?></td>
                                        <td>
                                            <?php if($monthly || $annual): ?>
                                                <?php if($monthly): ?>
                                                    <div><strong>Monthly:</strong> <?php echo e($monthly); ?></div>
                                                <?php endif; ?>
                                                <?php if($annual): ?>
                                                    <div><strong>Annual:</strong> <?php echo e($annual); ?></div>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-gray-400">&mdash;</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($plan->is_featured): ?>
                                                <span
                                                    class="badge bg-primary/10 text-primary rounded-full text-xs px-2 py-0.5">
                                                    <?php echo e($plan->featured_label ?? __('Most Popular')); ?>

                                                </span>
                                            <?php else: ?>
                                                <span class="text-gray-400">&mdash;</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('dashboard.plans.toggle', $plan->id)); ?>"
                                                method="POST" style="display:inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="w-full text-left">
                                                    <?php if($plan->is_active): ?>
                                                        <span
                                                            class="badge bg-emerald-500/10 text-emerald-600 rounded-full text-xs px-2 py-0.5">Active</span>
                                                    <?php else: ?>
                                                        <span
                                                            class="badge bg-gray-500/10 text-gray-600 rounded-full text-xs px-2 py-0.5">Inactive</span>
                                                    <?php endif; ?>
                                                </button>
                                            </form>
                                        </td>
                                        <td class="whitespace-nowrap flex gap-1">
                                            <a href="<?php echo e(route('dashboard.plans.edit', $plan->id)); ?>"
                                                class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary"
                                                title="Edit">
                                                <i class="ti ti-edit text-xl leading-none"></i>
                                            </a>
                                            <form action="<?php echo e(route('dashboard.plans.destroy', $plan->id)); ?>"
                                                method="POST"
                                                onsubmit="return confirm('Are you sure you want to delete this plan?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                    class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary"
                                                    title="Delete">
                                                    <i class="ti ti-trash text-xl leading-none"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-gray-500 py-8">No plans found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4"><?php echo e($plans->links()); ?></div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\plans\index.blade.php ENDPATH**/ ?>