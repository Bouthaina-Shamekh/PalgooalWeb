
<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('dashboard.invoices.index')); ?>"><?php echo e(__('Invoices')); ?></a>
                </li>
                <li class="breadcrumb-item" aria-current="page"><?php echo e(__('Manage Invoices')); ?></li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0"><?php echo e(__('Manage Invoices')); ?></h2>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card table-card">
                <?php if(session('ok')): ?>
                    <?php if (isset($component)) { $__componentOriginal1587a26e02f5044e2021410bd7590d74 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1587a26e02f5044e2021410bd7590d74 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.alert','data' => ['type' => 'success','class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success','class' => 'mb-4']); ?>
                        <?php echo e(session('ok')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1587a26e02f5044e2021410bd7590d74)): ?>
<?php $attributes = $__attributesOriginal1587a26e02f5044e2021410bd7590d74; ?>
<?php unset($__attributesOriginal1587a26e02f5044e2021410bd7590d74); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1587a26e02f5044e2021410bd7590d74)): ?>
<?php $component = $__componentOriginal1587a26e02f5044e2021410bd7590d74; ?>
<?php unset($__componentOriginal1587a26e02f5044e2021410bd7590d74); ?>
<?php endif; ?>
                <?php endif; ?>

                <?php if(session('connection_result')): ?>
                    <?php $connMsg = session('connection_result'); ?>
                    <?php if (isset($component)) { $__componentOriginal1587a26e02f5044e2021410bd7590d74 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1587a26e02f5044e2021410bd7590d74 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.alert','data' => ['type' => 'info','class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'info','class' => 'mb-4']); ?>
                        <span class="whitespace-pre-line"><?php echo e($connMsg); ?></span>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1587a26e02f5044e2021410bd7590d74)): ?>
<?php $attributes = $__attributesOriginal1587a26e02f5044e2021410bd7590d74; ?>
<?php unset($__attributesOriginal1587a26e02f5044e2021410bd7590d74); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1587a26e02f5044e2021410bd7590d74)): ?>
<?php $component = $__componentOriginal1587a26e02f5044e2021410bd7590d74; ?>
<?php unset($__componentOriginal1587a26e02f5044e2021410bd7590d74); ?>
<?php endif; ?>
                <?php endif; ?>

                <div class="card-header">
                    <div class="sm:flex items-center justify-between">
                        <h5 class="mb-3 sm:mb-0"><?php echo e(__('Invoices')); ?></h5>
                        <div class="flex items-center gap-2">
                            <a href="<?php echo e(route('dashboard.invoices.create')); ?>" class="btn btn-primary">
                                <i class="ti ti-plus"></i> <?php echo e(__('Create Invoice')); ?>

                            </a>
                        </div>
                    </div>
                </div>

                <div class="card-body pt-3">
                    
                    <div class="mb-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                        <form id="invoiceFilterForm" method="GET" action="<?php echo e(route('dashboard.invoices.index')); ?>"
                              class="flex flex-col sm:flex-row gap-2 sm:items-center w-full">
                            <div class="flex items-center gap-2 sm:min-w-[16rem] w-full">
                                <label for="invoiceSearch" class="sr-only"><?php echo e(__('Search')); ?></label>
                                <input id="invoiceSearch" type="search" name="q" value="<?php echo e(request('q')); ?>"
                                       placeholder="<?php echo e(__('Search by invoice number or client name')); ?>"
                                       class="rounded border px-3 py-2 text-sm w-full"
                                       autocomplete="off" />
                            </div>

                            <div class="flex items-center gap-2 sm:w-48">
                                <label for="invoiceStatus" class="sr-only"><?php echo e(__('Status')); ?></label>
                                <select id="invoiceStatus" name="status"
                                        class="rounded border px-2 py-2 text-sm w-full">
                                    <option value=""><?php echo e(__('All statuses')); ?></option>
                                    <?php $__currentLoopData = ['draft','unpaid','paid','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($st); ?>" <?php if(request('status') === $st): echo 'selected'; endif; ?>><?php echo e(__(ucfirst($st))); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="flex items-center gap-2">
                                <button class="px-3 py-2 bg-blue-600 text-white rounded text-sm">
                                    <?php echo e(__('Apply')); ?>

                                </button>
                                <?php if(request()->hasAny(['q','status']) && (filled(request('q')) || filled(request('status')))): ?>
                                    <a href="<?php echo e(route('dashboard.invoices.index')); ?>"
                                       class="px-3 py-2 border rounded text-sm text-gray-600 hover:bg-gray-100">
                                        <?php echo e(__('Reset')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>

                    
                    <div class="table-responsive">
                        <table class="table text-end align-middle">
                            <thead>
                                <tr>
                                    <th class="w-10">
                                        <input type="checkbox" id="select_all_invoices" class="form-check-input" aria-label="<?php echo e(__('Select all')); ?>">
                                    </th>
                                    <th><?php echo e(__('Invoice #')); ?></th>
                                    <th><?php echo e(__('Client')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                    <th><?php echo e(__('Total')); ?></th>
                                    <th><?php echo e(__('Due Date')); ?></th>
                                    <th><?php echo e(__('Created At')); ?></th>
                                    <th class="text-end"><?php echo e(__('Actions')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        // تنسيق المبلغ: cents -> major units، وإظهار كود العملة فقط لتجنب ازدواج $ مع الكود
                                        $totalMajor = number_format(($invoice->total_cents ?? 0) / 100, 2);
                                        $currency   = $invoice->currency ?? 'USD';
                                        $clientF    = optional($invoice->client)->first_name;
                                        $clientL    = optional($invoice->client)->last_name;
                                        $clientName = trim(($clientF ?? '') . ' ' . ($clientL ?? '')) ?: __('Unknown client');
                                        $statusBadges = [
                                            'draft'     => 'badge-secondary',
                                            'unpaid'    => 'badge-warning',
                                            'paid'      => 'badge-success',
                                            'cancelled' => 'badge-danger',
                                        ];
                                        $badgeClass = $statusBadges[$invoice->status] ?? 'badge-secondary';
                                    ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox"
                                                   class="form-check-input invoice_checkbox"
                                                   name="ids[]"
                                                   value="<?php echo e($invoice->id); ?>"
                                                   form="bulk_form_invoices"
                                                   aria-label="<?php echo e(__('Select invoice :num', ['num' => $invoice->number])); ?>">
                                        </td>
                                        <td class="font-mono text-sm"><?php echo e($invoice->number); ?></td>
                                        <td class="truncate max-w-[220px]" title="<?php echo e($clientName); ?>"><?php echo e($clientName); ?></td>
                                        <td>
                                            <span class="badge <?php echo e($badgeClass); ?>"><?php echo e(__(ucfirst($invoice->status))); ?></span>
                                        </td>
                                        <td>
                                            <span class="font-medium"><?php echo e($totalMajor); ?></span>
                                            <span class="text-xs text-gray-500"><?php echo e($currency); ?></span>
                                        </td>
                                        <td>
                                            <?php echo e($invoice->due_date ? $invoice->due_date->format('Y-m-d') : '—'); ?>

                                        </td>
                                        <td><?php echo e($invoice->created_at->format('Y-m-d H:i')); ?></td>
                                        <td>
                                            <div class="flex items-center justify-end gap-2">
                                                <a href="<?php echo e(route('dashboard.invoices.show', $invoice->id)); ?>"
                                                   class="btn btn-icon btn-link-secondary text-gray-600 hover:text-primary-600"
                                                   title="<?php echo e(__('View invoice')); ?>" aria-label="<?php echo e(__('View invoice')); ?>">
                                                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                                        <path d="M2 12s4-8 10-8 10 8 10 8-4 8-10 8S2 12 2 12z"></path>
                                                        <circle cx="12" cy="12" r="3"></circle>
                                                    </svg>
                                                </a>
                                                <a href="<?php echo e(route('dashboard.invoices.edit', $invoice->id)); ?>"
                                                   class="btn btn-icon btn-link-secondary text-gray-600 hover:text-primary-600"
                                                   title="<?php echo e(__('Edit invoice')); ?>" aria-label="<?php echo e(__('Edit invoice')); ?>">
                                                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                                        <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z"></path>
                                                    </svg>
                                                </a>
                                                <form action="<?php echo e(route('dashboard.invoices.destroy', $invoice->id)); ?>"
                                                      method="POST" class="inline ajax-action"
                                                      data-confirm="<?php echo e(__('Are you sure you want to delete this invoice?')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                            class="btn btn-icon btn-link-danger text-red-600 hover:text-red-700"
                                                            title="<?php echo e(__('Delete invoice')); ?>" aria-label="<?php echo e(__('Delete invoice')); ?>">
                                                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                                            <path d="M3 6h18M8 6v12a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V6"></path>
                                                            <path d="M10 11v6M14 11v6"></path>
                                                        </svg>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8" class="px-6 py-10 text-center text-sm text-gray-500">
                                            <?php echo e(__('No invoices found at the moment.')); ?>

                                            <a href="<?php echo e(route('dashboard.invoices.create')); ?>"
                                               class="text-blue-600 hover:underline font-medium">
                                                <?php echo e(__('Create a new invoice')); ?>

                                            </a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    
                    <form id="bulk_form_invoices" method="POST" action="<?php echo e(route('dashboard.invoices.bulk')); ?>"
                          class="mt-6 border-t pt-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="action" id="bulk_action_invoices">
                        <div class="flex flex-col gap-1">
                            <div class="text-sm font-medium text-gray-600"><?php echo e(__('With selected:')); ?></div>
                            <div id="bulk_selection_helper" class="text-xs text-gray-500">
                                <?php echo e(__('Select invoices to enable the actions.')); ?>

                            </div>
                        </div>

                        <div class="flex flex-wrap gap-2">
                            <button type="button" class="bulk-action-btn px-3 py-2 border rounded text-sm text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                                    data-bulk-action="paid" disabled>
                                <?php echo e(__('Mark Paid')); ?>

                            </button>
                            <button type="button" class="bulk-action-btn px-3 py-2 border rounded text-sm text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                                    data-bulk-action="unpaid" disabled>
                                <?php echo e(__('Mark Unpaid')); ?>

                            </button>
                            <button type="button" class="bulk-action-btn px-3 py-2 border rounded text-sm text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                                    data-bulk-action="cancelled" disabled>
                                <?php echo e(__('Mark Cancelled')); ?>

                            </button>
                            <button type="button" class="bulk-action-btn px-3 py-2 border rounded text-sm text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                                    data-bulk-action="duplicate" disabled
                                    data-confirm="<?php echo e(__('Create a duplicate of :count invoice(s)?', ['count' => ':count'])); ?>">
                                <?php echo e(__('Duplicate Invoice')); ?>

                            </button>
                            <button type="button" class="bulk-action-btn px-3 py-2 border rounded text-sm text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                                    data-bulk-action="reminder" disabled
                                    data-confirm="<?php echo e(__('Send a reminder email for :count invoice(s)?', ['count' => ':count'])); ?>">
                                <?php echo e(__('Send Reminder')); ?>

                            </button>
                            <button type="button" class="bulk-action-btn px-3 py-2 border rounded text-sm text-red-600 border-red-200 hover:bg-red-50 disabled:opacity-50 disabled:cursor-not-allowed"
                                    data-bulk-action="delete" disabled
                                    data-confirm="<?php echo e(__('Delete :count selected invoice(s)? This action cannot be undone.', ['count' => ':count'])); ?>">
                                <?php echo e(__('Delete')); ?>

                            </button>
                        </div>
                    </form>

                    <div class="pagination mt-4">
                        <?php echo e($invoices->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<script src="<?php echo e(asset('assets/dashboard/js/invoices-index.js')); ?>" defer></script>
<?php $__env->startPush('scripts'); ?>
    
    <script src="<?php echo e(asset('assets/dashboard/js/invoices-index.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\invoices\index.blade.php ENDPATH**/ ?>