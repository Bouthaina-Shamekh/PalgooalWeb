<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
  'label' => '',
  'type'  => 'text',
  'name'  => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
  'label' => '',
  'type'  => 'text',
  'name'  => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>


<div class="mb-3">
  <?php if($label): ?>
    <label for="<?php echo e($name); ?>" class="form-label capitalize"><?php echo e($label); ?></label>
  <?php endif; ?>

  <input
    id="<?php echo e($name); ?>"
    name="<?php echo e($name); ?>"
    type="<?php echo e($type); ?>"
    <?php echo e($attributes->merge(['class' => 'form-control'])); ?>

    placeholder="<?php echo e($attributes->get('placeholder', 'Enter ' . $label)); ?>"
  />
    
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\components\form\input.blade.php ENDPATH**/ ?>