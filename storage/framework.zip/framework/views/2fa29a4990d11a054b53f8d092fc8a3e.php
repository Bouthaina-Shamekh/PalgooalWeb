﻿<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="<?php echo e(app()->getLocale() === 'ar' ? 'rtl' : 'ltr'); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($page->translations->firstWhere('locale', app()->getLocale())?->title ?? $page->slug ?? 'Tenant Site'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@3.4.4/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-white text-gray-900">
    <div class="min-h-screen">
        <header class="border-b bg-gradient-to-r from-blue-50 to-blue-100/60">
            <div class="max-w-5xl mx-auto px-6 py-6">
                <p class="text-xs uppercase tracking-wide text-gray-500 mb-1"><?php echo e($tenantSubscription->domain_name); ?></p>
                <h1 class="text-3xl font-bold text-blue-900">
                    <?php echo e($page->translations->firstWhere('locale', app()->getLocale())?->title ?? $page->slug ?? 'صفحة'); ?>

                </h1>
            </div>
        </header>

        <main class="max-w-5xl mx-auto px-6 py-10 space-y-8">
            <?php $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $sectionTrans = $section->translations->firstWhere('locale', app()->getLocale())
                        ?? $section->translations->first();
                    $content = $sectionTrans?->content ?? [];
                    $partial = 'tenant.sections.' . \Illuminate\Support\Str::slug($section->type ?? 'generic', '_');
                ?>
                <?php echo $__env->first([
                    $partial,
                    'tenant.sections.generic'
                ], [
                    'section' => $section,
                    'translation' => $sectionTrans,
                    'content' => $content,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\tenant\site.blade.php ENDPATH**/ ?>