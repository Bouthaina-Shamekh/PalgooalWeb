<?php echo $__env->make('layouts.partials.dashboard.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="wrapper vh-100">
        <div class="align-items-center h-100 d-flex w-50 mx-auto">
            <div class="mx-auto text-center">
                <h1 class="display-1 m-0 font-weight-bolder text-danger" style="font-size:80px;">419</h1>
                <h1 class="mb-1 text-muted font-weight-bold">OOPS!</h1>
                <h4 class="mb-3 text-black">A simple error occurred please go back and try again</h4>
                <a href="<?php echo e(route('dashboard.home')); ?>" class="btn btn-lg btn-primary px-5">Back To Home</a>
            </div>
        </div>
    </div>
<?php echo $__env->make('layouts.partials.dashboard.end', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/errors/419.blade.php ENDPATH**/ ?>