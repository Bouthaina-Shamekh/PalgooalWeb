<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>"><?php echo e(t('dashboard.Home', 'Home')); ?></a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.languages.index')); ?>"><?php echo e(t('dashboard.Languages', 'Languages')); ?></a></li>
                <li class="breadcrumb-item" aria-current="page"><?php echo e(t('dashboard.Languages_List', 'Languages List')); ?></li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0"><?php echo e(t('dashboard.Languages_List', 'Languages List')); ?></h2>
            </div>
        </div>
    </div>
    <!-- [ breadcrumb ] end -->
    <!-- [ Main Content ] start -->
    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card table-card">
                <div class="card-header">
                    <div class="sm:flex items-center justify-between">
                        <h5 class="mb-3 sm:mb-0"><?php echo e(t('dashboard.Languages_List', 'Languages List')); ?></h5>
                        <div>
                            <a href="<?php echo e(route('dashboard.languages.create')); ?>" class="btn btn-primary"><?php echo e(t('dashboard.Add_Languages', 'Add Languages')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    
                                    <th>#</th>
                                    <th><?php echo e(t('dashboard.Name', 'Name')); ?></th>
                                    <th><?php echo e(t('dashboard.Native_Name', 'Native Name')); ?></th>
                                    <th><?php echo e(t('dashboard.Code', 'Code')); ?></th>
                                    <th><?php echo e(t('dashboard.Flag', 'Flag')); ?></th>
                                    <th><?php echo e(t('dashboard.RTL', 'RTL')); ?></th>
                                    <th><?php echo e(t('dashboard.Status', 'Status')); ?></th>
                                    <th><?php echo e(t('dashboard.Actiont', 'Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(($langs ->currentPage() - 1) * $langs ->perPage() + $loop->iteration); ?></td>
                                    <td><?php echo e($lang->name); ?></td>
                                    <td><?php echo e($lang->native); ?></td>
                                    <td><?php echo e(strtoupper($lang->code)); ?></td>
                                    <td>
                                        <?php if($lang->flag): ?>
                                            <img src="<?php echo e(asset($lang->flag)); ?>" alt="flag" class="w-6 h-4 inline-block">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch switch-lg">
                                            <input type="checkbox" <?php echo e($lang->is_rtl ? 'checked' : ''); ?> class="form-check-input checked:!bg-success-500 checked:!border-success-500 text-lg" onclick="toggleRtl(<?php echo e($lang->id); ?>, this.checked)" >
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch switch-lg">
                                            <input type="checkbox" <?php echo e($lang->is_active ? 'checked' : ''); ?> class="form-check-input checked:!bg-success-500 checked:!border-success-500 text-lg" onclick="toggleStatus(<?php echo e($lang->id); ?>, this.checked)" >
                                        </div>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('dashboard.translation-values.index', ['locale' => $lang->code])); ?>" class="btn btn-sm btn-info">
                                            <?php echo e(t('dashboard.languages_edit', 'Languages Edit')); ?>

                                        </a>
                                        <a href="<?php echo e(route('dashboard.languages.edit', $lang->id)); ?>" class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary">
                                            <i class="ti ti-edit text-xl leading-none"></i>
                                        </a>
                                        <a href="#" onclick="deleteLanguage(<?php echo e($lang->id); ?>)"  class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary">
                                            <i class="ti ti-trash text-xl leading-none"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="mt-4">
                    <?php echo e($langs->links()); ?>

                </div>
            </div>
        </div>
    </div>

<!-- ✅ SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // دالة موحدة لإظهار التنبيهات (Toasts)
const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 2000,
    timerProgressBar: true
});

function toggleRtl(langId, isChecked) {
    updateStatus(`/admin/languages/${langId}/toggle-rtl`, { is_rtl: isChecked ? 1 : 0 }, 'RTL');
}

function toggleStatus(langId, isChecked) {
    updateStatus(`/admin/languages/${langId}/toggle-status`, { is_active: isChecked ? 1 : 0 }, 'Status');
}

// دالة عامة لتحديث الحالات (Toggle)
function updateStatus(url, data, label) {
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
            'Accept': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            Toast.fire({ icon: 'success', title: `✅ ${label} updated successfully` });
        } else {
            Toast.fire({ icon: 'error', title: `❌ Error updating ${label}` });
        }
    })
    .catch(() => Toast.fire({ icon: 'error', title: '❌ Connection error' }));
}

// دالة الحذف باستخدام SweetAlert2
function deleteLanguage(langId) {
    Swal.fire({
        title: 'هل أنت متأكد؟',
        text: "لن تتمكن من التراجع عن هذا الإجراء!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'نعم، احذف!',
        cancelButtonText: 'إلغاء'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch(`/admin/languages/${langId}`, { // المسار الصحيح للـ Resource Delete
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    Swal.fire('تم الحذف!', 'تمت إزالة اللغة بنجاح.', 'success');
                    setTimeout(() => location.reload(), 1000); // إعادة تحميل الصفحة لرؤية التغيير
                } else {
                    Swal.fire('خطأ!', data.error || 'حدث خطأ أثناء الحذف.', 'error');
                }
            })
            .catch(() => Swal.fire('خطأ!', 'فشل الاتصال بالخادم.', 'error'));
        }
    });
}
</script>
<script>
function deleteLanguage(langId) {
    Swal.fire({
        title: 'هل أنت متأكد؟',
        text: "سيتم حذف اللغة نهائياً مع كافة الترجمات التابعة لها من قاعدة البيانات والذاكرة المؤقتة!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'نعم، احذف الآن',
        cancelButtonText: 'تراجع',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            // إظهار حالة التحميل
            Swal.fire({
                title: 'جاري الحذف...',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading(); }
            });

            fetch('/admin/languages/' + langId, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json'
                }
            })
            .then(response => {
                if (!response.ok) throw new Error('Network error occurred');
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'تم الحذف!',
                        text: 'تم تنظيف قاعدة البيانات وتحديث النظام.',
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload(); // إعادة التحميل بعد رسالة النجاح
                    });
                } else {
                    throw new Error(data.error || 'حدث خطأ ما');
                }
            })
            .catch(error => {
                Swal.fire('خطأ!', error.message, 'error');
            });
        }
    });
}
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>    <?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\lang\index.blade.php ENDPATH**/ ?>