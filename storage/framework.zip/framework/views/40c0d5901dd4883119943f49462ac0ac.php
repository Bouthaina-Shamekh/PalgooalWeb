<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'type' => 'info',
    'dismissible' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'type' => 'info',
    'dismissible' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $variants = [
        'success' => 'bg-green-100 border border-green-200 text-green-800',
        'error' => 'bg-red-100 border border-red-200 text-red-800',
        'warning' => 'bg-amber-100 border border-amber-200 text-amber-800',
        'info' => 'bg-blue-100 border border-blue-200 text-blue-800',
    ];
    $classes = $variants[$type] ?? $variants['info'];
?>

<div <?php echo e($attributes->merge(['class' => "rounded-lg px-4 py-3 text-sm {$classes}"])); ?>>
    <div class="flex items-start gap-2">
        <div class="flex-1">
            <?php echo e($slot); ?>

        </div>
        <?php if($dismissible): ?>
            <button type="button" class="text-current/60 hover:text-current font-semibold" data-alert-dismiss>
                &times;
            </button>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\components\dashboard\alert.blade.php ENDPATH**/ ?>