<?php echo $__env->make('dashboard.layouts.partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!-- [ Sidebar Menu ] start -->
<?php echo $__env->make('client.layouts.partials.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!-- [ Sidebar Menu ] end -->
<!-- [ Header Topbar ] start -->
<?php echo $__env->make('client.layouts.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!-- [ Header ] end -->

<!-- [ Main Content ] start -->
<div class="pc-container">
    <div class="pc-content">
        <?php echo e($slot); ?>


        <!-- [ Main Content ] end -->
    </div>
</div>
<!-- [ Main Content ] end -->


<?php echo $__env->make('dashboard.layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php echo $__env->make('client.layouts.partials.end', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\client\layouts\app.blade.php ENDPATH**/ ?>