
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['data' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['data' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    /**
     * Features section
     * - $data['title']      : Section heading (string)
     * - $data['subtitle']   : Section subheading / description (string)
     * - $data['features']   : Array of features:
     *      [
     *          [
     *              'icon'        => '<svg>...</svg>', // inline SVG icon (optional)
     *              'title'       => 'Feature title',
     *              'description' => 'Short description...',
     *          ],
     *          ...
     *      ]
     * - $data['show_illustration'] : bool - toggle illustration column (default: true)
     * - $data['illustration']      : custom path for illustration image (optional)
     */

    $title            = $data['title']    ?? __('عنوان غير متوفر');
    $subtitle         = $data['subtitle'] ?? '';
    $features         = $data['features'] ?? [];
    $showIllustration = array_key_exists('show_illustration', $data)
        ? (bool) $data['show_illustration']
        : true;

    // Illustration image (fallback to default Palgoals illustration)
    $illustrationPath = $data['illustration'] ?? 'assets/tamplate/images/Fu.svg';
?>

<section
    class="py-20 sm:py-24 lg:py-28 px-4 sm:px-6 lg:px-8 bg-background"
    dir="auto"
    aria-labelledby="features-heading"
    data-section-type="features"
>
    <div class="container-xx">
        
        <div class="text-center max-w-2xl mx-auto mb-12 sm:mb-14 lg:mb-16">
            <h2 id="features-heading"
                class="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-primary tracking-tight mb-4">
                <?php echo e($title); ?>

            </h2>

            <?php if($subtitle): ?>
                <p class="text-tertiary text-sm sm:text-base leading-relaxed">
                    <?php echo e($subtitle); ?>

                </p>
            <?php endif; ?>
        </div>

        
        <div class="grid gap-12 lg:gap-16 lg:grid-cols-5 items-center">
            
            <?php if($showIllustration): ?>
                <div class="lg:col-span-2 flex justify-center">
                    <img
                        src="<?php echo e(asset($illustrationPath)); ?>"
                        alt="مميزات المنصة"
                        class="max-w-[260px] sm:max-w-sm lg:max-w-[420px] w-full h-auto object-contain mx-auto
                               animate-fade-in-up
                               transition-transform duration-500 ease-out
                               hover:scale-105"
                        loading="lazy"
                    >
                </div>
            <?php endif; ?>

            
            <?php
                // If there is no illustration, take the full width
                $featuresColSpan = $showIllustration ? 'lg:col-span-3' : 'lg:col-span-5';
            ?>

            <div class="<?php echo e($featuresColSpan); ?>">
                <?php if(empty($features)): ?>
                    
                    <p class="text-sm text-gray-500 text-center lg:text-start">
                        <?php echo e(__('لم يتم إعداد مميزات لهذا القسم بعد.')); ?>

                    </p>
                <?php else: ?>
                    <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6 lg:gap-8">
                        <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $featureTitle       = $feature['title'] ?? __('عنوان');
                                $featureDescription = $feature['description'] ?? __('وصف مختصر');
                                $featureIcon        = $feature['icon'] ?? null;
                            ?>

                            <div
                                class="group rounded-2xl bg-white/90 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-700
                                       p-5 sm:p-6 shadow-[0_10px_30px_rgba(15,23,42,0.06)]
                                       hover:shadow-[0_18px_40px_rgba(15,23,42,0.14)]
                                       transition-all duration-200">
                                <dt class="flex flex-col items-center sm:items-start gap-4">
                                    
                                    <div
                                        class="w-12 h-12 flex items-center justify-center rounded-xl
                                               bg-primary/10 text-primary
                                               group-hover:bg-primary group-hover:text-white
                                               transition-colors duration-200 shrink-0">
                                        <?php if($featureIcon): ?>
                                            <?php echo $featureIcon; ?>

                                        <?php else: ?>
                                            
                                            <span class="w-2 h-2 rounded-full bg-current shadow-[0_0_0_3px_rgba(255,255,255,0.35)]"></span>
                                        <?php endif; ?>
                                    </div>

                                    
                                    <span class="text-base sm:text-lg font-semibold text-slate-900 dark:text-white text-center sm:text-start">
                                        <?php echo e($featureTitle); ?>

                                    </span>
                                </dt>

                                <dd class="mt-2 text-sm text-gray-600 dark:text-gray-300 leading-relaxed text-center sm:text-start">
                                    <?php echo e($featureDescription); ?>

                                </dd>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\components\template\sections\features.blade.php ENDPATH**/ ?>