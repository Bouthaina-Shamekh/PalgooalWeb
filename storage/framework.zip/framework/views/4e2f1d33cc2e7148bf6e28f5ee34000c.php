﻿<?php
    use App\Models\Service;
    use App\Services\TemplateService;
    use App\Models\CategoryTemplate;
    use App\Models\DomainTld;
    use App\Models\DomainTldPrice;
    use Illuminate\Support\Str;
    use App\Support\SeoMeta;
?>
<?php
    $pageTranslation = $page->translation();
    $fallbackTitle = t('frontend.page_default_title', 'Untitled Page');
    $pageTitle = $pageTranslation?->meta_title ?: $pageTranslation?->title ?? $fallbackTitle;
    $rawPageContent = is_string($pageTranslation?->content) ? $pageTranslation->content : '';
    $pageDescription = $pageTranslation?->meta_description ?: Str::limit(strip_tags($rawPageContent), 160);
    if ($pageDescription === '') {
        $pageDescription = (string) config('seo.default_description', '');
    }
    $defaultKeywords = config('seo.default_keywords', []);
    $fallbackKeywords = is_array($defaultKeywords)
        ? $defaultKeywords
        : array_filter(array_map('trim', explode(',', (string) $defaultKeywords)));
    $keywordsFromTranslation = $pageTranslation?->meta_keywords;
    if (is_string($keywordsFromTranslation)) {
        $keywordsFromTranslation = array_filter(array_map('trim', explode(',', $keywordsFromTranslation)));
    } elseif (!is_array($keywordsFromTranslation)) {
        $keywordsFromTranslation = [];
    }
    $pageKeywords = !empty($keywordsFromTranslation) ? $keywordsFromTranslation : $fallbackKeywords;
    $pageOgImage = $pageTranslation?->og_image ?: 'assets/images/services.jpg';
    if ($pageOgImage && !Str::startsWith($pageOgImage, ['http://', 'https://'])) {
        $pageOgImage = asset($pageOgImage);
    }
    $schemaType = $page->is_home ? 'WebSite' : 'WebPage';
    $pageSchema = [
        '@context' => 'https://schema.org',
        '@type' => $schemaType,
        'name' => $pageTitle,
        'url' => url()->current(),
        'description' => $pageDescription,
        'inLanguage' => app()->getLocale(),
    ];

    $publishedAt = $page->published_at?->toIso8601String() ?? $page->created_at?->toIso8601String();
    if ($publishedAt) {
        $pageSchema['datePublished'] = $publishedAt;
    }
    $updatedAt = $page->updated_at?->toIso8601String();
    if ($updatedAt) {
        $pageSchema['dateModified'] = $updatedAt;
    }
    $seoOverrides = SeoMeta::make([
        'title' => $pageTitle,
        'description' => $pageDescription,
        'keywords' => $pageKeywords,
        'image' => $pageOgImage,
        'canonical' => url()->current(),
        'type' => $page->is_home ? 'website' : 'article',
        'schema' => [$pageSchema],
    ]);
?>
<?php if (isset($component)) { $__componentOriginal0785005caee783032a496108c55d26d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0785005caee783032a496108c55d26d5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.template.layouts.index-layouts','data' => ['title' => $pageTitle,'description' => $pageDescription,'keywords' => $pageKeywords,'ogImage' => $pageOgImage,'seo' => $seoOverrides]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('template.layouts.index-layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pageTitle),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pageDescription),'keywords' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pageKeywords),'ogImage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pageOgImage),'seo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seoOverrides)]); ?>
    
    <?php if($page->sections->isEmpty()): ?>
        <div class="container mx-auto py-10">
            <h1 class="text-3xl font-bold mb-6">
            </h1>
            <div class="prose max-w-4xl">
                <?php echo $page->translation()?->content ?? '<p>ظ„ط§ ظٹظˆط¬ط¯ ظ…ط­طھظˆظ‰.</p>'; ?>

            </div>
        </div>
    <?php endif; ?>
    <?php
        $pageTranslation = $page->translation();
        $fallbackTitle = t('frontend.page_default_title', 'Untitled Page');
        $pageTitle = $pageTranslation?->meta_title ?: $pageTranslation?->title ?? $fallbackTitle;
        $rawPageContent = is_string($pageTranslation?->content) ? $pageTranslation->content : '';
        $pageDescription = $pageTranslation?->meta_description ?: Str::limit(strip_tags($rawPageContent), 160);
        if ($pageDescription === '') {
            $pageDescription = (string) config('seo.default_description', '');
        }
        $defaultKeywords = config('seo.default_keywords', []);
        $fallbackKeywords = is_array($defaultKeywords)
            ? $defaultKeywords
            : array_filter(array_map('trim', explode(',', (string) $defaultKeywords)));
        $keywordsFromTranslation = $pageTranslation?->meta_keywords;
        if (is_string($keywordsFromTranslation)) {
            $keywordsFromTranslation = array_filter(array_map('trim', explode(',', $keywordsFromTranslation)));
        } elseif (!is_array($keywordsFromTranslation)) {
            $keywordsFromTranslation = [];
        }
        $pageKeywords = !empty($keywordsFromTranslation) ? $keywordsFromTranslation : $fallbackKeywords;
        $pageOgImage = $pageTranslation?->og_image ?: 'assets/images/services.jpg';
        if ($pageOgImage && !Str::startsWith($pageOgImage, ['http://', 'https://'])) {
            $pageOgImage = asset($pageOgImage);
        }
        $schemaType = $page->is_home ? 'WebSite' : 'WebPage';
        $pageSchema = [
            '@context' => 'https://schema.org',
            '@type' => $schemaType,
            'name' => $pageTitle,
            'url' => url()->current(),
            'description' => $pageDescription,
            'inLanguage' => app()->getLocale(),
        ];
        $publishedAt = $page->published_at?->toIso8601String() ?? $page->created_at?->toIso8601String();
        if ($publishedAt) {
            $pageSchema['datePublished'] = $publishedAt;
        }
        $updatedAt = $page->updated_at?->toIso8601String();
        if ($updatedAt) {
            $pageSchema['dateModified'] = $updatedAt;
        }
        $seoOverrides = SeoMeta::make([
            'title' => $pageTitle,
            'description' => $pageDescription,
            'keywords' => $pageKeywords,
            'image' => $pageOgImage,
            'canonical' => url()->current(),
            'type' => $page->is_home ? 'website' : 'article',
            'schema' => [$pageSchema],
        ]);
    ?>
    <?php
        $sectionComponents = [
            'hero' => 'hero',
            'features' => 'features',
            'services' => 'services',
            'templates' => 'templates',
            'works' => 'works',
            'home-works' => 'home-works',
            'testimonials' => 'testimonials',
            'blog' => 'blog',
            'banner' => 'banner',
            'search-domain' => 'search-domain',
            'templates-pages' => 'templates-pages',
            'hosting-plans' => 'hosting-plans',
        ];
    ?>
    <?php $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $key = $section->key;
            $component = $sectionComponents[$key] ?? null;
            if (!$component) {
                continue;
            }
            $translation = $section->translation();
            $content = $translation?->content ?? [];
            $title = $translation?->title ?? '';

            // âœ… ط¬ظ‡ظ‘ط² ط¨ظٹط§ظ†ط§طھ ظƒظ„ ط³ظٹظƒط´ظ†
            $data = match ($key) {
                'hero' => [
                    'title' => $title,
                    'subtitle' => $content['subtitle'] ?? '',
                    'button_text-1' => $content['button_text-1'] ?? '',
                    'button_url-1' => $content['button_url-1'] ?? '',
                    'button_text-2' => $content['button_text-2'] ?? '',
                    'button_url-2' => $content['button_url-2'] ?? '',
                ],
                'features' => [
                    'title' => $title,
                    'subtitle' => $content['subtitle'] ?? '',
                    'features' => is_array($content['features'] ?? null)
                        ? $content['features']
                        : array_filter(array_map('trim', explode("\n", $content['features'] ?? ''))),
                ],
                'services' => [
                    'title' => $title,
                    'subtitle' => $content['subtitle'] ?? '',
                    'services' => Service::with('translations')->orderBy('order')->get(),
                ],
                'home-works' => [
                    'title' => $title,
                    'subtitle' => $content['subtitle'] ?? '',
                    'button_text-1' => $content['button_text-1'] ?? '',
                    'button_url-1' => $content['button_url-1'] ?? '',
                ],
                'works', 'testimonials', 'banner' => [
                    'title' => $title,
                    'subtitle' => $content['subtitle'] ?? '',
                ],
                'hosting-plans' => (function () use ($content) {
                    // default
                    $cat = null;

                    $query = \App\Models\Plan::where('is_active', true)
                        ->with(['translations', 'category.translations'])
                        ->orderBy('id', 'asc');

                    // ظپظ„طھط±ط© ط­ط³ط¨ plan_category_id ط¥ظ† ظˆظڈط¬ط¯
                    if (!empty($content['plan_category_id'])) {
                        $query->where('plan_category_id', (int) $content['plan_category_id']);

                        // ط­ط§ظˆظ„ ط¬ظ„ط¨ ط§ظ„طھطµظ†ظٹظپ ظ„طھظ…ط±ظٹط±ظ‡ ظ„ظ„ظˆط§ط¬ظ‡ط© (ط¥ظ† ظˆط¬ط¯)
                        $cat = \App\Models\PlanCategory::with('translations')->find((int) $content['plan_category_id']);
                    }
                    // ط£ظˆ ظپظ„طھط±ط© ط­ط³ط¨ slug ط¶ظ…ظ† طھط±ط¬ظ…ط© ط§ظ„ظ€ locale ط§ظ„ط­ط§ظ„ظٹط©
                    elseif (!empty($content['plan_category_slug'])) {
                        $slug = (string) $content['plan_category_slug'];

                        // ط§ظ„ط¨ط­ط« ط¶ظ…ظ† ط§ظ„طھط±ط¬ظ…ط§طھ ظ„ظ„ظ€ locale ط§ظ„ط­ط§ظ„ظٹ
                        $cat = \App\Models\PlanCategory::whereHas('translations', function ($q) use ($slug) {
                            $q->where('slug', $slug)->where('locale', app()->getLocale());
                        })
                            ->with('translations')
                            ->first();

                        // ط¥ط°ط§ ظ„ظ… ظ†ط¬ط¯ طھط±ط¬ظ…ط© ط¨ط§ظ„ظ€ locale ط§ظ„ط­ط§ظ„ظٹطŒ ط¬ط±ط¨ ط§ظ„ط¨ط­ط« ط¹ط¨ط± ط¬ظ…ظٹط¹ ط§ظ„طھط±ط¬ظ…ط§طھ
                        if (!$cat) {
                            $cat = \App\Models\PlanCategory::whereHas('translations', function ($q) use ($slug) {
                                $q->where('slug', $slug);
                            })
                                ->with('translations')
                                ->first();
                        }

                        if ($cat) {
                            $query->where('plan_category_id', $cat->id);
                        } else {
                            // ط®ظٹط§ط±: ط§ط±ط¬ط¹ ظ„ط§ ط´ظٹط، ط¨ط¯ظ„ ط¬ظ…ظٹط¹ ط§ظ„ط®ط·ط·
                            $query->whereRaw('0 = 1');
                        }
                    }

                    $plans = $query->get();

                    return [
                        'title' => $title ?? '',
                        'subtitle' => $content['subtitle'] ?? '',
                        'plans' => $plans,
                        'category' => $cat,
                    ];
                })(),

                'templates' => [
                    'title' => $title,
                    'subtitle' => $content['subtitle'] ?? '',
                    'templates' => \App\Models\Template::with('translations')->latest()->take(8)->get(),
                ],
                'blog' => [
                    'title' => $title,
                    'subtitle' => $content['subtitle'] ?? '',
                    'button_text-1' => $content['button_text-1'] ?? '',
                    'button_url-1' => $content['button_url-1'] ?? '',
                ],
                // âœ… ظ‡ظ†ط§ ظ†ظ…ط±ظ‘ط± ط¨ظٹط§ظ†ط§طھ search-domain (ط§ظ„ظƒطھط§ظ„ظˆط¬ + ط£ط³ط¹ط§ط± fallback)
                'search-domain' => (function () {
                    // TLDs ط§ظ„ظ…ط¹ط±ظˆط¶ط© ظپظٹ ط§ظ„ظƒطھط§ظ„ظˆط¬
                    $defaultTlds = DomainTld::where('in_catalog', true)
                        ->orderBy('tld')
                        ->pluck('tld')
                        ->map(fn($t) => strtolower(ltrim($t, '.')))
                        ->values()
                        ->all();

                    // ط£ط³ط¹ط§ط± fallback: ظ†ط³طھط®ط¯ظ… sale ط¥ظ† ظˆط¬ط¯طھطŒ ظˆط¥ظ„ط§ cost ظ„ظ€ Register ط³ظ†ط© ظˆط§ط­ط¯ط©
                    $fallbackPrices = DomainTldPrice::with('tld')
                        ->whereIn('domain_tld_id', DomainTld::where('in_catalog', true)->pluck('id'))
                        ->where('action', 'register')
                        ->where('years', 1)
                        ->get()
                        ->mapWithKeys(function ($p) {
                            $tld = strtolower($p->tld->tld ?? '');
                            if ($tld === '') {
                                return [];
                            }
                            $price = $p->sale ?? $p->cost;
                            return $price !== null ? [$tld => (float) $price] : [];
                        })
                        ->toArray();

                    return [
                        'title' => $GLOBALS['title'] ?? '',
                        'subtitle' => '', // ظ…ظ…ظƒظ† طھط³طھط®ط¯ظ… ظ…ظ† طھط±ط¬ظ…ط© ط§ظ„ط³ظٹظƒط´ظ† ظ„ظˆ ظ„ط²ظ…
                        'default_tlds' => $defaultTlds,
                        'fallback_prices' => $fallbackPrices,
                        'currency' => 'USD', // ط¹ط¯ظ‘ظ„ظ‡ط§ ط­ط³ط¨ ط¥ط¹ط¯ط§ط¯ط§طھظƒ ط¥ظ† ظ„ط²ظ…
                    ];
                })(),
                'templates-pages' => [
                    'max_price' => $content['max_price'] ?? 500,
                    'sort_by' => request('sort', $content['sort_by'] ?? 'default'),
                    'show_filter_sidebar' => $content['show_filter_sidebar'] ?? true,
                    'selectedCategory' => $content['selectedCategory'] ?? 'all',
                    'templates' => \App\Models\Template::with(['translations', 'categoryTemplate.translations'])
                        ->latest()
                        ->take(60)
                        ->get(),
                    'categories' => \App\Models\CategoryTemplate::with([
                        'translations' => function ($q) {
                            $q->where('locale', app()->getLocale())->orWhere('locale', 'ar');
                        },
                    ])

                        ->get()

                        ->map(function ($cat) {
                            $t =
                                $cat->translations->firstWhere('locale', app()->getLocale()) ??
                                $cat->translations->firstWhere('locale', 'ar');

                            $cat->translated_name = $t?->name ?? 'ط؛ظٹط± ظ…ط¹ط±ظپ';

                            $cat->translated_slug = $t?->slug ?? ($cat->slug ?? 'uncategorized');

                            return $cat;
                        }),
                ],

                default => [],
            };

        ?>
        
        <?php if($component === 'templates-pages'): ?>
            <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'template.sections.' . $component] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['templates' => $data['templates'],'categories' => $data['categories'],'max_price' => $data['max_price'],'sort_by' => $data['sort_by'],'show_filter_sidebar' => $data['show_filter_sidebar'],'selectedCategory' => $data['selectedCategory']]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
        <?php elseif($component === 'search-domain'): ?>
            
            <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'template.sections.' . $component] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['default-tlds' => $data['default_tlds'] ?? [],'fallback-prices' => $data['fallback_prices'] ?? [],'currency' => $data['currency'] ?? 'USD']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
        <?php elseif($component === 'hosting-plans'): ?>
            <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'template.sections.' . $component] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['plans' => $data['plans'] ?? collect(),'title' => $data['title'] ?? '','subtitle' => $data['subtitle'] ?? '','category' => $data['category'] ?? null]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
        <?php else: ?>
            
            <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'template.sections.' . $component] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => $data,'templates' => $data['templates'] ?? collect()]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0785005caee783032a496108c55d26d5)): ?>
<?php $attributes = $__attributesOriginal0785005caee783032a496108c55d26d5; ?>
<?php unset($__attributesOriginal0785005caee783032a496108c55d26d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0785005caee783032a496108c55d26d5)): ?>
<?php $component = $__componentOriginal0785005caee783032a496108c55d26d5; ?>
<?php unset($__componentOriginal0785005caee783032a496108c55d26d5); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/tamplate/page.blade.php ENDPATH**/ ?>