<div class="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg mb-8 border border-gray-200 dark:border-gray-700 space-y-6">
    <?php if(session()->has('success')): ?>
        <div class="flex items-center gap-3 bg-green-100 text-green-900 border border-green-300 dark:bg-green-800/20 dark:text-green-100 dark:border-green-600 px-4 py-3 rounded-lg shadow transition-all duration-300" role="alert">
            <svg class="w-5 h-5 text-green-600 dark:text-green-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
            </svg>
            <span class="text-sm font-medium"><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <div class="flex items-center gap-3 bg-red-100 text-red-900 border border-red-300 dark:bg-red-800/20 dark:text-red-100 dark:border-red-600 px-4 py-3 rounded-lg shadow transition-all duration-300" role="alert">
            <svg class="w-5 h-5 text-red-600 dark:text-red-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
            <span class="text-sm font-medium"><?php echo e(session('error')); ?></span>
        </div>
    <?php endif; ?>

    <div class="flex justify-between items-center">
        <h3 class="text-xl font-semibold text-gray-800 dark:text-white"><?php echo e(t('section.faq', 'FAQ')); ?></h3>
        <button onclick="confirmDeleteSection(<?php echo e($section->id); ?>)" class="text-red-600 hover:underline text-sm">
            <?php echo e(t('section.Delete', 'Delete')); ?>

        </button>
    </div>

    <div class="col-span-12 md:col-span-2 mb-4">
        <label class="form-label"><?php echo e(t('section.Section_Arrangement', 'Section Arrangement')); ?></label>
        <input type="number" wire:model.defer="order" class="form-control" placeholder="<?php echo e(t('section.Example:', 'Example: 1, 2, 3')); ?>" />
    </div>

    <div class="flex flex-wrap gap-2 mt-4">
        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button wire:click="setActiveLang('<?php echo e($lang->code); ?>')"
                class="px-4 py-2 text-sm font-medium rounded-lg transition <?php echo e($activeLang === $lang->code ? 'bg-primary text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-primary hover:text-white'); ?>">
                <?php echo e($lang->native); ?>

            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div wire:key="faq-<?php echo e($activeLang); ?>" class="grid grid-cols-12 gap-6">
        <div class="col-span-12 md:col-span-6 mb-4">
            <label class="form-label"><?php echo e(t('section.Title', 'Title')); ?></label>
            <input type="text" wire:model.defer="translationsData.<?php echo e($activeLang); ?>.title" class="form-control" placeholder="<?php echo e(t('section.Title', 'Title')); ?>" />
        </div>

        <div class="col-span-12 md:col-span-6 mb-4">
            <label class="form-label"><?php echo e(t('section.Brief_description', 'Brief description')); ?></label>
            <textarea wire:model.defer="translationsData.<?php echo e($activeLang); ?>.subtitle" class="form-textarea w-full rounded-lg border dark:bg-gray-900" rows="3" placeholder="<?php echo e(t('section.Brief_description', 'Brief description')); ?>"></textarea>
        </div>

        <div class="col-span-12">
            <div class="flex items-center justify-between mb-3">
                <label class="form-label mb-0"><?php echo e(t('section.FAQ_List', 'FAQ Entries')); ?></label>
                <button type="button" wire:click="addFaq('<?php echo e($activeLang); ?>')" class="btn btn-sm btn-primary">
                    <?php echo e(t('section.Add_FAQ', '+ Add FAQ')); ?>

                </button>
            </div>

            <div class="space-y-4">
                <?php $__currentLoopData = $translationsData[$activeLang]['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border border-gray-200 dark:border-gray-700 rounded-xl p-4 bg-gray-50 dark:bg-gray-900/40" wire:key="faq-<?php echo e($activeLang); ?>-<?php echo e($index); ?>">
                        <div class="flex items-center justify-between mb-3">
                            <span class="text-sm font-semibold text-gray-700 dark:text-gray-200">
                                <?php echo e(t('section.Question', 'Question')); ?> #<?php echo e($index + 1); ?>

                            </span>
                            <button type="button" wire:click="removeFaq('<?php echo e($activeLang); ?>', <?php echo e($index); ?>)" class="text-red-600 hover:text-red-500 text-sm">
                                <?php echo e(t('section.Remove', 'Remove')); ?>

                            </button>
                        </div>

                        <div class="grid grid-cols-1 gap-3">
                            <input type="text" wire:model.defer="translationsData.<?php echo e($activeLang); ?>.items.<?php echo e($index); ?>.question"
                                   class="form-control" placeholder="<?php echo e(t('section.Question', 'Question')); ?>">

                            <textarea wire:model.defer="translationsData.<?php echo e($activeLang); ?>.items.<?php echo e($index); ?>.answer"
                                      class="form-textarea w-full rounded-lg border dark:bg-gray-900" rows="3"
                                      placeholder="<?php echo e(t('section.Answer', 'Answer')); ?>"></textarea>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(empty($translationsData[$activeLang]['items'])): ?>
                    <p class="text-sm text-gray-500">
                        <?php echo e(t('section.No_FAQ_Items', 'No FAQ entries yet. Add your first question above.')); ?>

                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="text-end">
        <button wire:click="updateFaqSection" class="btn btn-primary">
            <?php echo e(t('section.Save_changes', 'Save changes')); ?>

        </button>
    </div>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\livewire\admin\sections\faq-section.blade.php ENDPATH**/ ?>