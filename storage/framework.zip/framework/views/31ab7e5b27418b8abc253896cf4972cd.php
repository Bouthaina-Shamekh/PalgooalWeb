<li class="dropdown pc-h-item">
    <?php
        $request = request();
        $currentUrl = $request->fullUrlWithoutQuery(['change-locale']);
        $buildLocaleUrl = static function (string $url, string $locale): string {
            $separator = str_contains($url, '?') ? '&' : '?';

            return $url . $separator . 'change-locale=' . urlencode($locale);
        };
    ?>

    <a
        class="pc-head-link dropdown-toggle me-0"
        data-pc-toggle="dropdown"
        href="#"
        role="button"
        aria-haspopup="false"
        aria-expanded="false"
        title="<?php echo e($currentLanguage?->native ?? strtoupper($currentLocale)); ?>"
    >
        <i class="ti ti-language text-[18px] leading-none"></i>
    </a>

    <div class="dropdown-menu dropdown-menu-end pc-h-dropdown lng-dropdown">
        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $isCurrent = $lang->code === $currentLocale;
                $label = $lang->native ?: $lang->name ?: strtoupper($lang->code);
                $meta = $lang->name && $lang->name !== $label ? $lang->name : strtoupper($lang->code);
            ?>

            <a
                href="<?php echo e($isCurrent ? '#' : $buildLocaleUrl($currentUrl ?: url('/admin/home'), $lang->code)); ?>"
                class="dropdown-item <?php echo e($isCurrent ? 'active pointer-events-none' : ''); ?>"
                data-lng="<?php echo e($lang->code); ?>"
                <?php if($isCurrent): ?> aria-current="page" <?php endif; ?>
            >
                <span class="flex items-center gap-3">
                    <?php if($lang->flag): ?>
                        <img
                            src="<?php echo e(asset($lang->flag)); ?>"
                            alt="<?php echo e($label); ?>"
                            class="w-5 h-5 rounded-full object-cover border border-secondary-200"
                        >
                    <?php else: ?>
                        <span class="w-5 h-5 rounded-full bg-light-primary text-primary text-[10px] font-semibold inline-flex items-center justify-center">
                            <?php echo e(strtoupper(substr($lang->code, 0, 2))); ?>

                        </span>
                    <?php endif; ?>

                    <span class="flex flex-col leading-tight">
                        <span class="font-medium"><?php echo e($label); ?></span>
                        <small class="text-muted"><?php echo e($meta); ?></small>
                    </span>
                </span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</li>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/components/lang/language-switcher-dashboard.blade.php ENDPATH**/ ?>