<a class="pc-head-link dropdown-toggle me-0" data-pc-toggle="dropdown" href="#" role="button" aria-haspopup="false"
    aria-expanded="false">

    <?php if($currentLanguage?->flag): ?>
        <img src="<?php echo e(asset($currentLanguage->flag)); ?>" alt="<?php echo e($currentLanguage->native); ?>" class="inline w-4 h-4 mr-1">
    <?php else: ?>
        🌐
    <?php endif; ?>
    <?php echo e($currentLanguage?->native ?? $currentLocale); ?>

</a>
<div class="dropdown-menu dropdown-menu-end pc-h-dropdown">

    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e($lang->code !== $currentLocale ? route('change_locale', ['locale' => $lang->code]) : '#'); ?>"
            class="dropdown-item <?php echo e($lang->code === $currentLocale ? 'aria-current=page' : ''); ?>">

            <?php if($lang->flag): ?>
                <img src="<?php echo e(asset($lang->flag)); ?>" alt="<?php echo e($lang->native); ?>" class="inline w-4 h-4 mr-1">
            <?php endif; ?>

            <?php echo e($lang->native); ?>

        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/components/lang/language-switcher-dashboard.blade.php ENDPATH**/ ?>