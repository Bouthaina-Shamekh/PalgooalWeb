<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto py-6 max-w-5xl space-y-6">
        <div>
            <a href="<?php echo e(route('dashboard.domains.index')); ?>"
                class="inline-flex items-center text-sm text-gray-500 hover:text-gray-700 transition">
                <i class="ti ti-arrow-left me-1"></i>
                <?php echo e(__('Back to domains')); ?>

            </a>
        </div>

        <div>
            <h1 class="text-2xl font-bold mb-2"><?php echo e(__('Register Domain: :domain', ['domain' => $domain->domain_name])); ?></h1>
            <p class="text-sm text-gray-500">
                <?php echo e(__('Confirm registrar details and important dates before submitting the registration request.')); ?>

            </p>
        </div>

        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 p-4 rounded">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="bg-red-100 text-red-800 p-4 rounded">
                <ul class="ps-5 list-disc space-y-1">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php
            $registrationDateValue = old('registration_date', $domain->registration_date ? \Illuminate\Support\Carbon::parse($domain->registration_date)->format('Y-m-d') : '');
            $renewalDateValue = old('renewal_date', $domain->renewal_date ? \Illuminate\Support\Carbon::parse($domain->renewal_date)->format('Y-m-d') : '');
        ?>

        <form action="<?php echo e(route('dashboard.domains.register.update', $domain->id)); ?>" method="POST"
            class="bg-white rounded-lg shadow p-6 space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <section class="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div class="space-y-2">
                    <label for="registrar" class="text-sm font-medium text-gray-700">
                        <?php echo e(__('Registrar')); ?>

                    </label>
                    <select id="registrar" name="registrar" class="form-select">
                        <option value=""><?php echo e(__('Select registrar')); ?></option>
                        <?php $__currentLoopData = $registrarOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>"
                                <?php if(old('registrar', $domain->registrar) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="space-y-2">
                    <label for="status" class="text-sm font-medium text-gray-700">
                        <?php echo e(__('Status')); ?>

                    </label>
                    <?php
                        $statusOptions = [
                            'active' => __('Active'),
                            'pending' => __('Pending'),
                            'expired' => __('Expired'),
                        ];
                    ?>
                    <select id="status" name="status" class="form-select">
                        <option value=""><?php echo e(__('Select status')); ?></option>
                        <?php $__currentLoopData = $statusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>"
                                <?php if(old('status', $domain->status) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </section>

            <section class="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div class="space-y-2">
                    <label for="registration_date" class="text-sm font-medium text-gray-700">
                        <?php echo e(__('Registration date')); ?>

                    </label>
                    <input type="date" id="registration_date" name="registration_date"
                        value="<?php echo e($registrationDateValue); ?>" class="form-control">
                </div>
                <div class="space-y-2">
                    <label for="renewal_date" class="text-sm font-medium text-gray-700">
                        <?php echo e(__('Renewal date')); ?>

                    </label>
                    <input type="date" id="renewal_date" name="renewal_date" value="<?php echo e($renewalDateValue); ?>"
                        class="form-control">
                </div>
            </section>

            <section class="space-y-2">
                <label for="register-notes" class="text-sm font-medium text-gray-700">
                    <?php echo e(__('Internal note (optional)')); ?>

                </label>
                <textarea id="register-notes" name="notes" rows="4" class="form-control"
                    placeholder="<?php echo e(__('Include any information the operations team should review before processing.')); ?>"><?php echo e(old('notes')); ?></textarea>
            </section>

            <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div class="text-sm text-gray-500">
                    <?php echo e(__('Submitting will update the domain record. Automated registrar communication will be added in a future release.')); ?>

                </div>
                <div class="flex gap-2">
                    <a href="<?php echo e(route('dashboard.domains.index')); ?>" class="btn btn-secondary">
                        <?php echo e(__('Cancel')); ?>

                    </a>
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Save registration details')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\domains\register.blade.php ENDPATH**/ ?>