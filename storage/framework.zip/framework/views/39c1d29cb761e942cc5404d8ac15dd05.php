<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
        <!-- Breadcrumb Section -->
        <div class="bg-white shadow-sm border-b border-gray-200">
            <div class="container mx-auto px-4 py-4 max-w-7xl">
                <nav class="flex items-center space-x-2 rtl:space-x-reverse text-sm">
                    <a href="<?php echo e(route('dashboard.home')); ?>"
                        class="flex items-center text-blue-600 hover:text-blue-800 transition-colors duration-200">
                        <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                        </svg>
                        <?php echo e(t('dashboard.Home', 'الرئيسية')); ?>

                    </a>
                    <svg class="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd"
                            d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 111.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                            clip-rule="evenodd"></path>
                    </svg>
                    <a href="<?php echo e(route('dashboard.testimonials.index')); ?>"
                        class="text-blue-600 hover:text-blue-800 transition-colors duration-200">
                        <?php echo e(t('dashboard.testimonials', 'التقييمات')); ?>

                    </a>
                    <svg class="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd"
                            d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 111.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                            clip-rule="evenodd"></path>
                    </svg>
                    <span class="text-gray-500">إضافة تقييم جديد</span>
                </nav>
            </div>
        </div>

        <div class="container mx-auto px-4 py-8 max-w-6xl">
            <!-- Header Section -->
            <div class="bg-white rounded-2xl shadow-lg p-6 mb-8 border-l-4 border-green-500">
                <div class="flex items-center space-x-4 rtl:space-x-reverse">
                    <div class="p-3 bg-green-100 rounded-full">
                        <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                        </svg>
                    </div>
                    <div>
                        <h1 class="text-3xl font-bold text-gray-900">إضافة تقييم جديد</h1>
                        <p class="text-gray-600 mt-1">أضف رأياً جديداً من عملائك للحفاظ على الثقة وإبراز جودة خدماتك.</p>
                    </div>
                </div>
            </div>

            <!-- Error Messages -->
            <?php if($errors->any()): ?>
                <div
                    class="bg-gradient-to-r from-red-50 to-pink-50 border-l-4 border-red-400 p-6 rounded-xl mb-8 shadow-sm">
                    <div class="flex items-start">
                        <div class="flex-shrink-0">
                            <svg class="w-6 h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </div>
                        <div class="mr-3">
                            <h3 class="text-red-800 font-semibold mb-2">يرجى مراجعة الأخطاء التالية:</h3>
                            <ul class="list-disc list-inside space-y-1 text-red-700">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Main Form -->
            <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
                <div class="px-8 py-6 bg-gradient-to-r from-gray-50 to-white border-b border-gray-200">
                    <h2 class="text-2xl font-semibold text-gray-800 flex items-center">
                        <svg class="w-6 h-6 ml-2 text-gray-600" fill="none" stroke="currentColor"
                            viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z">
                            </path>
                        </svg>
                        تفاصيل التقييم
                    </h2>
                    <p class="text-gray-600 mt-1">املأ الحقول التالية لإضافة تقييم جديد.</p>
                </div>

                <form action="<?php echo e(route('dashboard.testimonials.store')); ?>" method="POST" enctype="multipart/form-data"
                    class="p-8">
                    <?php echo csrf_field(); ?>
                    <div class="grid grid-cols-12 gap-x-6">
                        <?php echo $__env->make('dashboard.testimonials._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <style>
        /* Input field styling */
        .form-control {
            @apply w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white;
        }

        .form-control:focus {
            @apply shadow-lg border-blue-500 ring-2 ring-blue-200;
        }

        /* Button styling */
        .btn {
            @apply px-6 py-3 rounded-xl font-semibold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2;
        }

        .btn-primary {
            @apply bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 focus:ring-blue-300;
        }

        .btn-secondary {
            @apply bg-gradient-to-r from-gray-500 to-gray-600 hover:from-gray-600 hover:to-gray-700 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 focus:ring-gray-300;
        }

        /* Label styling */
        label {
            @apply text-sm font-semibold text-gray-700 mb-2 block;
        }

        /* Validation message styling */
        .text-red-600 {
            @apply text-red-500 text-sm mt-1 block;
        }

        /* Card border */
        .border {
            @apply border-gray-200 rounded-xl shadow-sm;
        }

        /* Modal appearance */
        .modal-content {
            @apply rounded-2xl border-0 shadow-2xl;
        }

        .modal-header {
            @apply bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-gray-200 rounded-t-2xl;
        }

        .modal-body {
            @apply p-6;
        }

        .modal-footer {
            @apply bg-gray-50 border-t border-gray-200 rounded-b-2xl;
        }

        /* Media picker button */
        #openMediaModalBtn {
            position: relative;
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem 1.5rem;
            border-radius: 1rem;
            font-weight: 600;
            color: #ffffff;
            background: linear-gradient(135deg, #4f46e5, #4338ca);
            box-shadow: 0 15px 30px -12px rgba(79, 70, 229, 0.45);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
        }

        #openMediaModalBtn:hover {
            transform: translateY(-2px);
            background: linear-gradient(135deg, #4338ca, #312e81);
            box-shadow: 0 18px 36px -14px rgba(67, 56, 202, 0.55);
        }

        #openMediaModalBtn:focus {
            outline: none;
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.3);
        }

        #openMediaModalBtn::after {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: 1rem;
            background: radial-gradient(circle at top left, rgba(255, 255, 255, 0.18), transparent 55%);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        #openMediaModalBtn:hover::after {
            opacity: 1;
        }

        #openMediaModalBtn svg {
            width: 1.5rem;
            height: 1.5rem;
        }

        #openMediaModalBtn span {
            font-size: 1rem;
        }
    </style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\testimonials\create.blade.php ENDPATH**/ ?>