<!-- Required -->
<script src="<?php echo e(asset('assets/tamplate/js/header.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/tamplate/js/custoum-script.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/tamplate/js/slider.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/tamplate/js/lang.js')); ?>"></script>

<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<link href="https://unpkg.com/aos@next/dist/aos.css" rel="stylesheet" />
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    AOS.init({
      duration: 800,
      once: true,
      easing: "ease-out",
    });
  });
</script>

</body>
</html><?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/tamplate/layouts/end.blade.php ENDPATH**/ ?>