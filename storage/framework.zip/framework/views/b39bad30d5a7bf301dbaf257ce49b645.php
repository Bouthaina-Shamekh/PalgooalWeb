<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


<div class="container mx-auto py-6">
    <h1 class="text-2xl font-bold mb-4">إدارة المعرض</h1>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create','App\\Models\\Portfolio')): ?>
    <a href="<?php echo e(route('dashboard.portfolios.create')); ?>" class="btn btn-primary mb-4">➕ إضافة معرض جديد</a>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 p-4 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="table-responsive dt-responsive">
        <table class="table table-striped table-bordered nowrap">
            <thead>
                <tr>
                    <th>#</th>
                    <th>الصورة</th>
                    <th>العنوان (<?php echo e(app()->getLocale()); ?>)</th>
                    <th>الحالة</th>
                    <th>النوع</th>
                    <th>الترتيب</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <img src="<?php echo e(asset('storage/' . $portfolio->default_image)); ?>" class="w-10 h-10">
                    </td>
                    <td>
                        <?php echo e($portfolio->translations()->where('locale', app()->getLocale())->first()->title); ?>

                    </td>
                    <td>
                        <?php echo e($portfolio->translations()->where('locale', app()->getLocale())->first()->status); ?></td>
                    <td>
                        <?php echo e($portfolio->translations()->where('locale', app()->getLocale())->first()->type); ?></td>
                    <td><?php echo e($portfolio->order); ?></td>
                    <td style="display: flex; gap: 5px;">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit','App\\Models\\Portfolio')): ?>
                            <a href="<?php echo e(route('dashboard.portfolios.edit', $portfolio->id)); ?>"
                                class="btn btn-sm btn-warning">تعديل</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete','App\\Models\\Portfolio')): ?>
                                <form action="<?php echo e(route('dashboard.portfolios.destroy', $portfolio->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"
                                        class="btn btn-danger">حذف</button>
                                </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($portfolios->links()); ?>

    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\portfolios\index.blade.php ENDPATH**/ ?>