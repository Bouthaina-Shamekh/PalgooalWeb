<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'status' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'status' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $normalized = strtolower((string) $status);
    $variants = [
        'paid' => 'bg-green-100 text-green-800 ring-green-200',
        'unpaid' => 'bg-amber-100 text-amber-800 ring-amber-200',
        'draft' => 'bg-gray-100 text-gray-700 ring-gray-200',
        'cancelled' => 'bg-red-100 text-red-700 ring-red-200',
    ];
    $classes = $variants[$normalized] ?? 'bg-gray-100 text-gray-700 ring-gray-200';
?>

<span <?php echo e($attributes->merge(['class' => "inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs font-semibold ring-1 ring-inset {$classes}"])); ?>>
    <?php echo e(__($status)); ?>

</span>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\components\dashboard\status-badge.blade.php ENDPATH**/ ?>