<?php
    $langCode = $lang->code;
    $panelId = 'lang-panel-' . $langCode;
    $ogImageValue = data_get($translations, $langCode . '.og_image');
    $hasOgImage = filled($ogImageValue);
?>

<div id="<?php echo e($panelId); ?>" role="tabpanel" aria-labelledby="lang-tab-<?php echo e($langCode); ?>"
    wire:key="page-add-lang-<?php echo e($langCode); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-4 space-y-4', 'hidden' => ! $isActive]); ?>">
    <div class="space-y-4">
        <div class="space-y-1">
            <label for="title_<?php echo e($langCode); ?>" class="block text-sm font-semibold text-slate-700 dark:text-slate-200">
                <?php echo e(t('dashboard.Page_Title', 'Page Title')); ?> (<?php echo e($langCode); ?>)
            </label>
            <input id="title_<?php echo e($langCode); ?>" type="text" wire:model.defer="translations.<?php echo e($langCode); ?>.title"
                class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm transition focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-200"
                placeholder="<?php echo e(t('dashboard.Page_Title', 'Page Title')); ?>">
            <?php $__errorArgs = ["translations.{$langCode}.title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-xs text-rose-500"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="space-y-1">
            <label for="slug_<?php echo e($langCode); ?>" class="block text-sm font-semibold text-slate-700 dark:text-slate-200">
                Slug (<?php echo e($langCode); ?>)
            </label>
            <input id="slug_<?php echo e($langCode); ?>" type="text" wire:model.defer="translations.<?php echo e($langCode); ?>.slug"
                class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm transition focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-200"
                placeholder="page-slug" aria-describedby="slug-help-<?php echo e($langCode); ?>">
            <p id="slug-help-<?php echo e($langCode); ?>" class="text-xs text-slate-500 dark:text-slate-400">
                <?php echo e(__('Use lowercase letters, numbers, and dashes only. Leave empty to auto-generate for the main language.')); ?>

            </p>
            <?php $__errorArgs = ["translations.{$langCode}.slug"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-xs text-rose-500"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="space-y-1">
            <label for="content_<?php echo e($langCode); ?>" class="block text-sm font-semibold text-slate-700 dark:text-slate-200">
                <?php echo e(t('dashboard.Page_Content', 'Page Content')); ?> (<?php echo e($langCode); ?>)
            </label>
            <textarea id="content_<?php echo e($langCode); ?>" wire:model.defer="translations.<?php echo e($langCode); ?>.content"
                class="h-48 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm transition focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-200"
                placeholder="<?php echo e(t('dashboard.Page_Content', 'Page Content')); ?>"></textarea>
            <?php $__errorArgs = ["translations.{$langCode}.content"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-xs text-rose-500"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="space-y-3 border-t border-slate-200 pt-4 dark:border-slate-700">
            <h3 class="text-sm font-semibold uppercase tracking-wide text-slate-600 dark:text-slate-400">
                <?php echo e(t('dashboard.SEO_Meta', 'SEO Meta')); ?>

            </h3>

            <div class="space-y-1">
                <label for="meta_title_<?php echo e($langCode); ?>" class="block text-sm font-semibold text-slate-700 dark:text-slate-200">
                    <?php echo e(t('dashboard.Meta_Title', 'Meta Title')); ?> (<?php echo e($langCode); ?>)
                </label>
                <input id="meta_title_<?php echo e($langCode); ?>" type="text"
                    wire:model.defer="translations.<?php echo e($langCode); ?>.meta_title"
                    class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm transition focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-200"
                    placeholder="<?php echo e(t('dashboard.Meta_Title', 'Meta Title')); ?>">
                <?php $__errorArgs = ["translations.{$langCode}.meta_title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-xs text-rose-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="space-y-1">
                <label for="meta_description_<?php echo e($langCode); ?>"
                    class="block text-sm font-semibold text-slate-700 dark:text-slate-200">
                    <?php echo e(t('dashboard.Meta_Description', 'Meta Description')); ?> (<?php echo e($langCode); ?>)
                </label>
                <textarea id="meta_description_<?php echo e($langCode); ?>" rows="2"
                    wire:model.defer="translations.<?php echo e($langCode); ?>.meta_description"
                    class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm transition focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-200"
                    placeholder="<?php echo e(t('dashboard.Short_description_for_search_engines', 'Short description for search engines')); ?>"></textarea>
                <p class="text-xs text-slate-500 dark:text-slate-400">
                    <?php echo e(t('dashboard.Aim_for_50_160_characters', 'Aim for 50-160 characters. Leave empty to reuse the title.')); ?>

                </p>
                <?php $__errorArgs = ["translations.{$langCode}.meta_description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-xs text-rose-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="space-y-1">
                <label for="meta_keywords_<?php echo e($langCode); ?>"
                    class="block text-sm font-semibold text-slate-700 dark:text-slate-200">
                    <?php echo e(t('dashboard.Meta_Keywords', 'Meta Keywords')); ?> (<?php echo e($langCode); ?>)
                </label>
                <input id="meta_keywords_<?php echo e($langCode); ?>" type="text"
                    wire:model.defer="translations.<?php echo e($langCode); ?>.meta_keywords"
                    class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm transition focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-200"
                    placeholder="keyword 1, keyword 2">
                <p class="text-xs text-slate-500 dark:text-slate-400">
                    <?php echo e(t('dashboard.Separate_keywords_with_commas', 'Separate keywords with a comma or Arabic comma (،).')); ?>

                </p>
                <?php $__errorArgs = ["translations.{$langCode}.meta_keywords"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-xs text-rose-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="space-y-1">
                <label for="og_image_input_<?php echo e($langCode); ?>"
                    class="block text-sm font-semibold text-slate-700 dark:text-slate-200">
                    <?php echo e(t('dashboard.Open_Graph_Image_URL', 'Open Graph Image URL')); ?> (<?php echo e($langCode); ?>)
                </label>
                <div class="flex flex-col gap-2 sm:flex-row sm:items-center">
                    <input id="og_image_input_<?php echo e($langCode); ?>" type="text"
                        wire:model.defer="translations.<?php echo e($langCode); ?>.og_image"
                        class="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm transition focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-200"
                        placeholder="https://example.com/og-image.jpg" data-media-input="<?php echo e($langCode); ?>">
                    <button type="button"
                        class="inline-flex items-center justify-center rounded-lg border border-primary px-3 py-2 text-sm font-medium text-primary transition hover:bg-primary/5 focus:outline-none focus:ring-2 focus:ring-primary/40 dark:border-indigo-400 dark:text-indigo-300 dark:hover:bg-indigo-500/10"
                        data-media-modal="pageMediaModal" data-media-locale="<?php echo e($langCode); ?>">
                        <?php echo e(t('dashboard.Choose_from_media', 'Choose from media')); ?>

                    </button>
                </div>
                <p class="text-xs text-slate-500 dark:text-slate-400">
                    <?php echo e(t('dashboard.Use_a_full_URL_or_a_Storage_link_generated_via_asset_Storage_url_Recommended_size_1200x630px', 'Use a full URL or a Storage link generated via asset()/Storage::url(). Recommended size 1200x630px.')); ?>

                </p>
                <?php $__errorArgs = ["translations.{$langCode}.og_image"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-xs text-rose-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="mt-2" data-media-preview-wrapper="<?php echo e($langCode); ?>">
                    <p class="text-xs text-slate-500 dark:text-slate-400" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mb-1', 'hidden' => ! $hasOgImage]); ?>">
                        <?php echo e(t('dashboard.Preview', 'Preview')); ?>

                    </p>
                    <img src="<?php echo e($ogImageValue ?: ''); ?>" alt="OG image preview"
                        data-media-preview="<?php echo e($langCode); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['max-h-32 rounded-lg border border-slate-200 object-cover shadow-sm dark:border-slate-700', 'hidden' => ! $hasOgImage]); ?>">
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\livewire\admin\pages\partials\language-fields.blade.php ENDPATH**/ ?>