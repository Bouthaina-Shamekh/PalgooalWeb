<div class="col-span-12 md:col-span-6">
    <label for="client_id">Client</label>
    <select name="client_id" id="client_id" class="form-select">
        <option value="">Select Client</option>
        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($client->id); ?>" <?php if($domain->client_id == $client->id): echo 'selected'; endif; ?>><?php echo e($client->first_name); ?>

                <?php echo e($client->last_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-span-12 md:col-span-6">
    <div class="mb-3">
        <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['label' => 'Domain Name','value' => $domain->domain_name,'name' => 'domain_name','type' => 'text','placeholder' => 'e.g. example.com or client.palgoals.com']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Domain Name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($domain->domain_name),'name' => 'domain_name','type' => 'text','placeholder' => 'e.g. example.com or client.palgoals.com']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
    </div>
</div>
<div class="col-span-12 md:col-span-6">
    <div class="mb-3">
        <label for="registrar" class="form-label">Registrar Domain</label>
        <select id="registrar" name="registrar" class="form-select">
            <option value="" <?php if($domain->registrar == ''): echo 'selected'; endif; ?>>-- Select Registrar Domain --</option>
            <option value="enom" <?php if($domain->registrar == 'enom'): echo 'selected'; endif; ?>>enom</option>
            <option value="namcheap" <?php if($domain->registrar == 'namcheap'): echo 'selected'; endif; ?>>namcheap</option>
        </select>
    </div>
</div>
<div class="col-span-12 md:col-span-6">
    <div class="mb-3">
        <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['label' => 'Registration Date','value' => $domain->registration_date,'name' => 'registration_date','type' => 'date','placeholder' => 'Registration Date']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Registration Date','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($domain->registration_date),'name' => 'registration_date','type' => 'date','placeholder' => 'Registration Date']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
    </div>
</div>
<div class="col-span-12 md:col-span-6">
    <div class="mb-3">
        <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['label' => 'Renewal Date','value' => $domain->renewal_date,'name' => 'renewal_date','type' => 'date','placeholder' => 'Renewal Date']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Renewal Date','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($domain->renewal_date),'name' => 'renewal_date','type' => 'date','placeholder' => 'Renewal Date']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
    </div>
</div>
<div class="col-span-12 md:col-span-6">
    <div class="mb-3">
        <label for="status" class="form-label">Status</label>
        <select id="status" name="status" class="form-select">
            <option value="">-- Select Registrar Domain --</option>
            <option value="active" <?php if($domain->status == 'active'): echo 'selected'; endif; ?>>active</option>
            <option value="expired" <?php if($domain->status == 'expired'): echo 'selected'; endif; ?>>expired</option>
            <option value="pending" <?php if($domain->status == 'pending'): echo 'selected'; endif; ?>>pending</option>
        </select>
    </div>
</div>
<div class="col-span-12 text-right">
    <a href="<?php echo e(route('dashboard.domains.index')); ?>" class="btn btn-secondary">Cancel</a>
    <button type="submit" class="btn btn-primary">Submit</button>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\domains\_form.blade.php ENDPATH**/ ?>