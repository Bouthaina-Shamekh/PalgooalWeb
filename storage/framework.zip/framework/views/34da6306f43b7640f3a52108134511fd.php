<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">الرئيسية</a></li>
                <li class="breadcrumb-item" aria-current="page">إضافة سيرفر</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">إضافة سيرفر جديد</h2>
            </div>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">بيانات السيرفر</h5>
                </div>
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger mb-4">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('dashboard.servers.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block mb-1">اسم السيرفر</label>
                                <input type="text" name="name" class="form-control" required value="<?php echo e(old('name')); ?>">
                            </div>
                            <div>
                                <label class="block mb-1">نوع اللوحة</label>
                                <select name="type" class="form-control" required>
                                    <option value="cpanel" <?php echo e(old('type') == 'cpanel' ? 'selected' : ''); ?>>cPanel</option>
                                    <option value="directadmin" <?php echo e(old('type') == 'directadmin' ? 'selected' : ''); ?>>DirectAdmin</option>
                                </select>
                            </div>
                            <div>
                                <label class="block mb-1">IP</label>
                                <input type="text" name="ip" class="form-control" value="<?php echo e(old('ip')); ?>">
                            </div>
                            <div>
                                <label class="block mb-1">Hostname</label>
                                <input type="text" name="hostname" class="form-control" value="<?php echo e(old('hostname')); ?>">
                            </div>
                            <div>
                                <label class="block mb-1">اسم المستخدم</label>
                                <input type="text" name="username" class="form-control" value="<?php echo e(old('username')); ?>">
                            </div>
                            <div>
                                <label class="block mb-1">كلمة المرور</label>
                                <input type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>">
                            </div>
                            <div>
                                <label class="block mb-1">API Token</label>
                                <input type="password" name="api_token" class="form-control" value="<?php echo e(old('api_token')); ?>">
                            </div>
                            <div>
                                <label class="block mb-1">الحالة</label>
                                <select name="is_active" class="form-control">
                                    <option value="1" <?php echo e(old('is_active', 1) == 1 ? 'selected' : ''); ?>>مفعل</option>
                                    <option value="0" <?php echo e(old('is_active') == 0 ? 'selected' : ''); ?>>معطل</option>
                                </select>
                            </div>
                        </div>
                        <div class="mt-6 flex gap-2">
                            <button type="submit" class="btn btn-primary">حفظ</button>
                            <a href="<?php echo e(route('dashboard.servers.index')); ?>" class="btn btn-light">إلغاء</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\servers\create.blade.php ENDPATH**/ ?>