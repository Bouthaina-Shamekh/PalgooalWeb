<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="min-h-screen bg-gray-50 dark:bg-gray-950 px-4 py-6">
        
        <header class="mb-6">
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
                <?php echo e(__('Edit Section')); ?>: <?php echo e($page->translation()?->title ?? $page->slug); ?>

            </h1>
            <p class="text-sm text-gray-500 dark:text-gray-400">
                Page Builder v2 – Hero Default section (multi-language JSON content)
            </p>
        </header>

        <form method="POST"
              action="<?php echo e(route('dashboard.pages.sections.update', [$page, $section])); ?>"
              class="space-y-8">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            
            <div class="bg-white dark:bg-gray-900 rounded-xl shadow-sm border border-gray-200 dark:border-gray-800 p-6 space-y-4">
                <h2 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <?php echo e(__('Basic Settings')); ?>

                </h2>

                
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                        <?php echo e(__('Section Type')); ?>

                    </label>
                    <select name="type"
                            class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm">
                        <?php $__currentLoopData = $sectionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>"
                                <?php echo e(old('type', $section->type) === $value ? 'selected' : ''); ?>>
                                <?php echo e($meta['label'] ?? $value); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                        <?php echo e(__('Section Title (Admin / Optional)')); ?>

                    </label>
                    <input type="text"
                           name="admin_title"
                           value="<?php echo e(old('admin_title')); ?>"
                           class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm">
                </div>

                
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                            <?php echo e(__('Display Order')); ?>

                        </label>
                        <input type="number"
                               name="order"
                               value="<?php echo e(old('order', $section->order ?? 1)); ?>"
                               class="mt-1 block w-full  border p-2  mb-1 rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm">
                        <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                            <?php echo e(__('Variant (optional)')); ?>

                        </label>
                        <input type="text"
                               name="variant"
                               value="<?php echo e(old('variant', $section->variant)); ?>"
                               class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm">
                        <?php $__errorArgs = ['variant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="flex items-end">
                        <label class="inline-flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
                            <input type="checkbox"
                                   name="is_active"
                                   value="1"
                                   class="rounded border-gray-300 dark:border-gray-700"
                                   <?php echo e(old('is_active', $section->is_active) ? 'checked' : ''); ?>>
                            <?php echo e(__('Active (visible on the frontend)')); ?>

                        </label>
                    </div>
                </div>
            </div>

            
            <div class="bg-white dark:bg-gray-900 rounded-xl shadow-sm border border-gray-200 dark:border-gray-800 p-6 space-y-6">
                <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    <?php echo e(__('Section Content (per language)')); ?>

                </h2>

                
                <div class="border-b border-gray-200 dark:border-gray-700 mb-4">
                    <nav class="-mb-px flex space-x-4 rtl:space-x-reverse" aria-label="Tabs">
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $active = $index === 0;
                            ?>
                            <button
                                type="button"
                                class="tab-btn px-3 py-2 text-sm font-medium border-b-2
                                       <?php echo e($active
                                            ? 'border-primary text-primary'
                                            : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-300 dark:hover:text-white'); ?>"
                                data-tab="lang-<?php echo e($language->code); ?>">
                                <?php echo e($language->name); ?> (<?php echo e($language->code); ?>)
                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </nav>
                </div>

                
                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $code        = $language->code;
                        $translation = $section->translations->firstWhere('locale', $code);
                        $content     = $translation?->content ?? [];

                        // إعداد قيمة textarea للـ features (من الـ content['features'] كـ array)
                        $featuresTextarea = old("translations.$code.content.features_textarea");

                        if ($featuresTextarea === null) {
                            if (!empty($content['features']) && is_array($content['features'])) {
                                $featuresTextarea = implode("\n", $content['features']);
                            } else {
                                $featuresTextarea = '';
                            }
                        }

                        $mediaTypeOld = old("translations.$code.content.media_type", $content['media_type'] ?? 'image');
                    ?>

                    <div class="tab-panel <?php echo e($index === 0 ? '' : 'hidden'); ?>" id="lang-<?php echo e($code); ?>">
                        
                        <input type="hidden" name="translations[<?php echo e($code); ?>][locale]" value="<?php echo e($code); ?>">

                        
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                                <?php echo e(__('Section title')); ?> (<?php echo e($code); ?>)
                            </label>
                            <input type="text"
                                   name="translations[<?php echo e($code); ?>][title]"
                                   value="<?php echo e(old("translations.$code.title", $translation->title ?? '')); ?>"
                                   class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm">
                        </div>

                        
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                                <?php echo e(__('Eyebrow (small label above title)')); ?>

                            </label>
                            <input type="text"
                                   name="translations[<?php echo e($code); ?>][content][eyebrow]"
                                   value="<?php echo e(old("translations.$code.content.eyebrow", $content['eyebrow'] ?? '')); ?>"
                                   class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm">
                        </div>

                        
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                                <?php echo e(__('Hero Title')); ?>

                            </label>
                            <input type="text"
                                   name="translations[<?php echo e($code); ?>][content][title]"
                                   value="<?php echo e(old("translations.$code.content.title", $content['title'] ?? '')); ?>"
                                   class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm">
                        </div>

                        
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                                <?php echo e(__('Subtitle')); ?>

                            </label>
                            <textarea
                                name="translations[<?php echo e($code); ?>][content][subtitle]"
                                rows="3"
                                class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm"
                            ><?php echo e(old("translations.$code.content.subtitle", $content['subtitle'] ?? '')); ?></textarea>
                        </div>

                        
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                                    <?php echo e(__('Primary Button Label')); ?>

                                </label>
                                <input type="text"
                                       name="translations[<?php echo e($code); ?>][content][primary_button][label]"
                                       value="<?php echo e(old("translations.$code.content.primary_button.label", $content['primary_button']['label'] ?? '')); ?>"
                                       class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                                    <?php echo e(__('Primary Button URL')); ?>

                                </label>
                                <input type="text"
                                       name="translations[<?php echo e($code); ?>][content][primary_button][url]"
                                       value="<?php echo e(old("translations.$code.content.primary_button.url", $content['primary_button']['url'] ?? '')); ?>"
                                       class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm">
                            </div>
                        </div>

                        
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                                    <?php echo e(__('Secondary Button Label')); ?>

                                </label>
                                <input type="text"
                                       name="translations[<?php echo e($code); ?>][content][secondary_button][label]"
                                       value="<?php echo e(old("translations.$code.content.secondary_button.label", $content['secondary_button']['label'] ?? '')); ?>"
                                       class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                                    <?php echo e(__('Secondary Button URL')); ?>

                                </label>
                                <input type="text"
                                       name="translations[<?php echo e($code); ?>][content][secondary_button][url]"
                                       value="<?php echo e(old("translations.$code.content.secondary_button.url", $content['secondary_button']['url'] ?? '')); ?>"
                                       class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm">
                            </div>
                        </div>

                        
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                                <?php echo e(__('Features (each line = one bullet)')); ?>

                            </label>
                            <textarea
                                name="translations[<?php echo e($code); ?>][content][features_textarea]"
                                rows="4"
                                class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm"
                            ><?php echo e($featuresTextarea); ?></textarea>
                            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                                <?php echo e(__('Each line will be converted to a feature item.')); ?>

                            </p>
                        </div>

                        
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                                    <?php echo e(__('Media Type')); ?>

                                </label>
                                <select
                                    name="translations[<?php echo e($code); ?>][content][media_type]"
                                    class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm"
                                >
                                    <option value="image" <?php echo e($mediaTypeOld === 'image' ? 'selected' : ''); ?>>Image</option>
                                    <option value="video" <?php echo e($mediaTypeOld === 'video' ? 'selected' : ''); ?>>Video</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                                    <?php echo e(__('Media URL')); ?>

                                </label>
                                <input type="text"
                                       name="translations[<?php echo e($code); ?>][content][media_url]"
                                       value="<?php echo e(old("translations.$code.content.media_url", $content['media_url'] ?? '')); ?>"
                                       class="mt-1 block w-full rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white text-sm">
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <p class="text-xs text-gray-500 dark:text-gray-400">
                    <?php echo e(__('All fields inside "content" will be stored as JSON and used by the Hero Default front-end component.')); ?>

                </p>
            </div>

            
            <div class="flex items-center justify-between">
                <a href="<?php echo e(route('dashboard.pages.sections.index', $page)); ?>"
                   class="text-sm text-gray-600 dark:text-gray-300 hover:underline">
                    <?php echo e(__('Back to Sections')); ?>

                </a>

                <button type="submit"
                        class="inline-flex items-center justify-center rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-primary/90">
                    <?php echo e(__('Update Section')); ?>

                </button>
            </div>
        </form>
    </div>

    
    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const buttons = document.querySelectorAll('.tab-btn');
                const panels  = document.querySelectorAll('.tab-panel');

                buttons.forEach(btn => {
                    btn.addEventListener('click', () => {
                        const target = btn.getAttribute('data-tab');

                        buttons.forEach(b => {
                            b.classList.remove('border-primary','text-primary');
                            b.classList.add('border-transparent','text-gray-500');
                        });

                        btn.classList.add('border-primary','text-primary');

                        panels.forEach(panel => {
                            panel.classList.toggle('hidden', panel.id !== target);
                        });
                    });
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\pages\sections\edit.blade.php ENDPATH**/ ?>