<div>
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>"><?php echo e(t('dashboard.Home', 'Home')); ?></a>
                </li>
                <li class="breadcrumb-item"><a
                        href="<?php echo e(route('dashboard.languages.index')); ?>"><?php echo e(t('dashboard.All_Pages', 'ALL Pages')); ?></a>
                </li>
                
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0"><?php echo e(t('dashboard.All_Pages', 'ALL Pages')); ?></h2>
            </div>
        </div>
    </div>
    <!-- [ breadcrumb ] end -->

    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
        <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!-- [ Main Content ] start -->
    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card table-card">
                <div class="card-header">
                    <div class="sm:flex items-center justify-between">
                        <h5 class="mb-3 mb-sm-0"><?php echo e(t('dashboard.All_Pages', 'All Pages')); ?></h5>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', 'App\\Models\\Page')): ?>
                            <div>
                                <button wire:click="goToAddPage"
                                    class="btn btn-primary"><?php echo e(t('dashboard.Add_Page', 'Add Page')); ?></button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover" id="pc-dt-simple">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo e(t('dashboard.Title', 'Title')); ?></th>
                                    <th><?php echo e(t('dashboard.Homepage', 'Homepage')); ?></th>
                                    <th><?php echo e(t('dashboard.Status', 'Status')); ?></th>
                                    <th><?php echo e(t('dashboard.Date', 'Date')); ?></th>
                                    <th><?php echo e(t('dashboard.Action', 'Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($p->translation()?->title ?: $p->slug); ?></td>
                                        <td>
                                            <!--[if BLOCK]><![endif]--><?php if($p->is_home): ?>
                                                <span
                                                    class="btn btn-success"><?php echo e(t('dashboard.Current_Homepage', 'Current Homepage')); ?></span>
                                            <?php else: ?>
                                                <button wire:click="setAsHome(<?php echo e($p->id); ?>)"
                                                    class="btn btn-primary">
                                                    <?php echo e(t('dashboard.Make_Homepage', 'Make Homepage')); ?>

                                                </button>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </td>
                                        <td>
                                            <span
                                                class="px-2 py-1 rounded text-xs <?php echo e($p->is_active ? 'bg-green-200 text-green-900' : 'bg-red-200 text-red-900'); ?>">
                                                <?php echo e($p->is_active ? __("\u{0645}\u{0646}\u{0634}\u{0648}\u{0631}\u{0629}") : __("\u{0645}\u{0633}\u{0648}\u{062F}\u{0629}")); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($p->created_at->translatedFormat('Y-m-d h:i A')); ?></td>
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Page')): ?>
                                                <a href="<?php echo e(url($p->slug ?: '/')); ?>"
                                                    class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary"
                                                    target="_blank">
                                                    <i class="ti ti-eye text-xl leading-none"></i>
                                                </a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', 'App\\Models\\Page')): ?>
                                                <button wire:click="edit(<?php echo e($p->id); ?>)"
                                                    class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary">
                                                    <i class="ti ti-edit text-xl leading-none"></i>
                                                </button>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', 'App\\Models\\Page')): ?>
                                                <button onclick="confirmDeletePage(<?php echo e($p->id); ?>)"
                                                    class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary">
                                                    <i class="ti ti-trash text-xl"></i>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- [ Main Content ] end -->
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        function confirmDeletePage(pageId) {
            Swal.fire({
                title: '<?php echo e(__("\u{0647}\u{0644}\u{0020}\u{0623}\u{0646}\u{062A}\u{0020}\u{0645}\u{062A}\u{0623}\u{0643}\u{062F}\u{0020}\u{0645}\u{0646}\u{0020}\u{062D}\u{0630}\u{0641}\u{0020}\u{0627}\u{0644}\u{0635}\u{0641}\u{062D}\u{0629}\u{061F}")); ?>',
                text: '<?php echo e(__("\u{0644}\u{0646}\u{0020}\u{062A}\u{062A}\u{0645}\u{0643}\u{0646}\u{0020}\u{0645}\u{0646}\u{0020}\u{0627}\u{0644}\u{062A}\u{0631}\u{0627}\u{062C}\u{0639}\u{0020}\u{0639}\u{0646}\u{0020}\u{0647}\u{0630}\u{0627}\u{0020}\u{0627}\u{0644}\u{0625}\u{062C}\u{0631}\u{0627}\u{0621}\u{0021}")); ?>',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: '<?php echo e(__("\u{0646}\u{0639}\u{0645}\u{060C}\u{0020}\u{0627}\u{062D}\u{0630}\u{0641}\u{0020}\u{0627}\u{0644}\u{0635}\u{0641}\u{062D}\u{0629}")); ?>',
                cancelButtonText: '<?php echo e(__("\u{0625}\u{0644}\u{063A}\u{0627}\u{0621}")); ?>',
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6'
            }).then((result) => {
                if (result.isConfirmed) {
                    Livewire.dispatch('deleteConfirmed', {
                        id: pageId
                    });
                }
            });
        }

        window.addEventListener('page-deleted-success', () => {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'success',
                title: '<?php echo e(__("\u{062A}\u{0645}\u{0020}\u{062D}\u{0630}\u{0641}\u{0020}\u{0627}\u{0644}\u{0635}\u{0641}\u{062D}\u{0629}\u{0020}\u{0628}\u{0646}\u{062C}\u{0627}\u{062D}\u{002E}")); ?>',
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true
            });
        });

        window.addEventListener('page-delete-failed', () => {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'error',
                title: '<?php echo e(__("\u{062A}\u{0639}\u{0630}\u{0631}\u{0020}\u{062D}\u{0630}\u{0641}\u{0020}\u{0627}\u{0644}\u{0635}\u{0641}\u{062D}\u{0629}\u{002E}")); ?>',
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true
            });
        });
    </script>

    <script>
        function confirmDeleteSection(sectionId) {
            Swal.fire({
                title: '<?php echo e(__("\u{0647}\u{0644}\u{0020}\u{0623}\u{0646}\u{062A}\u{0020}\u{0645}\u{062A}\u{0623}\u{0643}\u{062F}\u{0020}\u{0645}\u{0646}\u{0020}\u{062D}\u{0630}\u{0641}\u{0020}\u{0647}\u{0630}\u{0627}\u{0020}\u{0627}\u{0644}\u{0642}\u{0633}\u{0645}\u{061F}")); ?>',
                text: '<?php echo e(__("\u{0644}\u{0646}\u{0020}\u{062A}\u{062A}\u{0645}\u{0643}\u{0646}\u{0020}\u{0645}\u{0646}\u{0020}\u{0627}\u{0644}\u{062A}\u{0631}\u{0627}\u{062C}\u{0639}\u{0020}\u{0639}\u{0646}\u{0020}\u{0647}\u{0630}\u{0627}\u{0020}\u{0627}\u{0644}\u{0625}\u{062C}\u{0631}\u{0627}\u{0621}\u{0021}")); ?>',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: '<?php echo e(__("\u{0646}\u{0639}\u{0645}\u{060C}\u{0020}\u{0627}\u{062D}\u{0630}\u{0641}\u{0020}\u{0627}\u{0644}\u{0642}\u{0633}\u{0645}")); ?>',
                cancelButtonText: '<?php echo e(__("\u{0625}\u{0644}\u{063A}\u{0627}\u{0621}")); ?>',
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6'
            }).then((result) => {
                if (result.isConfirmed) {
                    Livewire.dispatch('deleteSection', {
                        id: sectionId
                    });
                }
            });
        }

        window.addEventListener('section-deleted-success', () => {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'success',
                title: '<?php echo e(__("\u{062A}\u{0645}\u{0020}\u{062D}\u{0630}\u{0641}\u{0020}\u{0627}\u{0644}\u{0642}\u{0633}\u{0645}\u{0020}\u{0628}\u{0646}\u{062C}\u{0627}\u{062D}\u{002E}")); ?>',
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true
            });
        });

        window.addEventListener('section-delete-failed', () => {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'error',
                title: '<?php echo e(__("\u{062A}\u{0639}\u{0630}\u{0631}\u{0020}\u{062D}\u{0630}\u{0641}\u{0020}\u{0627}\u{0644}\u{0642}\u{0633}\u{0645}\u{002E}")); ?>',
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/livewire/dashboard/pages/index-page.blade.php ENDPATH**/ ?>