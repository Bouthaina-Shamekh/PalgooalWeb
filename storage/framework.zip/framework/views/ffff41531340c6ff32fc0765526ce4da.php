
<?php echo $__env->make('dashboard.layouts.partials..head', [
    'title' => __('Login'),
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- [ Main Content ] start -->

<div class="auth-main relative">
    <div class="auth-wrapper v2 flex items-center w-full h-full min-h-screen">
        <div
            class="auth-form flex items-center justify-center grow flex-col min-h-screen bg-cover relative p-6 bg-theme-cardbg dark:bg-themedark-cardbg">
            <div class="card sm:my-12 w-full max-w-[480px] border-none shadow-none">
                <div class="card-body sm:!p-10">
                    <div class="text-center">
                        <a href="#">
                            <img src="<?php echo e(asset('assets/dashboard/images/logo.png')); ?>" alt="img" class="mx-auto"
                                width="80%" />
                        </a>
                        <div class="grid my-4">
                            <button type="button"
                                class="btn mt-2 flex items-center justify-center gap-2 text-theme-bodycolor dark:text-themedark-bodycolor bg-theme-bodybg dark:bg-themedark-bodybg border border-theme-border dark:border-themedark-border hover:border-primary-500 dark:hover:border-primary-500">
                                <img src="<?php echo e(asset('assets/dashboard/images/authentication/facebook.svg')); ?>"
                                    alt="img" /> <span><?php echo e(__('Sign In with Facebook')); ?></span>
                            </button>
                            <button type="button"
                                class="btn mt-2 flex items-center justify-center gap-2 text-theme-bodycolor dark:text-themedark-bodycolor bg-theme-bodybg dark:bg-themedark-bodybg border border-theme-border dark:border-themedark-border hover:border-primary-500 dark:hover:border-primary-500">
                                <img src="<?php echo e(asset('assets/dashboard/images/authentication/twitter.svg')); ?>"
                                    alt="img" /> <span><?php echo e(__('Sign In with Twitter')); ?></span>
                            </button>
                            <button type="button"
                                class="btn mt-2 flex items-center justify-center gap-2 text-theme-bodycolor dark:text-themedark-bodycolor bg-theme-bodybg dark:bg-themedark-bodybg border border-theme-border dark:border-themedark-border hover:border-primary-500 dark:hover:border-primary-500">
                                <img src="<?php echo e(asset('assets/dashboard/images/authentication/google.svg')); ?>"
                                    alt="img" /> <span><?php echo e(__('Sign In with Google')); ?></span>
                            </button>
                        </div>
                    </div>
                    <div class="relative my-5">
                        <div aria-hidden="true" class="absolute flex inset-0 items-center">
                            <div class="w-full border-t border-theme-border dark:border-themedark-border"></div>
                        </div>
                        <div class="relative flex justify-center">
                            <span class="px-4 bg-theme-cardbg dark:bg-themedark-cardbg"><?php echo e(__('OR')); ?></span>
                        </div>
                    </div>
                    <h4 class="text-center font-medium mb-4"><?php echo e(__('Login with your email')); ?></h4>
                    <form action="<?php echo e(route('login')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <input type="email" name="email" class="form-control" id="floatingInput" placeholder="<?php echo e(__('Email Address')); ?>" />
                        </div>
                        <div class="mb-4">
                            <input type="password" name="password" class="form-control" id="floatingInput1" placeholder="<?php echo e(__('Password')); ?>" />
                        </div>
                        <div class="flex mt-1 justify-between items-center flex-wrap">
                            <div class="form-check">
                                <input class="form-check-input input-primary" type="checkbox"  name="remember" id="remember_me" checked="" />
                                <label class="form-check-label text-muted" for="remember_me"><?php echo e(__('Remember me?')); ?></label>
                            </div>
                            <h6 class="font-normal text-primary-500 mb-0">
                                
                            </h6>
                        </div>
                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary w-full"><?php echo e(__('Login')); ?></button>
                        </div>
                    </form>
                    <div class="flex justify-between items-end flex-wrap mt-4">
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- [ Main Content ] end -->

<style>
    .floting-button{
        display: none;
    }
</style>

<?php echo $__env->make('dashboard.layouts.partials..end', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\auth\login.blade.php ENDPATH**/ ?>