<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'meta' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'meta' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php

    $metaInstance =
        $meta instanceof \App\Support\SeoMeta
            ? $meta
            : (is_null($meta)
                ? \App\Support\SeoMeta::defaults()
                : \App\Support\SeoMeta::fromArray((array) $meta));

    $data = $metaInstance->toArray();
    $title = $data['title'] ?? config('app.name');
    $description = $data['description'] ?? null;
    $keywords = $metaInstance->keywordsString();
    $canonical = $data['canonical'] ?? null;
    $robots = $data['robots'] ?? (config('seo.default_robots') ?? null);
    $type = $data['type'] ?? (config('seo.default_type') ?? 'website');
    $locale = $data['locale'] ?? app()->getLocale();
    $siteName = $data['site_name'] ?? (config('seo.site_name') ?? config('app.name'));
    $twitterCard = $data['twitter_card'] ?? config('seo.twitter.card', 'summary_large_image');
    $twitterHandle = $data['twitter_handle'] ?? config('seo.twitter.handle');
    $alternates = $data['alternates'] ?? [];
    $extraMeta = $data['extra_meta'] ?? [];
    $extraLinks = $data['extra_links'] ?? [];
    $schemaEntries = $data['schema'] ?? [];

    $currentUrl = url()->current();
    if ($canonical === true || $canonical === null) {
        $canonical = $currentUrl;
    }

    $image = $data['image'] ?? null;
    if ($image) {
        $image = \Illuminate\Support\Str::startsWith($image, ['http://', 'https://']) ? $image : asset($image);
    }

    $ogLocale = null;
    if ($locale) {
        $parts = explode('-', $locale);
        $language = strtolower($parts[0] ?? '');
        $region = strtoupper($parts[1] ?? ($language ? $language : ''));
        $ogLocale = trim($language . '_' . $region, '_');
    }
?>

<title><?php echo e($title); ?></title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<?php if($description): ?>
    <meta name="description" content="<?php echo e($description); ?>" />
<?php endif; ?>
<?php if($keywords): ?>
    <meta name="keywords" content="<?php echo e($keywords); ?>" />
<?php endif; ?>
<?php if($robots): ?>
    <meta name="robots" content="<?php echo e($robots); ?>" />
<?php endif; ?>
<?php if($canonical): ?>
    <link rel="canonical" href="<?php echo e($canonical); ?>" />
<?php endif; ?>
<?php if($locale): ?>
    <meta name="language" content="<?php echo e($locale); ?>" />
<?php endif; ?>


<meta property="og:title" content="<?php echo e($title); ?>" />
<?php if($description): ?>
    <meta property="og:description" content="<?php echo e($description); ?>" />
<?php endif; ?>
<meta property="og:type" content="<?php echo e($type); ?>" />
<meta property="og:url" content="<?php echo e($canonical); ?>" />
<?php if($siteName): ?>
    <meta property="og:site_name" content="<?php echo e($siteName); ?>" />
<?php endif; ?>
<?php if($ogLocale): ?>
    <meta property="og:locale" content="<?php echo e($ogLocale); ?>" />
<?php endif; ?>
<?php if($image): ?>
    <meta property="og:image" content="<?php echo e($image); ?>" />
<?php endif; ?>


<?php if($twitterCard): ?>
    <meta name="twitter:card" content="<?php echo e($twitterCard); ?>" />
<?php endif; ?>
<?php if($twitterHandle): ?>
    <meta name="twitter:site" content="<?php echo e($twitterHandle); ?>" />
    <meta name="twitter:creator" content="<?php echo e($twitterHandle); ?>" />
<?php endif; ?>
<meta name="twitter:title" content="<?php echo e($title); ?>" />
<?php if($description): ?>
    <meta name="twitter:description" content="<?php echo e($description); ?>" />
<?php endif; ?>
<?php if($image): ?>
    <meta name="twitter:image" content="<?php echo e($image); ?>" />
<?php endif; ?>
<?php if($canonical): ?>
    <meta name="twitter:url" content="<?php echo e($canonical); ?>" />
<?php endif; ?>


<?php $__currentLoopData = $alternates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $hrefLang = $alternate['locale'] ?? null;
        $href = $alternate['url'] ?? null;
    ?>
    <?php if($hrefLang && $href): ?>
        <link rel="alternate" hreflang="<?php echo e($hrefLang); ?>" href="<?php echo e($href); ?>" />
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $extraMeta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $name = $entry['name'] ?? null;
        $property = $entry['property'] ?? null;
        $content = $entry['content'] ?? null;
    ?>
    <?php if($content !== null): ?>
        <?php if($property): ?>
            <meta property="<?php echo e($property); ?>" content="<?php echo e($content); ?>" />
        <?php elseif($name): ?>
            <meta name="<?php echo e($name); ?>" content="<?php echo e($content); ?>" />
        <?php endif; ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $extraLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $rel = $entry['rel'] ?? null;
        $href = $entry['href'] ?? null;
        $typeAttr = $entry['type'] ?? null;
    ?>
    <?php if($rel && $href): ?>
        <link rel="<?php echo e($rel); ?>" href="<?php echo e($href); ?>"
            <?php if($typeAttr): ?> type="<?php echo e($typeAttr); ?>" <?php endif; ?> />
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $schemaEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $json = is_string($schema)
            ? $schema
            : json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    ?>
    <?php if($json): ?>
        <script type="application/ld+json"><?php echo $json; ?></script>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/components/seo/meta.blade.php ENDPATH**/ ?>