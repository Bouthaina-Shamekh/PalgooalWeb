<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'meta' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'meta' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    use App\Support\SeoMeta;
    use Illuminate\Support\Str;

    $metaInstance = $meta instanceof SeoMeta
        ? $meta
        : (is_null($meta) ? SeoMeta::defaults() : SeoMeta::fromArray((array) $meta));

    $data = $metaInstance->toArray();
    $title = $data['title'] ?? config('app.name');
    $description = $data['description'] ?? null;
    $keywords = $metaInstance->keywordsString();
    $canonical = $data['canonical'] ?? null;
    $robots = $data['robots'] ?? (config('seo.default_robots') ?? null);
    $type = $data['type'] ?? (config('seo.default_type') ?? 'website');
    $locale = $data['locale'] ?? app()->getLocale();
    $siteName = $data['site_name'] ?? (config('seo.site_name') ?? config('app.name'));
    $twitterCard = $data['twitter_card'] ?? config('seo.twitter.card', 'summary_large_image');
    $twitterHandle = $data['twitter_handle'] ?? config('seo.twitter.handle');
    $alternates = $data['alternates'] ?? [];
    $extraMeta = $data['extra_meta'] ?? [];
    $extraLinks = $data['extra_links'] ?? [];
    $schemaEntries = $data['schema'] ?? [];

    $currentUrl = url()->current();
    if ($canonical === true || $canonical === null) {
        $canonical = $currentUrl;
    }

    $image = $data['image'] ?? null;
    if ($image) {
        $image = Str::startsWith($image, ['http://', 'https://']) ? $image : asset($image);
    }

    $ogLocale = null;
    if ($locale) {
        $parts = explode('-', $locale);
        $language = strtolower($parts[0] ?? '');
        $region = strtoupper($parts[1] ?? ($language ? $language : ''));
        $ogLocale = trim($language . '_' . $region, '_');
    }
?>

<title><?php echo e($title); ?></title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<?php if($description): ?>
    <meta name="description" content="<?php echo e($description); ?>" />
<?php endif; ?>
<?php if($keywords): ?>
    <meta name="keywords" content="<?php echo e($keywords); ?>" />
<?php endif; ?>
<?php if($robots): ?>
    <meta name="robots" content="<?php echo e($robots); ?>" />
<?php endif; ?>
<?php if($canonical): ?>
    <link rel="canonical" href="<?php echo e($canonical); ?>" />
<?php endif; ?>
<?php if($locale): ?>
    <meta name="language" content="<?php echo e($locale); ?>" />
<?php endif; ?>


<meta property="og:title" content="<?php echo e($title); ?>" />
<?php if($description): ?>
    <meta property="og:description" content="<?php echo e($description); ?>" />
<?php endif; ?>
<meta property="og:type" content="<?php echo e($type); ?>" />
<meta property="og:url" content="<?php echo e($canonical); ?>" />
<?php if($siteName): ?>
    <meta property="og:site_name" content="<?php echo e($siteName); ?>" />
<?php endif; ?>
<?php if($ogLocale): ?>
    <meta property="og:locale" content="<?php echo e($ogLocale); ?>" />
<?php endif; ?>
<?php if($image): ?>
    <meta property="og:image" content="<?php echo e($image); ?>" />
<?php endif; ?>


<?php if($twitterCard): ?>
    <meta name="twitter:card" content="<?php echo e($twitterCard); ?>" />
<?php endif; ?>
<?php if($twitterHandle): ?>
    <meta name="twitter:site" content="<?php echo e($twitterHandle); ?>" />
    <meta name="twitter:creator" content="<?php echo e($twitterHandle); ?>" />
<?php endif; ?>
<meta name="twitter:title" content="<?php echo e($title); ?>" />
<?php if($description): ?>
    <meta name="twitter:description" content="<?php echo e($description); ?>" />
<?php endif; ?>
<?php if($image): ?>
    <meta name="twitter:image" content="<?php echo e($image); ?>" />
<?php endif; ?>
<?php if($canonical): ?>
    <meta name="twitter:url" content="<?php echo e($canonical); ?>" />
<?php endif; ?>


<?php $__currentLoopData = $alternates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php($hrefLang = $alternate['locale'] ?? null)
    @php($href = $alternate['url'] ?? null)
    @if ($hrefLang && $href)
        <link rel="alternate" hreflang="{{ $hrefLang }}" href="{{ $href }}" />
    @endif
@endforeach

{{-- Extra meta/link entries --}}
@foreach ($extraMeta as $entry)
    @php($name = $entry['name'] ?? null)
    @php($property = $entry['property'] ?? null)
    @php($content = $entry['content'] ?? null)
    @if ($content !== null)
        @if ($property)
            <meta property="{{ $property }}" content="{{ $content }}" />
        @elseif ($name)
            <meta name="{{ $name }}" content="{{ $content }}" />
        @endif
    @endif
@endforeach

@foreach ($extraLinks as $entry)
    @php($rel = $entry['rel'] ?? null)
    @php($href = $entry['href'] ?? null)
    @php($typeAttr = $entry['type'] ?? null)
    @if ($rel && $href)
        <link rel="{{ $rel }}" href="{{ $href }}" @if ($typeAttr) type="{{ $typeAttr }}" @endif />
    @endif
@endforeach

{{-- Structured data --}}
@foreach ($schemaEntries as $schema)
    @php
        $json = is_string($schema) ? $schema : json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    ?>
    <?php if($json): ?>
        <script type="application/ld+json"><?php echo $json; ?></script>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/components/seo/meta.blade.php ENDPATH**/ ?>