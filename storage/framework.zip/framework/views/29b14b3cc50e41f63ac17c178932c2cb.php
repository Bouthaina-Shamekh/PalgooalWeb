<div>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Clients</a></li>
                <li class="breadcrumb-item" aria-current="page">Clients List</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">Clients List</h2>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card table-card">
                <div class="card-header">
                    <div class="sm:flex items-center justify-between">
                        <h5 class="mb-3 sm:mb-0">Clients List</h5>
                        <div>
                           <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create','App\\Models\Client')): ?>
                           <a href="#" wire:click.prevent="showAdd" class="btn btn-primary">Add Client</a>
                           <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="flex items-center justify-between mb-4">
                    <input type="text" wire:model="search" wire:input="updateSearch" placeholder="Search clients..." />
                    <select wire:model="perPage" wire:change="updatePerPage" class="border rounded px-2 py-1">
                        <option value="5">5 per page</option>
                        <option value="10">10 per page</option>
                        <option value="25">25 per page</option>
                    </select>
                </div>
                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Client</th>
                                    <th>Company</th>
                                    <th>Phone</th>
                                    <th>Location</th>
                                    <th>Subscriptions</th>
                                    <th>Domains</th>
                                    <th>Last Login</th>
                                    <th>Joined</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(($clients->firstItem() ?? 1) + $loop->index); ?></td>
                                    <td>
                                        <div class="flex items-center w-44">
                                            <div class="shrink-0">
                                                <img src="<?php echo e($client->avatar ? asset('storage/' . $client->avatar) : asset('assets/images/user/avatar-1.jpg')); ?>"
                                                     alt="<?php echo e(trim(($client->first_name ?? '') . ' ' . ($client->last_name ?? '')) ?: 'Client avatar'); ?>"
                                                     class="rounded-full w-10 h-10 object-cover" />
                                            </div>
                                            <div class="grow ltr:ml-3 rtl:mr-3">
                                                <h6 class="mb-0 font-semibold"><?php echo e($client->first_name); ?> <?php echo e($client->last_name); ?></h6>
                                                <p class="text-sm text-gray-500 mb-0"><?php echo e($client->email); ?></p>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="text-sm"><?php echo e($client->company_name ?: '-'); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-sm"><?php echo e($client->phone ?: '-'); ?></span>
                                    </td>
                                    <td>
                                        <div class="text-sm">
                                            <?php if($client->city || $client->country): ?>
                                                <span><?php echo e($client->city); ?></span>
                                                <?php if($client->city && $client->country): ?><br><?php endif; ?>
                                                <span class="text-gray-500"><?php echo e($client->country); ?></span>
                                            <?php else: ?>
                                                <span class="text-gray-400">-</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="inline-flex items-center justify-center w-8 h-8 bg-blue-100 text-blue-600 rounded-full text-sm font-semibold">
                                            <?php echo e($client->subscriptions_count ?? 0); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <span class="inline-flex items-center justify-center w-8 h-8 bg-green-100 text-green-600 rounded-full text-sm font-semibold">
                                            <?php echo e($client->domains_count ?? 0); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="text-sm">
                                            <?php if($client->last_login_at): ?>
                                                <span class="text-gray-600"><?php echo e($client->last_login_at->diffForHumans()); ?></span>
                                                <br>
                                                <span class="text-xs text-gray-400"><?php echo e($client->last_login_at->format('M j, Y')); ?></span>
                                            <?php else: ?>
                                                <span class="text-gray-400">Never</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="text-sm">
                                            <span class="text-gray-600"><?php echo e($client->created_at->format('M j, Y')); ?></span>
                                            <br>
                                            <span class="text-xs text-gray-400"><?php echo e($client->created_at->diffForHumans()); ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($client->status === 'active'): ?>
                                            <span class="badge bg-success-500/10 text-success-500 rounded-full text-sm px-3 py-1">
                                                <i class="ti ti-check w-3 h-3 mr-1"></i>Active
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-500/10 text-danger-500 rounded-full text-sm px-3 py-1">
                                                <i class="ti ti-ban w-3 h-3 mr-1"></i>Inactive
                                            </span>
                                        <?php endif; ?>

                                        <?php if(!$client->can_login): ?>
                                            <br>
                                            <span class="badge bg-warning-500/10 text-warning-500 rounded-full text-xs px-2 py-1 mt-1">
                                                <i class="ti ti-lock w-2 h-2 mr-1"></i>No Login
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="flex items-center gap-1">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view','App\\Models\\Client')): ?>
                                            <button wire:click="showDetails(<?php echo e($client->id); ?>)"
                                                    class="w-8 h-8 rounded-lg inline-flex items-center justify-center btn-link-secondary hover:bg-blue-50 hover:text-blue-600 transition-colors"
                                                    title="View Details">
                                                <i class="ti ti-eye text-lg leading-none"></i>
                                            </button>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit','App\\Models\\Client')): ?>
                                            <button wire:click="showEdit(<?php echo e($client->id); ?>)"
                                                    class="w-8 h-8 rounded-lg inline-flex items-center justify-center btn-link-secondary hover:bg-yellow-50 hover:text-yellow-600 transition-colors"
                                                    title="Edit Client">
                                                <i class="ti ti-edit text-lg leading-none"></i>
                                            </button>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('login','App\\Models\\Client')): ?>
                                            <button type="button"
                                                    wire:click="loginAs(<?php echo e($client->id); ?>)"
                                                    wire:loading.attr="disabled"
                                                    class="w-8 h-8 rounded-lg inline-flex items-center justify-center btn-link-secondary hover:bg-purple-50 hover:text-purple-600 transition-colors"
                                                    title="Login as Client"
                                                    <?php if(!$client->can_login): ?> disabled aria-disabled="true" <?php endif; ?>>
                                                <i class="ti ti-login text-lg leading-none"></i>
                                            </button>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete','App\\Models\\Client')): ?>
                                            <button wire:click="delete(<?php echo e($client->id); ?>)"
                                                    onclick="confirm('Are you sure you want to delete this client?') || event.stopImmediatePropagation()"
                                                    class="w-8 h-8 rounded-lg inline-flex items-center justify-center btn-link-secondary hover:bg-red-50 hover:text-red-600 transition-colors"
                                                    title="Delete Client">
                                                <i class="ti ti-trash text-lg leading-none"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="11" class="text-center py-8">
                                        <div class="text-gray-500">
                                            <i class="ti ti-users text-4xl mb-2 opacity-50"></i>
                                            <p class="text-lg mb-1">No clients found</p>
                                            <p class="text-sm">Start by adding your first client</p>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="mt-4">
                    <?php echo e($clients->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\livewire\admin\client\index.blade.php ENDPATH**/ ?>