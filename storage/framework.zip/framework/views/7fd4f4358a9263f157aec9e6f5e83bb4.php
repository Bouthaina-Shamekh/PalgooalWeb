<?php echo $__env->make('components.template.layouts.index-layouts', [
    'title' => $title ?? (config('seo.default_title') ?? config('app.name', 'Palgoals')),
    'description' => $description ?? config('seo.default_description'),
    'keywords' => $keywords ?? config('seo.default_keywords', []),
    'ogImage' => $ogImage ?? asset(config('seo.default_image', 'assets/images/default-og.jpg')),
    'seo' => $seo ?? null,
    'slot' => $slot,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\components\front\layouts\index-layouts.blade.php ENDPATH**/ ?>