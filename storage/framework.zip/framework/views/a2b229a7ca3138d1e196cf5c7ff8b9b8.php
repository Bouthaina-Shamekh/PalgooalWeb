<?php
    $sectionComponents = $sectionComponents ?? [];
?>

<?php $__currentLoopData = $builderSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $builderSection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $type = $builderSection['type'] ?? null;
        $component = $sectionComponents[$type] ?? null;

        $data = is_array($builderSection['data'] ?? null) ? $builderSection['data'] : [];

        // ✅ Inject dynamic DB payload only when needed
        if ($type) {
            $data = \App\Support\Sections\SectionQueryResolver::resolve($type, $data);
        }
    ?>

    <?php if($component): ?>
        <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'template.sections.' . $component] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => $data]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
    <?php else: ?>
        
        <?php switch($type):
            case ('text'): ?>
                <section class="py-10 px-4 sm:px-6 lg:px-8">
                    <div class="max-w-4xl mx-auto text-<?php echo e($data['align'] ?? 'left'); ?>">
                        <?php if(!empty($data['title'])): ?>
                            <h2 class="text-2xl font-bold text-slate-900 mb-3"><?php echo e($data['title']); ?></h2>
                        <?php endif; ?>
                        <?php if(!empty($data['body'])): ?>
                            <p class="text-slate-600"><?php echo e($data['body']); ?></p>
                        <?php endif; ?>
                    </div>
                </section>
                <?php break; ?>

            <?php case ('image'): ?>
                <section class="py-8 px-4 sm:px-6 lg:px-8">
                    <div class="max-w-5xl mx-auto text-<?php echo e($data['align'] ?? 'center'); ?>">
                        <figure class="inline-block">
                            <img src="<?php echo e($data['url'] ?? ''); ?>" alt="<?php echo e($data['alt'] ?? ''); ?>"
                                 style="width: <?php echo e($data['width'] ?? '100%'); ?>;">
                            <?php if(!empty($data['alt'])): ?>
                                <figcaption class="text-sm text-slate-500 mt-2"><?php echo e($data['alt']); ?></figcaption>
                            <?php endif; ?>
                        </figure>
                    </div>
                </section>
                <?php break; ?>

            <?php case ('button'): ?>
                <section class="py-6 px-4 sm:px-6 lg:px-8">
                    <div class="max-w-4xl mx-auto text-<?php echo e($data['align'] ?? 'center'); ?>">
                        <?php $isOutline = ($data['style'] ?? 'primary') === 'outline'; ?>
                        <a href="<?php echo e($data['url'] ?? '#'); ?>"
                           class="inline-flex items-center gap-2 px-5 py-3 rounded-full text-sm font-semibold
                                  <?php echo e($isOutline ? 'border border-slate-300 text-slate-800 bg-white' : 'bg-primary text-white shadow'); ?>">
                            <?php echo e($data['text'] ?? __('Button')); ?>

                        </a>
                    </div>
                </section>
                <?php break; ?>

            <?php default: ?>
                
        <?php endswitch; ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\front\pages\_render-builder-sections.blade.php ENDPATH**/ ?>