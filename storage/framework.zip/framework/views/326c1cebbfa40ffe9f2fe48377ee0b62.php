<?php if (isset($component)) { $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $attributes; } ?>
<?php $component = App\View\Components\ClientLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ClientLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header mb-6">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('client.home')); ?>">لوحة العميل</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('client.subscriptions')); ?>">اشتراكاتي</a></li>
                <li class="breadcrumb-item" aria-current="page">Page Builder</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">Page Builder - <?php echo e($page->translations->firstWhere('locale', app()->getLocale())?->title ?? $page->slug); ?></h2>
            </div>
        </div>
    </div>

    <?php if(session('ok')): ?>
        <div class="alert alert-success mb-4"><?php echo e(session('ok')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-4">
            <ul class="list-disc ms-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div class="lg:col-span-4 space-y-4">
            <div class="card p-4">
                <h4 class="font-semibold mb-3">الأقسام</h4>
                <ul id="sectionsList" class="space-y-2" data-reorder-url="<?php echo e(route('client.subscriptions.pages.sections.reorder', [$subscription, $page])); ?>">
                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="border rounded-lg p-3 flex items-center justify-between bg-white cursor-move" data-id="<?php echo e($section->id); ?>">
                            <div>
                                <p class="text-xs text-gray-500 uppercase"><?php echo e($section->type); ?></p>
                                <p class="font-semibold"><?php echo e($section->translations->firstWhere('locale', app()->getLocale())?->title ?? $section->key); ?></p>
                            </div>
                            <a href="<?php echo e(route('client.subscriptions.pages.builder', [$subscription, $page, 'section' => $section->id])); ?>"
                                class="text-sm text-primary hover:underline">تعديل</a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="card p-4">
                <h4 class="font-semibold mb-3">إضافة قسم</h4>
                <form action="<?php echo e(route('client.subscriptions.pages.sections.add', [$subscription, $page])); ?>" method="POST" class="space-y-3">
                    <?php echo csrf_field(); ?>
                    <label class="block text-sm text-gray-600">اختر بلوك</label>
                    <select name="block_key" class="w-full rounded border px-3 py-2">
                        <option value="">-- اختر --</option>
                        <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>"><?php echo e($block['type']); ?> - <?php echo e($block['variant'] ?? $key); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button type="submit" class="btn btn-primary w-full">إضافة</button>
                </form>
            </div>
        </div>

        <div class="lg:col-span-8">
            <div class="card p-4">
                <?php if($selectedSection): ?>
                    <h3 class="text-lg font-semibold mb-3">تعديل القسم: <?php echo e($selectedSection->type); ?></h3>
                    <form action="<?php echo e(route('client.subscriptions.sections.update', [$subscription, $selectedSection])); ?>" method="POST" class="space-y-4" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label class="block text-sm text-gray-600 mb-1">العنوان</label>
                            <input type="text" name="title" value="<?php echo e($selectedSection->translations->firstWhere('locale', app()->getLocale())?->title); ?>"
                                class="w-full rounded border px-3 py-2">
                        </div>

                        <?php if($selectedSection->type === 'hero'): ?>
                            <?php
                                $heroContent = $selectedSection->translations->firstWhere('locale', app()->getLocale())?->content ?? [];
                            ?>
                            <div class="grid md:grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">العنوان الفرعي</label>
                                    <input type="text" name="subtitle" value="<?php echo e($heroContent['subtitle'] ?? ''); ?>" class="w-full rounded border px-3 py-2">
                                </div>
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">نص الزر</label>
                                    <input type="text" name="button_label" value="<?php echo e($heroContent['button_label'] ?? ''); ?>" class="w-full rounded border px-3 py-2">
                                </div>
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">رابط الزر</label>
                                    <input type="text" name="button_url" value="<?php echo e($heroContent['button_url'] ?? ''); ?>" class="w-full rounded border px-3 py-2">
                                </div>
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">صورة الخلفية</label>
                                    <input type="text" name="image" value="<?php echo e($heroContent['image'] ?? ''); ?>" class="w-full rounded border px-3 py-2" placeholder="أو ارفع صورة">
                                    <div class="mt-2">
                                        <input type="file" name="background_image_file" class="text-sm">
                                    </div>
                                </div>
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">لون الخلفية</label>
                                    <input type="color" name="background_color" value="<?php echo e(data_get($heroContent, 'colors.background') ?? '#ef4444'); ?>" class="w-full h-10 rounded border">
                                </div>
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">لون النص</label>
                                    <input type="color" name="text_color" value="<?php echo e(data_get($heroContent, 'colors.text') ?? '#ffffff'); ?>" class="w-full h-10 rounded border">
                                </div>
                            </div>
                        <?php elseif($selectedSection->type === 'menu'): ?>
                            <?php
                                $menuContent = $selectedSection->translations->firstWhere('locale', app()->getLocale())?->content ?? [];
                                $items = $menuContent['items'] ?? [];
                            ?>
                            <div class="space-y-3" id="menuItems">
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="border rounded p-3 grid md:grid-cols-3 gap-2">
                                        <input type="text" name="items[<?php echo e($idx); ?>][name]" value="<?php echo e($item['name'] ?? ''); ?>" class="rounded border px-2 py-1" placeholder="الاسم">
                                        <input type="text" name="items[<?php echo e($idx); ?>][description]" value="<?php echo e($item['description'] ?? ''); ?>" class="rounded border px-2 py-1" placeholder="الوصف">
                                        <input type="text" name="items[<?php echo e($idx); ?>][price]" value="<?php echo e($item['price'] ?? ''); ?>" class="rounded border px-2 py-1" placeholder="السعر">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <button type="button" class="btn btn-outline-primary text-sm" onclick="addMenuItem()">+ إضافة طبق</button>
                            </div>
                            <div class="grid md:grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">لون الخلفية</label>
                                    <input type="color" name="background_color" value="<?php echo e(data_get($menuContent, 'colors.background') ?? '#ffffff'); ?>" class="w-full h-10 rounded border">
                                </div>
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">لون النص</label>
                                    <input type="color" name="text_color" value="<?php echo e(data_get($menuContent, 'colors.text') ?? '#1f2937'); ?>" class="w-full h-10 rounded border">
                                </div>
                            </div>
                        <?php elseif($selectedSection->type === 'testimonials'): ?>
                            <?php
                                $tContent = $selectedSection->translations->firstWhere('locale', app()->getLocale())?->content ?? [];
                                $items = $tContent['items'] ?? [];
                            ?>
                            <div class="space-y-3" id="testimonialItems">
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="border rounded p-3 grid md:grid-cols-3 gap-2">
                                        <input type="text" name="items[<?php echo e($idx); ?>][name]" value="<?php echo e($item['name'] ?? ''); ?>" class="rounded border px-2 py-1" placeholder="الاسم">
                                        <input type="text" name="items[<?php echo e($idx); ?>][text]" value="<?php echo e($item['text'] ?? ''); ?>" class="rounded border px-2 py-1" placeholder="النص">
                                        <input type="number" min="1" max="5" name="items[<?php echo e($idx); ?>][rating]" value="<?php echo e($item['rating'] ?? 5); ?>" class="rounded border px-2 py-1" placeholder="التقييم">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <button type="button" class="btn btn-outline-primary text-sm" onclick="addTestimonial()">+ إضافة شهادة</button>
                            </div>
                            <div class="grid md:grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">لون الخلفية</label>
                                    <input type="color" name="background_color" value="<?php echo e(data_get($tContent, 'colors.background') ?? '#f9fafb'); ?>" class="w-full h-10 rounded border">
                                </div>
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">لون النص</label>
                                    <input type="color" name="text_color" value="<?php echo e(data_get($tContent, 'colors.text') ?? '#111827'); ?>" class="w-full h-10 rounded border">
                                </div>
                            </div>
                        <?php else: ?>
                            <p class="text-sm text-gray-500">لا يوجد محرر لهذا النوع بعد. يمكنك إضافة التعديلات من لوحة التطوير.</p>
                        <?php endif; ?>

                        <div class="flex items-center gap-3">
                            <button type="submit" class="btn btn-primary">حفظ التعديلات</button>
                            <?php if(app()->environment('local')): ?>
                                <a class="text-sm text-primary" href="<?php echo e(route('tenant.preview', $subscription->id)); ?>" target="_blank">معاينة في تبويب جديد</a>
                            <?php endif; ?>
                        </div>
                    </form>
                <?php else: ?>
                    <p class="text-gray-500">لا توجد أقسام بعد.</p>
                <?php endif; ?>
            </div>
            <?php if(app()->environment('local')): ?>
                <div class="card p-4 mt-4">
                    <div class="flex items-center justify-between mb-3">
                        <div>
                            <h4 class="font-semibold">معاينة حية</h4>
                            <p class="text-xs text-gray-500">يتم إعادة تحميلها بعد الحفظ.</p>
                        </div>
                        <button type="button" onclick="reloadPreview()" class="btn btn-sm btn-outline-primary">إعادة تحميل</button>
                    </div>
                    <div class="aspect-[16/9] border rounded-xl overflow-hidden bg-gray-50">
                        <iframe id="tenantPreviewFrame"
                            src="<?php echo e(route('tenant.preview.page', [$subscription->id, $page->slug])); ?>"
                            class="w-full h-full" frameborder="0"></iframe>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
    <script>
        const list = document.getElementById('sectionsList');
        if (list) {
            Sortable.create(list, {
                animation: 150,
                onEnd: function() {
                    const ids = Array.from(list.querySelectorAll('[data-id]')).map(li => li.dataset.id);
                    fetch(list.dataset.reorderUrl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: JSON.stringify({ order: ids })
                    });
                }
            });
        }
        function addMenuItem() {
            const wrapper = document.getElementById('menuItems');
            const idx = wrapper.querySelectorAll('.grid').length;
            const div = document.createElement('div');
            div.className = 'border rounded p-3 grid md:grid-cols-3 gap-2';
            div.innerHTML = `
                <input type="text" name="items[\${idx}][name]" class="rounded border px-2 py-1" placeholder="الاسم">
                <input type="text" name="items[\${idx}][description]" class="rounded border px-2 py-1" placeholder="الوصف">
                <input type="text" name="items[\${idx}][price]" class="rounded border px-2 py-1" placeholder="السعر">`;
            wrapper.insertBefore(div, wrapper.lastElementChild);
        }
        function addTestimonial() {
            const wrapper = document.getElementById('testimonialItems');
            const idx = wrapper.querySelectorAll('.grid').length;
            const div = document.createElement('div');
            div.className = 'border rounded p-3 grid md:grid-cols-3 gap-2';
            div.innerHTML = `
                <input type="text" name="items[\${idx}][name]" class="rounded border px-2 py-1" placeholder="الاسم">
                <input type="text" name="items[\${idx}][text]" class="rounded border px-2 py-1" placeholder="النص">
                <input type="number" min="1" max="5" name="items[\${idx}][rating]" value="5" class="rounded border px-2 py-1" placeholder="التقييم">`;
            wrapper.insertBefore(div, wrapper.lastElementChild);
        }

        <?php if(session('ok') && app()->environment('local')): ?>
            document.addEventListener('DOMContentLoaded', () => {
                reloadPreview();
            });
        <?php endif; ?>

        function reloadPreview() {
            const frame = document.getElementById('tenantPreviewFrame');
            if (frame) {
                frame.src = frame.src;
            }
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $attributes = $__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $component = $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?><?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\client\subscriptions\pages\builder.blade.php ENDPATH**/ ?>