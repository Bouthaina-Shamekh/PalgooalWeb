<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['variant' => 'front']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['variant' => 'front']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?> 
<?php
    use Illuminate\Support\Facades\View;

    $request = request();
    $currentRoute = request()->route()?->getName();
    $slug = request()->route('slug');
    $currentLocale = app()->getLocale();
    $sharedPage = View::shared('currentPage', null);
    $currentUrl = $request->fullUrlWithoutQuery(['change-locale']);
    $buildLocaleUrl = static function (string $url, string $locale): string {
        $separator = str_contains($url, '?') ? '&' : '?';

        return $url . $separator . 'change-locale=' . urlencode($locale);
    };

    $buttonClass = match ($variant) {
        'builder'
            => 'flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-semibold text-slate-700 bg-slate-100 rounded-full hover:bg-slate-200',
        'topbar' => 'flex items-center gap-2 hover:text-red-brand transition-all duration-300 text-sm md:text-base',
        default
            => 'flex items-center gap-1 text-primary dark:text-white font-semibold hover:text-secondary dark:hover:text-yellow-400 text-sm',
    };

    $menuClass = match ($variant) {
        'builder'
            => 'absolute mt-2 w-40 bg-white border border-slate-200 rounded-xl shadow-lg z-40 py-1 rtl:right-0 rtl:left-auto ltr:left-0 ltr:right-auto',
        'topbar'
            => 'absolute top-full ltr:right-0 rtl:left-0 mt-2 min-w-[140px] bg-white border border-gray-200 rounded-xl shadow-lg z-[100] overflow-hidden',
        default
            => 'absolute left-0 mt-2 w-28 bg-white dark:bg-[#2c2c2c] border border-gray-200 dark:border-gray-700 rounded-md shadow-md z-40',
    };

    $itemClass = match ($variant) {
        'builder' => 'block w-full text-right px-3 py-1.5 text-[12px] hover:bg-slate-100 rounded-lg',
        'topbar'
            => 'block w-full ltr:text-left rtl:text-right px-4 py-3 text-purple-brand hover:bg-gray-100 transition-colors text-sm font-medium',
        default => 'block w-full text-right px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-white/20',
    };

    $activeItemClass = $variant === 'topbar' ? 'bg-gray-100 font-semibold' : 'bg-slate-100 dark:bg-white/10 font-bold';

    $showFlags = $variant !== 'builder';
?>

<div class="relative group" id="lang-container">
    <button id="lang-switch" class="<?php echo e($buttonClass); ?>" type="button" aria-haspopup="true" aria-controls="lang-menu">
        <?php if($variant === 'builder'): ?>
            <span class="uppercase tracking-wide"><?php echo e($currentLanguage?->code ?? strtoupper($currentLocale)); ?></span>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5 text-slate-500" fill="none" viewBox="0 0 24 24"
                stroke="currentColor" stroke-width="1.5" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 21a9 9 0 100-18 9 9 0 000 18z" />
                <path stroke-linecap="round" stroke-linejoin="round"
                    d="M3.6 9h16.8M3.6 15h16.8M12 3c2.5 2.6 3.9 5.6 3.9 9s-1.4 6.4-3.9 9c-2.5-2.6-3.9-5.6-3.9-9S9.5 5.6 12 3z" />
            </svg>
        <?php elseif($variant === 'topbar'): ?>
            <svg class="h-4" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path opacity="0.6"
                    d="M8.5 16.5C12.9183 16.5 16.5 12.9183 16.5 8.5C16.5 4.08172 12.9183 0.5 8.5 0.5M8.5 16.5C4.08172 16.5 0.5 12.9183 0.5 8.5C0.5 4.08172 4.08172 0.5 8.5 0.5M8.5 16.5C10.6818 16.5 11.4091 12.8636 11.4091 8.5C11.4091 4.13636 10.6818 0.5 8.5 0.5M8.5 16.5C6.31818 16.5 5.59091 12.8636 5.59091 8.5C5.59091 4.13636 6.31818 0.5 8.5 0.5M1.22727 11.4091H15.7727M1.22727 5.59091H15.7727"
                    stroke="white" />
            </svg>
            <span><?php echo e($currentLanguage?->native ?? strtoupper($currentLocale)); ?></span>
            <svg class="h-3 w-3 opacity-70" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11.914 6.457"
                aria-hidden="true">
                <path d="M10.5,0,5.25,5.25,0,0" fill="none" stroke="currentColor" stroke-linecap="round"
                    stroke-linejoin="round" stroke-width="1" />
            </svg>
        <?php else: ?>
            <?php if($currentLanguage?->flag): ?>
                <img src="<?php echo e(asset($currentLanguage->flag)); ?>" alt="<?php echo e($currentLanguage->native); ?>"
                    class="inline w-4 h-4 mr-1">
            <?php endif; ?>
            <span><?php echo e($currentLanguage?->native ?? strtoupper($currentLocale)); ?></span>
        <?php endif; ?>
    </button>

    <div id="lang-menu"
        class="<?php echo e($menuClass); ?> opacity-0 invisible group-hover:opacity-100 group-hover:visible md:transition-all md:duration-200">

        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $redirectUrl = '#';

                if ($sharedPage && $lang->code !== $currentLocale) {
                    $translatedPage = $sharedPage->translations->firstWhere('locale', $lang->code);
                    $translatedSlug = $translatedPage?->slug;

                    if ($sharedPage->is_home) {
                        $redirectUrl = $buildLocaleUrl(url('/'), $lang->code);
                    } elseif ($translatedSlug) {
                        $redirectUrl = $buildLocaleUrl(url($translatedSlug), $lang->code);
                    } else {
                        $redirectUrl = $buildLocaleUrl($currentUrl ?: url('/'), $lang->code);
                    }
                } elseif ($currentRoute === 'template.show' && $slug && $lang->code !== $currentLocale) {
                    $template = \App\Models\Template::with('translations')
                        ->whereHas('translations', function ($q) use ($slug) {
                            $q->where('slug', $slug);
                        })
                        ->first();

                    $translatedSlug = $template?->translations->firstWhere('locale', $lang->code)?->slug;

                    if ($translatedSlug) {
                        $redirectUrl = $buildLocaleUrl(route('template.show', ['slug' => $translatedSlug]), $lang->code);
                    }
                } elseif ($currentRoute === 'portfolio.show' && $slug && $lang->code !== $currentLocale) {
                    $portfolio = \App\Models\Portfolio::with('translations')
                        ->whereHas('translations', function ($q) use ($slug) {
                            $q->where('slug', $slug);
                        })
                        ->orWhere('slug', $slug)
                        ->first();

                    $translatedSlug = $portfolio?->translations->firstWhere('locale', $lang->code)?->slug;

                    if ($translatedSlug) {
                        $redirectUrl = $buildLocaleUrl(route('portfolio.show', ['slug' => $translatedSlug]), $lang->code);
                    }
                } elseif ($lang->code !== $currentLocale) {
                    $redirectUrl = $buildLocaleUrl($currentUrl ?: url('/'), $lang->code);
                }
            ?>

            <a href="<?php echo e($redirectUrl); ?>"
                class="<?php echo e($itemClass); ?> <?php echo e($lang->code === $currentLocale ? $activeItemClass : ''); ?>">
                <?php if($showFlags && $lang->flag): ?>
                    <img src="<?php echo e(asset($lang->flag)); ?>" alt="<?php echo e($lang->native); ?>" class="inline w-4 h-4 mr-1">
                <?php endif; ?>
                <?php echo e($lang->native); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/components/lang/language-switcher.blade.php ENDPATH**/ ?>