﻿<section class="border rounded-2xl shadow-sm p-6">
    <div class="flex items-center justify-between mb-4">
        <div>
            <p class="text-xs uppercase text-gray-400 mb-1"><?php echo e($section->key ?? 'Section'); ?></p>
            <h2 class="text-xl font-semibold"><?php echo e($translation->title ?? __('قسم بدون عنوان')); ?></h2>
        </div>
        <span class="text-xs text-gray-300">#<?php echo e($section->sort_order); ?></span>
    </div>

    <?php
        $isArray = is_array($content);
    ?>

    <?php if($isArray): ?>
        <div class="space-y-3 text-sm text-gray-600">
            <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-gray-50 rounded-lg p-3">
                    <p class="text-xs text-gray-400"><?php echo e(is_string($key) ? $key : 'item'); ?></p>
                    <pre class="whitespace-pre-wrap text-sm"><?php echo e(is_array($value) ? json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) : $value); ?></pre>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php elseif(!empty($content)): ?>
        <p class="text-sm text-gray-600"><?php echo e($content); ?></p>
    <?php else: ?>
        <p class="text-sm text-gray-400"><?php echo e(__('لا توجد بيانات بعد لهذا القسم.')); ?></p>
    <?php endif; ?>
</section>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\tenant\sections\generic.blade.php ENDPATH**/ ?>