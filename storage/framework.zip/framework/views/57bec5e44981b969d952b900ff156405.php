<div class="space-y-6">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><?php echo e(t('dashboard.Home', 'Home')); ?></a></li>
                <li class="breadcrumb-item" aria-current="page"><?php echo e(t('dashboard.Templates_Management', 'Templates Management')); ?></li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0"><?php echo e(t('dashboard.Templates_Management', 'Templates Management')); ?></h2>
            </div>
        </div>
    </div>
    <!-- [ breadcrumb ] end -->

    <?php if(session()->has('success')): ?>
        <div class="px-4 py-2 text-green-800 bg-green-100 border border-green-300 rounded shadow-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    
<?php if($errors->any()): ?>
    <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg border border-red-400" role="alert">
        <span class="font-bold">حدث خطأ في التحقق من الصحة!</span>
        <ul class="mt-2 list-disc list-inside">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>



    <!-- [ Main Content ] start -->
    <div class="grid grid-cols-12 gap-6">
        <!-- [ form-element ] start -->
        <div class="col-span-12 lg:col-span-7">
            <form wire:submit.prevent="save" class="card">
                <div class="card-header">
                    <h5><?php echo e($mode === 'edit' ? t('dashboard.Edit_Template', 'Edit Template') : t('dashboard.Add_New_Template', 'Add New Template')); ?></h5>
                </div>
                <div class="card-body">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-4">
                            <div class="mb-3">
                                <label for="category" class="form-label"><?php echo e(t('dashboard.Category', 'Category')); ?></label>
                                <select id="category" wire:model="category_template_id" class="form-select">
                                    <option value=""><?php echo e(t('dashboard.Select_Category', 'Select Category')); ?></option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>">
                                            <?php echo e($category->getTranslation()?->name ?? $category->getTranslation('en')?->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['category_template_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500 form-text"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="price" class="form-label"><?php echo e(t('dashboard.Price', 'Price')); ?></label>
                                <input type="number" step="0.01" id="price" wire:model="price" class="form-control" placeholder="e.g., 99.99">
                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500 form-text"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="space-y-2">
                            <label class="form-label"><?php echo e(t('dashboard.Template_Image', 'Template Image')); ?></label>
                            <div class="flex items-center gap-4">
                                <?php if($image): ?>
                                    <img src="<?php echo e($image->temporaryUrl()); ?>" class="object-cover w-24 h-24 rounded-lg">
                                <?php elseif($existing_image_url): ?>
                                    <img src="<?php echo e(asset('storage/' . $existing_image_url)); ?>" class="object-cover w-24 h-24 rounded-lg">
                                <?php endif; ?>
                                <input type="file" wire:model="image" class="form-control">
                            </div>
                            <div wire:loading wire:target="image" class="mt-1 text-sm text-blue-500"><?php echo e(t('dashboard.Uploading', 'Uploading')); ?>...</div>
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500 form-text"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <hr class="my-6">

                    
                    <h6 class="mb-4 text-lg font-semibold"><?php echo e(t('dashboard.Offer_Details', 'Offer Details')); ?></h6>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="mb-3">
                            <label for="discount_price" class="form-label"><?php echo e(t('dashboard.Discount_Price', 'Discount Price')); ?></label>
                            <input type="number" step="0.01" id="discount_price" wire:model="discount_price" class="form-control" placeholder="e.g., 49.99">
                            <?php $__errorArgs = ['discount_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500 form-text"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="discount_ends_at" class="form-label"><?php echo e(t('dashboard.Discount_Ends_At', 'Discount Ends At')); ?></label>
                            <input type="datetime-local" id="discount_ends_at" wire:model="discount_ends_at" class="form-control">
                            <?php $__errorArgs = ['discount_ends_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500 form-text"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    

                    <hr class="my-6">

                    
                    <h6 class="mb-4 text-lg font-semibold"><?php echo e(t('dashboard.Translations', 'Translations')); ?></h6>
                    <ul class="flex mb-4 border-b space-x-2 rtl:space-x-reverse">
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <button type="button" wire:click="$set('activeLang', '<?php echo e($lang->code); ?>')"
                                    class="px-4 py-2 rounded-t-lg text-sm <?php echo e($activeLang === $lang->code ? 'bg-gray-50 border-t border-l border-r font-semibold text-indigo-600' : 'bg-gray-200 hover:bg-gray-300'); ?>">
                                    <?php echo e($lang->name); ?>

                                </button>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div wire:key="trans-<?php echo e($lang->code); ?>" <?php if($activeLang !== $lang->code): ?> style="display: none;" <?php endif; ?>>
                            <div class="space-y-4">
                                <div class="mb-3">
                                    <label class="form-label"><?php echo e(t('dashboard.Template_Name', 'Template Name')); ?></label>
                                    <input type="text" wire:model="translations.<?php echo e($lang->code); ?>.name" class="form-control">
                                    <?php $__errorArgs = ["translations.{$lang->code}.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500 form-text"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label"><?php echo e(t('dashboard.Slug_for_language', 'Slug for language')); ?> (<?php echo e($lang->name); ?>)</label>
                                    <input type="text" wire:model="translations.<?php echo e($lang->code); ?>.slug" class="form-control">
                                    <?php $__errorArgs = ["translations.{$lang->code}.slug"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500 form-text"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label"><?php echo e(t('dashboard.Preview_URL_for_language', 'Preview URL for language')); ?> (<?php echo e($lang->name); ?>)</label>
                                    <input type="url" wire:model="translations.<?php echo e($lang->code); ?>.preview_url" class="form-control" placeholder="https://example.com/template-preview-<?php echo e($lang->code); ?>">
                                    <?php $__errorArgs = ["translations.{$lang->code}.preview_url" ];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500 form-text"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label"><?php echo e(t('dashboard.Description', 'Description')); ?></label>
                                    <textarea wire:model="translations.<?php echo e($lang->code); ?>.description" class="form-control" rows="4"></textarea>
                                </div>
                                <div class="p-4 border rounded-lg bg-slate-50">
                                    <div class="flex items-center justify-between mb-3">
                                        <h6 class="font-semibold"><?php echo e(t('dashboard.Features', 'Features')); ?></h6>
                                        <button type="button" wire:click="addFeature('<?php echo e($lang->code); ?>')" class="text-sm btn btn-success-light btn-sm">+ <?php echo e(t('dashboard.Add_Feature', 'Add Feature')); ?></button>
                                    </div>
                                    <div class="space-y-3">
                                        <?php $__currentLoopData = $translations[$lang->code]['details']['features'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div wire:key="feature-<?php echo e($lang->code); ?>-<?php echo e($index); ?>" class="flex items-center gap-2 p-2 border rounded bg-white">
                                                <input type="text" wire:model="translations.<?php echo e($lang->code); ?>.details.features.<?php echo e($index); ?>.icon" class="w-16 form-control" placeholder="🎨">
                                                <input type="text" wire:model="translations.<?php echo e($lang->code); ?>.details.features.<?php echo e($index); ?>.title" class="w-full form-control" placeholder="<?php echo e(t('dashboard.Feature_Title', 'Feature Title')); ?>">
                                                <button type="button" wire:click="removeFeature('<?php echo e($lang->code); ?>', <?php echo e($index); ?>)" class="text-red-500 hover:text-red-700">
                                                    <i class="ti ti-trash"></i>
                                                </button>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="p-4 border rounded-lg bg-slate-50">
                                    <div class="flex items-center justify-between mb-3">
                                        <h6 class="font-semibold"><?php echo e(t('dashboard.Specifications', 'Specifications')); ?></h6>
                                        <button type="button" wire:click="addSpecification('<?php echo e($lang->code); ?>')" class="text-sm btn btn-success-light btn-sm">+ <?php echo e(t('dashboard.Add_Specification', 'Add Specification')); ?></button>
                                    </div>
                                    <div class="space-y-3">
                                        <?php $__currentLoopData = $translations[$lang->code]['details']['specifications'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div wire:key="spec-<?php echo e($lang->code); ?>-<?php echo e($index); ?>" class="flex items-center gap-2 p-2 border rounded bg-white">
                                                <input type="text" wire:model="translations.<?php echo e($lang->code); ?>.details.specifications.<?php echo e($index); ?>.key" class="w-1/3 form-control" placeholder="<?php echo e(t('dashboard.Spec_Key', 'SpecKey')); ?>">
                                                <input type="text" wire:model="translations.<?php echo e($lang->code); ?>.details.specifications.<?php echo e($index); ?>.value" class="w-2/3 form-control" placeholder="<?php echo e(t('dashboard.Spec_Value', 'Spec Value')); ?>">
                                                <button type="button" wire:click="removeSpecification('<?php echo e($lang->code); ?>', <?php echo e($index); ?>)" class="text-red-500 hover:text-red-700">
                                                    <i class="ti ti-trash"></i>
                                                </button>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="p-4 mt-4 text-left bg-gray-50 card-footer">
                    <button type="submit" wire:loading.attr="disabled" class="btn btn-primary">
                        <span wire:loading.remove wire:target="save"><?php echo e($mode === 'edit' ? t('dashboard.Save_Changes', 'Save Changes') : t('dashboard.Add_Template', 'Add Template')); ?></span>
                        <span wire:loading wire:target="save"><?php echo e(t('dashboard.Saving', 'Saving')); ?>...</span>
                    </button>
                    <?php if($mode === 'edit'): ?>
                        <button type="button" wire:click="resetForm" class="btn btn-secondary"><?php echo e(t('dashboard.Cancel', 'Cancel')); ?></button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        <!-- [ form-element ] end -->

        <!-- [ list-element ] start -->
        <div class="col-span-12 lg:col-span-5">
            <div class="card">
                <div class="card-header">
                    <h5><?php echo e(t('dashboard.Current_Templates', 'Current Templates')); ?></h5>
                </div>
                <div class="card-body">
                    <ul class="space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li wire:key="tpl-<?php echo e($template->id); ?>" class="flex items-start justify-between p-3 bg-gray-100 rounded-lg">
                                <div class="flex items-center gap-4">
                                    <img src="<?php echo e(asset('storage/' . $template->image)); ?>" class="object-cover w-16 h-16 rounded-md">
                                    <div>
                                        <strong class="text-gray-800"><?php echo e($template->getTranslation()?->name ?? $template->getTranslation('en')?->name); ?></strong>
                                        <p class="text-sm text-gray-600"><?php echo e($template->categoryTemplate?->getTranslation()?->name ?? $template->categoryTemplate?->getTranslation('en')?->name ?? 'Uncategorized'); ?></p>
                                        <div class="flex items-baseline gap-2 mt-1">
                                            <?php if($template->discount_price && ($template->discount_ends_at ? $template->discount_ends_at->isFuture() : true)): ?>
                                                <p class="text-sm font-bold text-red-600">$<?php echo e(number_format($template->discount_price, 2)); ?></p>
                                                <p class="text-xs text-gray-500 line-through">$<?php echo e(number_format($template->price, 2)); ?></p>
                                            <?php else: ?>
                                                <p class="text-sm font-bold text-blue-600">$<?php echo e(number_format($template->price, 2)); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex items-center gap-2">
                                    <button wire:click="edit(<?php echo e($template->id); ?>)" class="w-8 h-8 inline-flex items-center justify-center text-yellow-600 rounded-xl hover:bg-yellow-100">
                                        <i class="ti ti-edit text-xl leading-none"></i>
                                    </button>
                                    <button onclick="confirm('هل أنت متأكد من الحذف؟') || event.stopImmediatePropagation()" wire:click="confirmDelete(<?php echo e($template->id); ?>)" class="w-8 h-8 inline-flex items-center justify-center text-red-600 rounded-xl hover:bg-red-100">
                                        <i class="ti ti-trash text-xl"></i>
                                    </button>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-center text-gray-500"><?php echo e(t('dashboard.No_templates_found', 'No templates found')); ?></p>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <!-- [ list-element ] end -->
        <div class="mt-4">
    <?php echo e($templates->links()); ?>

</div>
    </div>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\livewire\admin\template\template-management.blade.php ENDPATH**/ ?>