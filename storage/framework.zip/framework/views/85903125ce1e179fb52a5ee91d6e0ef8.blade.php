<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
@props(['defaultTlds','fallbackPrices','currency'])
<x-template.sections.search-domain :default-tlds="$defaultTlds" :fallback-prices="$fallbackPrices" :currency="$currency" >

{{ $slot ?? "" }}
</x-template.sections.search-domain>