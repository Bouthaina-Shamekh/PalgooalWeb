<?php if(session()->has($type)): ?>
    <div class="col-12 mb-4">
        <div class="alert alert-<?php echo e($type); ?> alert-dismissible fade show" role="alert">
            <?php if(is_array(session($type))): ?>
            <ul class="list-group" style="    height: 60px; overflow: hidden;">
                <?php $__currentLoopData = session($type); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="btn btn-info" data-toggle="modal" data-target="#logModal">
                <span aria-hidden="true">عرض الكل</span>
            </button>
            <?php elseif(is_string(session($type))): ?>
                <?php echo e(session($type)); ?>

            <?php endif; ?>
        </div>
    </div> <!-- /. col -->
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\components\alart.blade.php ENDPATH**/ ?>