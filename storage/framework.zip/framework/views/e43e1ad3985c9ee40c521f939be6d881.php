<!-- Breadcrumb -->
<?php if(!empty($items)): ?>
    <div class="relative z-10 mt-6">
        <nav class="text-sm text-white/80" aria-label="Breadcrumb">
            <ol class="flex flex-wrap justify-center items-center gap-2 ">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php if(!isset($item['url']) || $loop->last): ?>
                            <span class="text-white font-semibold"><?php echo e($item['title']); ?></span>
                            <?php else: ?>
                            <a href="<?php echo e($item['url']); ?>" class="hover:underline text-white font-semibold"><?php echo e($item['title']); ?></a>
                        <?php endif; ?>
                    </li>
                    <?php if(!$loop->last): ?>
                        <span class="mx-2">/</span>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        </nav>
    </div>
<?php endif; ?>


            



<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\components\breadcrumb.blade.php ENDPATH**/ ?>