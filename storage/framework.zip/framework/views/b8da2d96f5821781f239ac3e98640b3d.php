<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => config('seo.default_title') ?? config('app.name', 'Palgoals'),
    'description' => config('seo.default_description'),
    'keywords' => config('seo.default_keywords', []),
    'ogImage' => asset(config('seo.default_image', 'assets/images/default-og.jpg')),
    'seo' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => config('seo.default_title') ?? config('app.name', 'Palgoals'),
    'description' => config('seo.default_description'),
    'keywords' => config('seo.default_keywords', []),
    'ogImage' => asset(config('seo.default_image', 'assets/images/default-og.jpg')),
    'seo' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    use App\Support\SeoMeta;

    $baseSeo = SeoMeta::make([
        'title' => $title,
        'description' => $description,
        'keywords' => $keywords,
        'image' => $ogImage,
    ]);

    $seoPayload = isset($seo)
        ? $baseSeo->with($seo instanceof SeoMeta ? $seo->toArray() : (array) $seo)
        : $baseSeo;

    $defaultSchema = trim(view('front.layouts.partials.schema')->render());
    if ($defaultSchema !== '') {
        $existingSchema = $seoPayload->toArray()['schema'] ?? [];
        $existingSchema[] = $defaultSchema;
        $seoPayload = $seoPayload->with(['schema' => $existingSchema]);
    }
?>

<?php echo $__env->make('front.layouts.partials.head', ['seo' => $seoPayload], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('front.layouts.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo e($slot); ?>


<!-- [ Footer ] start -->
<?php echo $__env->make('front.layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!-- [ Footer ] end -->
<!-- [ Customizer ] start -->
<?php echo $__env->make('front.layouts.partials.end', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!-- [ Customizer ] end -->
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\components\template\layouts\index-layouts.blade.php ENDPATH**/ ?>