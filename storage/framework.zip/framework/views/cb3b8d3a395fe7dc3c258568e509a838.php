<?php
    $containerClass = $containerClass ?? 'flex items-center gap-2 sm:gap-4';
    $authButtonClass = $authButtonClass ?? 'inline-flex items-center gap-2 px-4 py-1.5 rounded-lg border border-primary text-primary dark:text-white dark:border-white text-sm font-semibold hover:bg-primary/10 dark:hover:bg-white/20 transition-all duration-200';
    $mobileToggleClass = $mobileToggleClass ?? 'md:hidden p-2 rounded text-primary dark:text-white hover:bg-primary/10 dark:hover:bg-white/20';
    $canAccessClientDashboard = auth('client')->check()
        && session('client_impersonated_by_admin')
        && auth('web')->check()
        && (int) session('client_impersonator_admin_id') === (int) auth('web')->id();
?>

<div class="<?php echo e($containerClass); ?>">
    <?php if (isset($component)) { $__componentOriginal17635bf51fa95c39716ce1359c2110db = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17635bf51fa95c39716ce1359c2110db = $attributes; } ?>
<?php $component = App\View\Components\Lang\LanguageSwitcher::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lang.language-switcher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lang\LanguageSwitcher::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17635bf51fa95c39716ce1359c2110db)): ?>
<?php $attributes = $__attributesOriginal17635bf51fa95c39716ce1359c2110db; ?>
<?php unset($__attributesOriginal17635bf51fa95c39716ce1359c2110db); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17635bf51fa95c39716ce1359c2110db)): ?>
<?php $component = $__componentOriginal17635bf51fa95c39716ce1359c2110db; ?>
<?php unset($__componentOriginal17635bf51fa95c39716ce1359c2110db); ?>
<?php endif; ?>

    <?php if($canAccessClientDashboard): ?>
        <a
            href="<?php echo e(route('client.home')); ?>"
            id="user-menu-toggle"
            class="<?php echo e($authButtonClass); ?>"
            aria-label="<?php echo e(t('frontend.Client_Area', 'Client Area')); ?>"
        >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round"
                    d="M5.121 17.804A11.963 11.963 0 0112 15c2.21 0 4.266.642 5.879 1.742M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <span><?php echo e(t('frontend.Hello', 'Hello')); ?>: <?php echo e(Auth::guard('client')->user()->first_name); ?></span>
        </a>
    <?php endif; ?>

    <button
        id="sidebar-toggle"
        class="<?php echo e($mobileToggleClass); ?>"
        aria-label="<?php echo e(t('frontend.Menu', 'Open Menu')); ?>"
    >
        <svg class="w-7 h-7" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
        </svg>
    </button>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\front\layouts\partials\header-actions.blade.php ENDPATH**/ ?>