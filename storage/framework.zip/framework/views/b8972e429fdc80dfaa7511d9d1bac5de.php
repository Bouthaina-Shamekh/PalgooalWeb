    <?php echo $__env->make('layouts.partials.dashboard.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- [ Sidebar Menu ] start -->
    <?php echo $__env->make('layouts.partials.dashboard.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- [ Sidebar Menu ] end -->
    <!-- [ Header Topbar ] start -->
    <?php echo $__env->make('layouts.partials.dashboard.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- [ Header ] end -->

    <!-- [ Main Content ] start -->
    <div class="pc-container">
        <div class="pc-content">
          <?php echo e($slot); ?>

        </div>
    </div>
    <!-- [ Main Content ] end -->
    <!-- [ Footer ] start -->
    <?php echo $__env->make('layouts.partials.dashboard.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- [ Footer ] end -->
    <!-- [ Customizer ] start -->
    <?php echo $__env->make('layouts.partials.dashboard.end', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- [ Customizer ] end --><?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/layouts/dashboard-layout.blade.php ENDPATH**/ ?>