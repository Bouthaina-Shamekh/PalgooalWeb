<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        /**
         * ------------------------------------------------------------------
         * Expected data:
         *  - $page     : \App\Models\Page (marketing page)
         *  - $sections : \Illuminate\Support\Collection|\App\Models\Section[]
         * ------------------------------------------------------------------
         */

        // Resolve page title for breadcrumb and header
        $pageTranslation = method_exists($page, 'translation')
            ? $page->translation()
            : null;

        $pageTitle = $pageTranslation?->title
            ?? $page->slug
            ?? ('#' . $page->id);
    ?>

    
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('dashboard.home')); ?>">
                        <?php echo e(t('dashboard.Home', 'Home')); ?>

                    </a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('dashboard.pages.index')); ?>">
                        <?php echo e(t('dashboard.All_Pages', 'All Pages')); ?>

                    </a>
                </li>
                <li class="breadcrumb-item" aria-current="page">
                    <?php echo e(t('dashboard.Page_Sections', 'Page Sections')); ?> – <?php echo e($pageTitle); ?>

                </li>
            </ul>

            <div class="page-header-title">
                <h2 class="mb-0">
                    <?php echo e(t('dashboard.Page_Sections', 'Page Sections')); ?>

                    <small class="text-sm text-muted d-block">
                        <?php echo e($pageTitle); ?>

                    </small>
                </h2>
            </div>
        </div>
    </div>
    

    
    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="bg-red-100 text-red-800 px-4 py-2 rounded mb-4">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card table-card">
                <div class="card-header">
                    <div class="sm:flex items-center justify-between">
                        <div>
                            <h5 class="mb-1 mb-sm-0">
                                <?php echo e(t('dashboard.Page_Sections', 'Page Sections')); ?>

                            </h5>
                            <p class="text-xs text-slate-500 mt-1">
                                <?php echo e(__('Manage the content blocks (sections) that build this marketing page.')); ?>

                            </p>
                        </div>

                        <div class="flex items-center gap-2">
                            
                            <a href="<?php echo e(route('dashboard.pages.index')); ?>" class="btn btn-link-secondary">
                                <?php echo e(t('dashboard.Back_to_Pages', 'Back to Pages')); ?>

                            </a>

                            
                            <a href="<?php echo e(route('dashboard.pages.sections.create', $page)); ?>"
                               class="btn btn-primary">
                                <?php echo e(t('dashboard.Add_Section', 'Add Section')); ?>

                            </a>
                        </div>
                    </div>
                </div>

                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover" id="pc-dt-sections">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo e(t('dashboard.Type', 'Type')); ?></th>
                                    <th><?php echo e(t('dashboard.Variant', 'Variant')); ?></th>
                                    <th><?php echo e(t('dashboard.Title', 'Title')); ?></th>
                                    <th><?php echo e(t('dashboard.Locales', 'Locales')); ?></th>
                                    <th><?php echo e(t('dashboard.Order', 'Order')); ?></th>
                                    <th><?php echo e(t('dashboard.Status', 'Status')); ?></th>
                                    <th><?php echo e(t('dashboard.Action', 'Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        /** @var \App\Models\Section $section */

                                        // Resolve a single translation for current app locale
                                        $translation = method_exists($section, 'translation')
                                            ? $section->translation()
                                            : null;

                                        // Title fallback: translation title OR type label
                                        $sectionTitle = $translation?->title
                                            ?? ucfirst(str_replace('_', ' ', $section->type));

                                        // Comma separated list of locales (e.g. "ar, en")
                                        $locales = $section->translations
                                            ? $section->translations->pluck('locale')->implode(', ')
                                            : '';
                                    ?>

                                    <tr>
                                        
                                        <td><?php echo e($loop->iteration); ?></td>

                                        
                                        <td>
                                            <span class="text-xs px-2 py-1 rounded bg-slate-100 text-slate-800">
                                                <?php echo e($section->type); ?>

                                            </span>
                                        </td>

                                        
                                        <td>
                                            <?php if($section->variant): ?>
                                                <span class="text-xs px-2 py-1 rounded bg-purple-100 text-purple-800">
                                                    <?php echo e($section->variant); ?>

                                                </span>
                                            <?php else: ?>
                                                <span class="text-xs text-slate-400">—</span>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td>
                                            <?php echo e($sectionTitle); ?>

                                        </td>

                                        
                                        <td>
                                            <?php if($locales): ?>
                                                <span class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-800">
                                                    <?php echo e($locales); ?>

                                                </span>
                                            <?php else: ?>
                                                <span class="text-xs text-slate-400">—</span>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td>
                                            <span class="text-xs px-2 py-1 rounded bg-slate-50 text-slate-700">
                                                <?php echo e($section->order ?? '—'); ?>

                                            </span>
                                        </td>

                                        
                                        <td>
                                            <?php if($section->is_active): ?>
                                                <span class="px-2 py-1 rounded text-xs bg-green-200 text-green-900">
                                                    <?php echo e(t('dashboard.Active', 'Active')); ?>

                                                </span>
                                            <?php else: ?>
                                                <span class="px-2 py-1 rounded text-xs bg-red-200 text-red-900">
                                                    <?php echo e(t('dashboard.Inactive', 'Inactive')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td class="space-x-1 rtl:space-x-reverse">
                                            
                                            <a href="<?php echo e(route('dashboard.pages.sections.edit', [$page, $section])); ?>"
                                               class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary"
                                               title="<?php echo e(t('dashboard.Edit', 'Edit')); ?>">
                                                <i class="ti ti-edit text-xl leading-none"></i>
                                            </a>

                                            
                                            <form action="<?php echo e(route('dashboard.pages.sections.destroy', [$page, $section])); ?>"
                                                  method="POST"
                                                  class="inline"
                                                  onsubmit="return confirm('<?php echo e(__('Are you sure you want to delete this section? This action cannot be undone.')); ?>')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                        class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary"
                                                        title="<?php echo e(t('dashboard.Delete', 'Delete')); ?>">
                                                    <i class="ti ti-trash text-xl"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-slate-500 py-4">
                                            <?php echo e(__('No sections have been added for this page yet.')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    
                    
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\pages\sections\index.blade.php ENDPATH**/ ?>