<!-- Banner Section -->
<section class="relative bg-primary py-20 px-4 sm:px-8 lg:px-24 shadow-md text-white overflow-hidden">
    <!-- المحتوى -->
    <div class="relative z-10 max-w-4xl mx-auto text-center">
        <h1 class="text-3xl sm:text-4xl lg:text-5xl font-extrabold leading-snug drop-shadow-lg mb-4">
            <?php echo e($data['title'] ?? 'عنوان الترحيب'); ?>

        </h1>
        <p class="text-lg sm:text-xl font-light text-white/90 max-w-3xl mx-auto">
            <?php echo e($data['subtitle'] ?? 'نص ترحيبي مختصر'); ?>

        </p>
        <!-- Breadcrumb -->
        <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>

    </div>
</section>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\components\template\sections\banner.blade.php ENDPATH**/ ?>