
<?php
    use App\Support\SeoMeta;

    /**
     * Normalize incoming SEO payload
     * - $seo ممكن يكون SeoMeta أو array أو null
     * - $settings يُفترض جاي من View Composer (site_title, favicon, ...)
     */
    if ($seo instanceof SeoMeta) {
        $seoMeta = $seo;
    } elseif (is_array($seo ?? null)) {
        // لو جاينا SEO كـ array من صفحة معينة
        $seoMeta = SeoMeta::make($seo);
    } else {
        // ديفولت عام للموقع
        $defaultTitle = $settings->resolved_site_title
            ?? config('seo.default_title')
            ?? config('app.name', 'Palgoals');

        $seoMeta = SeoMeta::make([
            'title'       => $defaultTitle,
            'description' => $settings->resolved_site_discretion
                ?? config('seo.default_description'),
            'keywords'    => config('seo.default_keywords', []),
            'image'       => asset(config('seo.default_image', 'assets/images/default-og.jpg')),
            'canonical'   => url()->current(),
            'type'        => 'website',
        ]);
    }
?>

<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(current_dir()); ?>">

<head>
    
    <?php if (isset($component)) { $__componentOriginal5d0a24dd43287eafaf3e24ec153646b3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d0a24dd43287eafaf3e24ec153646b3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.seo.meta','data' => ['meta' => $seoMeta]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('seo.meta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['meta' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seoMeta)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d0a24dd43287eafaf3e24ec153646b3)): ?>
<?php $attributes = $__attributesOriginal5d0a24dd43287eafaf3e24ec153646b3; ?>
<?php unset($__attributesOriginal5d0a24dd43287eafaf3e24ec153646b3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d0a24dd43287eafaf3e24ec153646b3)): ?>
<?php $component = $__componentOriginal5d0a24dd43287eafaf3e24ec153646b3; ?>
<?php unset($__componentOriginal5d0a24dd43287eafaf3e24ec153646b3); ?>
<?php endif; ?>

    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <link
        rel="icon"
        href="<?php echo e($settings?->favicon ? asset('storage/' . $settings->favicon) : asset('assets/images/favicon.ico')); ?>"
        type="image/x-icon"
    >

    
    

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Almarai:wght@300;400;700;800&family=Cairo:wght@200..1000&display=swap"
        rel="stylesheet"
    >
    
    <link rel="stylesheet" href="<?php echo e(mix('assets/tamplate/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(route('frontend.assets.purple_topbar_css')); ?>">
    <link rel="stylesheet" href="<?php echo e(route('frontend.assets.palgoals_marketing_footer_css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/fonts/tabler-icons.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

    <?php echo $__env->yieldPushContent('meta'); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body x-data="languageSwitcher()" class="m-0 bg-white text-purple-brand overflow-x-hidden">
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\front\layouts\partials\head.blade.php ENDPATH**/ ?>