<footer class="pc-footer">
    <div class="footer-wrapper container-fluid mx-10">
        <div class="grid grid-cols-12 gap-1.5">
            <div class="col-span-12 sm:col-span-6 my-1">
                <p class="m-0">
                    © crafted with ♥ by Team <a href="https://www.palgoals.com/" class="text-theme-bodycolor dark:text-themedark-bodycolor hover:text-primary-500 dark:hover:text-primary-500" target="_blank">Palgoals</a>
                </p>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/layouts/partials/dashboard/footer.blade.php ENDPATH**/ ?>