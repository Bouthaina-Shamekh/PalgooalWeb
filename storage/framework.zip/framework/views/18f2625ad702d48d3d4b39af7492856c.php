<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto py-6 max-w-4xl space-y-6">
        <div>
            <a href="<?php echo e(route('dashboard.domains.index')); ?>"
                class="inline-flex items-center text-sm text-gray-500 hover:text-gray-700 transition">
                <i class="ti ti-arrow-left me-1"></i>
                <?php echo e(__('Back to domains')); ?>

            </a>
        </div>

        <div>
            <h1 class="text-2xl font-bold mb-2"><?php echo e(__('Renew Domain: :domain', ['domain' => $domain->domain_name])); ?></h1>
            <p class="text-sm text-gray-500">
                <?php echo e(__('Review the current renewal information and update the next renewal date before confirming.')); ?>

            </p>
        </div>

        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 p-4 rounded">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="bg-red-100 text-red-800 p-4 rounded">
                <ul class="ps-5 list-disc space-y-1">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php
            $renewalValue = old('renewal_date', $suggestedRenewal);
            $statusValue = old('status', $domain->status);
            $paymentMethodValue = old('payment_method', $domain->payment_method);
        ?>

        <section class="bg-white rounded-lg shadow p-6 space-y-4">
            <h2 class="text-lg font-semibold"><?php echo e(__('Current renewal details')); ?></h2>
            <dl class="grid grid-cols-1 gap-4 md:grid-cols-2 text-sm">
                <div>
                    <dt class="text-gray-500"><?php echo e(__('Current renewal date')); ?></dt>
                    <dd class="font-medium"><?php echo e($currentRenewal); ?></dd>
                </div>
                <div>
                    <dt class="text-gray-500"><?php echo e(__('Suggested next renewal')); ?></dt>
                    <dd class="font-medium"><?php echo e($suggestedRenewal); ?></dd>
                </div>
            </dl>
        </section>

        <form action="<?php echo e(route('dashboard.domains.renew.update', $domain->id)); ?>" method="POST"
            class="bg-white rounded-lg shadow p-6 space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <section class="grid grid-cols-1 gap-6 md:grid-cols-2 items-end">
                <div class="space-y-2">
                    <label for="renewal_date" class="text-sm font-medium text-gray-700">
                        <?php echo e(__('Next renewal date')); ?>

                    </label>
                    <input type="date" id="renewal_date" name="renewal_date" value="<?php echo e($renewalValue); ?>"
                        class="form-control">
                </div>
                <div class="flex gap-2">
                    <button type="button" id="use-suggested-renewal"
                        class="btn btn-secondary"
                        data-suggested="<?php echo e($suggestedRenewal); ?>">
                        <?php echo e(__('Use suggested date')); ?>

                    </button>
                    <button type="button" id="add-year-renewal" class="btn btn-outline-secondary">
                        <?php echo e(__('Add 1 year')); ?>

                    </button>
                </div>
            </section>

            <section class="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div class="space-y-2">
                    <label for="status" class="text-sm font-medium text-gray-700">
                        <?php echo e(__('Status after renewal')); ?>

                    </label>
                    <select id="status" name="status" class="form-select">
                        <option value=""><?php echo e(__('Select status')); ?></option>
                        <?php $__currentLoopData = $statusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if($statusValue === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="space-y-2">
                    <label for="payment_method" class="text-sm font-medium text-gray-700">
                        <?php echo e(__('Payment method (optional)')); ?>

                    </label>
                    <input type="text" id="payment_method" name="payment_method" class="form-control"
                        value="<?php echo e($paymentMethodValue); ?>" placeholder="<?php echo e(__('e.g. credit card, bank transfer')); ?>">
                </div>
            </section>

            <section class="space-y-2">
                <label for="renew-notes" class="text-sm font-medium text-gray-700">
                    <?php echo e(__('Internal note (optional)')); ?>

                </label>
                <textarea id="renew-notes" name="notes" rows="4" class="form-control"
                    placeholder="<?php echo e(__('Add any context for the finance or operations team.')); ?>"><?php echo e(old('notes')); ?></textarea>
            </section>

            <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div class="text-sm text-gray-500">
                    <?php echo e(__('Renewal submission updates the domain record. Automated registrar updates will arrive in a future release.')); ?>

                </div>
                <div class="flex gap-2">
                    <a href="<?php echo e(route('dashboard.domains.index')); ?>" class="btn btn-secondary">
                        <?php echo e(__('Cancel')); ?>

                    </a>
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Save renewal')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const renewalInput = document.getElementById('renewal_date');
            const suggestedButton = document.getElementById('use-suggested-renewal');
            const addYearButton = document.getElementById('add-year-renewal');

            if (suggestedButton && renewalInput) {
                suggestedButton.addEventListener('click', () => {
                    const suggested = suggestedButton.dataset.suggested;
                    if (suggested) {
                        renewalInput.value = suggested;
                    }
                });
            }

            if (addYearButton && renewalInput) {
                addYearButton.addEventListener('click', () => {
                    if (!renewalInput.value) {
                        return;
                    }
                    const currentDate = new Date(renewalInput.value);
                    if (Number.isNaN(currentDate.getTime())) {
                        return;
                    }
                    currentDate.setFullYear(currentDate.getFullYear() + 1);
                    const month = String(currentDate.getMonth() + 1).padStart(2, '0');
                    const day = String(currentDate.getDate()).padStart(2, '0');
                    renewalInput.value = `${currentDate.getFullYear()}-${month}-${day}`;
                });
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\domains\renew.blade.php ENDPATH**/ ?>