
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>"><?php echo e(t('dashboard.Home', 'Home')); ?></a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.category')); ?>"><?php echo e(t('dashboard.Template_Categories', 'Template Categories')); ?></a></li>
                
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0"><?php echo e(t('dashboard.Template_Categories', 'Template Categories')); ?></h2>
            </div>
        </div>
    </div>
    <!-- [ breadcrumb ] end -->
    <?php if(session()->has('success')): ?>
        <div class="bg-green-100 border border-green-300 text-green-800 px-4 py-2 rounded shadow-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    
    <!-- [ Main Content ] start -->
    <div class="grid grid-cols-12 gap-6">
        <div class="col-span-12 lg:col-span-6">
            <div class="card">
                <div class="card-header">
                    <h5><?php echo e($mode === 'edit' ? t('dashboard.Edit_Category', 'Edit Category') : t('dashboard.Add_New_Category', 'Add New Category')); ?></h5>
                </div>
                <div class="card-body">
                    <!-- تبويبات اللغات -->
                    <ul class="flex mb-4 border-b space-x-2 rtl:space-x-reverse">
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <button type="button" wire:click="$set('activeLang', '<?php echo e($lang->code); ?>')"
                                    class="px-4 py-2 rounded-t-lg text-sm <?php echo e($activeLang === $lang->code ? 'bg-gray-50 border-t border-l border-r font-semibold text-indigo-600' : 'bg-gray-200 hover:bg-gray-300'); ?>">
                                    <?php echo e($lang->name); ?>

                                </button>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <!-- الحقول داخل التبويبات -->
                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div wire:key="trans-<?php echo e($lang->code); ?>" <?php if($activeLang !== $lang->code): ?> style="display: none;" <?php endif; ?>>
                            <div class="space-y-4">
                                <div class="mb-3">
                                    <label class="form-label"><?php echo e(t('dashboard.Category_Name', 'Category Name')); ?></label>
                                    <input type="text" wire:model="translations.<?php echo e($lang->code); ?>.name" class="form-control" placeholder="<?php echo e(t('dashboard.Category_Name', 'Category Name')); ?>">
                                    <?php $__errorArgs = ["translations.{$lang->code}.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500 form-text"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label"><?php echo e(t('dashboard.Slug', 'Slug')); ?></label>
                                    <input type="text" wire:model="translations.<?php echo e($lang->code); ?>.slug" class="form-control" placeholder="<?php echo e(t('dashboard.Slug', 'Slug')); ?>">
                                    <?php $__errorArgs = ["translations.{$lang->code}.slug"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500 form-text"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label"><?php echo e(t('dashboard.Description', 'Description')); ?></label>
                                    <textarea wire:model="translations.<?php echo e($lang->code); ?>.description" class="form-control" rows="4" placeholder="<?php echo e(t('dashboard.Description', 'Description')); ?>"></textarea>
                                    <?php $__errorArgs = ["translations.{$lang->code}.description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500 form-text"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="mt-4 text-left">
                        <button type="button" wire:click="save" wire:loading.attr="disabled" class="btn btn-primary">
                            <span wire:loading.remove wire:target="save">
                            <?php echo e($mode === 'edit' ? t('dashboard.Save_Changes', 'Save Changes') : t('dashboard.Add_Category', 'Add Category')); ?>

                            </span>
                            <span wire:loading wire:target="save">
                                <?php echo e(t('dashboard.Saving', 'Saving...')); ?>

                            </span>
                        </button>
                        <?php if($mode === 'edit'): ?>
                            <button type="button" wire:click="resetForm" class="btn btn-secondary">
                                <?php echo e(t('dashboard.Cancel', 'Cancel')); ?>

                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ form-element ] end -->
        <!-- [ list-element ] start -->
        <div class="col-span-12 lg:col-span-5">
            <div class="card">
                <div class="card-header">
                    <h5><?php echo e(t('dashboard.Current_Categories', 'Current Categories')); ?></h5>
                </div>
                <div class="card-body">
                    <ul class="space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li wire:key="cat-<?php echo e($category->id); ?>" class="flex items-center justify-between p-3 bg-gray-100 rounded-lg">
                            <div>
                                <strong class="text-gray-800"><?php echo e($category->translated_name); ?></strong>
                                <p class="text-sm text-gray-500"><?php echo e($category->translated_slug); ?></p>
                            </div>
                            <div class="flex items-center gap-2">
                                <button wire:click="edit(<?php echo e($category->id); ?>)" class="w-8 h-8 inline-flex items-center justify-center text-yellow-600 rounded-xl hover:bg-yellow-100">
                                    <i class="ti ti-edit text-xl leading-none"></i>
                                </button>
                                <button
                                    onclick="confirm('هل أنت متأكد من رغبتك في الحذف؟') || event.stopImmediatePropagation()"
                                    wire:click="delete(<?php echo e($category->id); ?>)"
                                    class="w-8 h-8 inline-flex items-center justify-center text-red-600 rounded-xl hover:bg-red-100">
                                    <i class="ti ti-trash text-xl"></i>
                                </button>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-center text-gray-500"><?php echo e(t('dashboard.No_categories_found', 'No categories found')); ?></p>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <!-- [ list-element ] end -->
    </div>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\livewire\admin\template\category-management.blade.php ENDPATH**/ ?>