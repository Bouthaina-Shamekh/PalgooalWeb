
<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('dashboard.home')); ?>"><?php echo e(t('dashboard.Home', 'Home')); ?></a>
                </li>
                <li class="breadcrumb-item" aria-current="page">
                    <?php echo e(t('dashboard.All_Pages', 'All Pages')); ?>

                </li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0"><?php echo e(t('dashboard.All_Pages', 'All Pages')); ?></h2>
            </div>
        </div>
    </div>
    <!-- [ breadcrumb ] end -->

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card table-card">
                <div class="card-header">
                    <div class="sm:flex items-center justify-between">
                        <h5 class="mb-3 mb-sm-0">
                            <?php echo e(t('dashboard.All_Pages', 'All Pages')); ?>

                        </h5>
                        <div>
                            <a href="<?php echo e(route('dashboard.pages.create')); ?>" class="btn btn-primary">
                                <?php echo e(t('dashboard.Add_Page', 'Add Page')); ?>

                            </a>
                        </div>
                    </div>
                </div>

                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover" id="pc-dt-simple">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo e(t('dashboard.Title', 'Title')); ?></th>
                                    <th><?php echo e(t('dashboard.Slug', 'Slug')); ?></th>
                                    <th><?php echo e(t('dashboard.Homepage', 'Homepage')); ?></th>
                                    <th><?php echo e(t('dashboard.Status', 'Status')); ?></th>
                                    <th><?php echo e(t('dashboard.Date', 'Date')); ?></th>
                                    <th><?php echo e(t('dashboard.Action', 'Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $translation = $p->translation();
                                        $title = $translation?->title ?? ($p->slug ?? '#' . $p->id);
                                        $slug = $translation?->slug ?? ($p->slug ?? '');
                                        $frontUrl = $p->is_home ? url('/') : ($slug ? url($slug) : url('/'));
                                    ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>

                                        <td><?php echo e($title); ?></td>

                                        <td>
                                            <?php if($p->is_home): ?>
                                                <span class="text-xs px-2 py-1 rounded bg-blue-100 text-blue-800">
                                                    /
                                                </span>
                                            <?php elseif($slug): ?>
                                                <span class="text-xs px-2 py-1 rounded bg-slate-100 text-slate-800">
                                                    /<?php echo e($slug); ?>

                                                </span>
                                            <?php else: ?>
                                                <span class="text-xs text-slate-400">—</span>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td>
                                            <?php if($p->is_home): ?>
                                                <span class="btn btn-success btn-sm">
                                                    <?php echo e(t('dashboard.Current_Homepage', 'Current Homepage')); ?>

                                                </span>
                                            <?php else: ?>
                                                <form action="<?php echo e(route('dashboard.pages.set-home', $p)); ?>"
                                                    method="POST" class="inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-primary btn-sm">
                                                        <?php echo e(t('dashboard.Make_Homepage', 'Make Homepage')); ?>

                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td>
                                            <form action="<?php echo e(route('dashboard.pages.toggle-active', $p)); ?>"
                                                method="POST" class="inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit"
                                                    class="px-2 py-1 rounded text-xs
                                                        <?php echo e($p->is_active ? 'bg-green-200 text-green-900' : 'bg-red-200 text-red-900'); ?>">
                                                    <?php echo e($p->is_active ? __('منشورة') : __('مسودة')); ?>

                                                </button>
                                            </form>
                                        </td>

                                        
                                        <td>
                                            <?php echo e(optional($p->created_at)->translatedFormat('Y-m-d h:i A')); ?>

                                        </td>

                                        
                                        <td class="space-x-1 rtl:space-x-reverse">
                                            
                                            <a href="<?php echo e($frontUrl); ?>"
                                                class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary"
                                                target="_blank">
                                                <i class="ti ti-eye text-xl leading-none"></i>
                                            </a>

                                            
                                            <a href="<?php echo e(route('dashboard.pages.edit', $p)); ?>"
                                                class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary">
                                                <i class="ti ti-edit text-xl leading-none"></i>
                                            </a>

                                            
                                            <button type="button"
                                                class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary text-danger"
                                                onclick="confirmDeletePage(<?php echo e($p->id); ?>)">
                                                <i class="ti ti-trash text-xl"></i>
                                            </button>


                                            
                                            <form id="delete-page-<?php echo e($p->id); ?>"
                                                action="<?php echo e(route('dashboard.pages.destroy', $p)); ?>" method="POST"
                                                class="hidden">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                            
                                            <a href="<?php echo e(route('dashboard.pages.builder', $p)); ?>"
                                                class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary"
                                                title="<?php echo e(__('Page Builder')); ?>">
                                                <i class="ti ti-vector text-xl leading-none"></i>
                                            </a>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-slate-500 py-4">
                                            <?php echo e(__('لا توجد صفحات حتى الآن.')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4">
                        <?php echo e($pages->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>


<script>
    /**
     * Confirm page deletion using SweetAlert.
     *
     * - Called directly from the delete button onclick (user interaction),
     *   so browser will not suppress the dialog.
     * - If SweetAlert (Swal) is not loaded, falls back to window.confirm().
     */
    function confirmDeletePage(pageId) {
        // Fallback if SweetAlert is not available
        if (typeof Swal === 'undefined') {
            const ok = window.confirm(
                '<?php echo e(__('هل أنت متأكد من حذف الصفحة؟ لن تتمكن من التراجع عن هذا الإجراء.')); ?>'
            );
            if (ok) {
                const form = document.getElementById('delete-page-' + pageId);
                if (form) form.submit();
            }
            return;
        }

        Swal.fire({
            title: '<?php echo e(__('هل أنت متأكد من حذف هذه الصفحة؟')); ?>',
            text: '<?php echo e(__('لن تتمكن من التراجع عن هذا الإجراء!')); ?>',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: '<?php echo e(__('نعم، احذف الصفحة')); ?>',
            cancelButtonText: '<?php echo e(__('إلغاء')); ?>',
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6'
        }).then((result) => {
            if (result.isConfirmed) {
                const form = document.getElementById('delete-page-' + pageId);
                if (form) {
                    form.submit();
                }
            }
        });
    }
</script>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\pages\index.blade.php ENDPATH**/ ?>