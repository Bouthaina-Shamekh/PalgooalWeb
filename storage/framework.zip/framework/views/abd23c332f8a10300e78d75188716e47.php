<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


<div class="container mx-auto py-6">
    <h1 class="text-2xl font-bold mb-4">جميع القوالب</h1>

    <a href="<?php echo e(route('dashboard.templates.create')); ?>" class="btn btn-primary mb-4">➕ إضافة قالب جديد</a>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 p-4 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="w-full bg-white shadow rounded-lg overflow-hidden">
        <thead class="bg-gray-100 text-right">
            <tr>
                <th class="p-4">#</th>
                <th class="p-4">الاسم</th>
                <th class="p-4">الصورة</th>
                <th class="p-4">السعر</th>
                <th class="p-4">التصنيف</th>
                <th class="p-4">خيارات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t">
                    <td class="p-4"><?php echo e($template->id); ?></td>
                    <td class="p-4"><?php echo e($template->translation()?->name ?? '—'); ?></td>
                    <td class="p-4">
                        <img src="<?php echo e(asset('storage/' . $template->image)); ?>" class="h-16 w-20 object-cover rounded" alt="صورة القالب">
                    </td>
                    <td class="p-4"><?php echo e($template->price); ?> $</td>
                    <td class="p-4"><?php echo e($template->categoryTemplate->translation?->name ?? '—'); ?></td>
                    <td class="p-4">
                        <a href="<?php echo e(route('dashboard.templates.edit', $template->id)); ?>" class="text-blue-600 hover:underline">تعديل</a> |
                        <form action="<?php echo e(route('dashboard.templates.destroy', $template->id)); ?>" method="POST" class="inline-block" onsubmit="return confirm('هل أنت متأكد من الحذف؟');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:underline">حذف</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="mt-6">
        <?php echo e($templates->links()); ?>

    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/dashboard/templates/index.blade.php ENDPATH**/ ?>