<nav class="pc-sidebar">
    <div class="navbar-wrapper">
        <div class="m-header flex items-center py-4 px-6 h-header-height">
            <a href="../dashboard/index.html" class="b-brand flex items-center gap-3">
                <!-- ========   Change your logo from here   ============ -->
                <img src="<?php echo e(asset('assets-dashboard/images/logo-dark.svg')); ?>" class="img-fluid logo-lg" alt="logo" />
            </a>
        </div>
        <div class="navbar-content h-[calc(100vh_-_74px)] py-2.5">
            <div
                class="card pc-user-card mx-[15px] mb-[15px] bg-theme-sidebaruserbg dark:bg-themedark-sidebaruserbg border border-secondary-100/10">
                <div class="card-body !p-4">
                    <div class="flex items-center gap-3">
                        <img class="shrink-0 w-[48px] h-[48px] rounded-full border border-secondary-200"
                            src="https://ui-avatars.com/api/?name=<?php echo e(Auth::user()->name); ?>" alt="user-image" />
                        <div class="grow">
                            <h6 class="mb-0 text-sm font-semibold"><?php echo e(Auth::user()->name); ?></h6>
                            <small class="text-xs text-muted"><?php echo e(Auth::user()->email); ?></small>
                        </div>
                        <button class="shrink-0 btn btn-icon inline-flex btn-link-secondary" data-pc-toggle="collapse"
                            aria-expanded="false" aria-controls="pc_sidebar_userlink">
                            <svg class="pc-icon w-[20px] h-[20px]">
                                <use xlink:href="#custom-more-vertical"></use>
                            </svg>
                        </button>
                    </div>
                    <div class="hidden pc-user-links mt-3" id="pc_sidebar_userlink">
                        <div class="space-y-2">
                            <a href="<?php echo e(route('dashboard.users.profile', Auth::user()->id)); ?>"
                                class="flex items-center gap-2 px-2 py-2 rounded hover:bg-primary-50">
                                <i class="text-lg leading-none ti ti-user"></i>
                                <span class="text-sm"><?php echo e(t('dashboard.My_Account', 'My Account')); ?></span>
                            </a>
                            <a href="#!" class="flex items-center gap-2 px-2 py-2 rounded hover:bg-primary-50">
                                <i class="text-lg leading-none ti ti-settings"></i>
                                <span class="text-sm"><?php echo e(t('dashboard.Settings', 'Settings')); ?></span>
                            </a>
                            <form action="<?php echo e(route('logout')); ?>" method="post" class="px-2">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="w-full btn btn-outline-danger flex items-center justify-center gap-2">
                                    <i class="text-lg leading-none ti ti-power"></i>
                                    <span class="text-sm"><?php echo e(t('dashboard.Logout', 'Logout')); ?></span>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <ul class="pc-navbar">
                <li class="pc-item pc-caption">
                    <label
                        class="text-xs uppercase tracking-wider text-muted"><?php echo e(t('dashboard.Navigation', 'Navigation')); ?></label>
                </li>
                <li class="pc-item">
                    <a href="<?php echo e(route('dashboard.home')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <span class="pc-micon">
                                <i class="fas fa-home"></i>
                            </span>
                        </span>
                        <span class="pc-mtext"><?php echo e(t('dashboard.Home', 'Home')); ?></span>
                    </a>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Page')): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.pages')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-file"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.Pages', 'Pages')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\Template')): ?>
                    <li class="pc-item pc-hasmenu">
                        <a href="#!" class="pc-link">
                            <span class="pc-micon">
                                <svg class="pc-icon">
                                    <use xlink:href="#custom-layer"></use>
                                </svg>
                            </span>
                            <span class="pc-mtext"
                                data-i18n="Online Courses"><?php echo e(t('dashboard.Template_management', 'Template management')); ?></span>
                            <span class="pc-arrow"><i data-feather="chevron-left" class="rtl:rotate-180"></i></span>
                        </a>
                        <ul class="pc-submenu">
                            <li class="pc-item"><a class="pc-link" href="<?php echo e(route('dashboard.templates.index')); ?>"
                                    data-i18n="Menus"><?php echo e(t('dashboard.All_templates', 'All templates')); ?></a></li>
                            <li class="pc-item"><a class="pc-link" href="<?php echo e(route('dashboard.category')); ?>"
                                    data-i18n="Menus"><?php echo e(t('dashboard.Categories', 'Categories')); ?></a></li>
                            <li class="pc-item"><a class="pc-link" href="<?php echo e(route('dashboard.reviews.index')); ?>"
                                    data-i18n="Menus"><?php echo e(t('dashboard.reviews', 'reviews')); ?></a></li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Service')): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.services')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-briefcase"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.services', 'services')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\Feedback')): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.feedbacks')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-star"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.feedbacks', 'testimonial')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Portfolio')): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.portfolios.index')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-briefcase"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.portfolios', 'portfolios')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <li class="pc-item pc-caption">
                    <label
                        class="text-xs uppercase tracking-wider text-muted"><?php echo e(t('dashboard.clients', 'clients')); ?></label>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Client')): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.clients')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-users"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.clients', 'clients')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Domain')): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.domains.index')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-globe"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.domains', 'domains')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Plan')): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.plans.index')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-boxes"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.plans', 'plans')); ?></span>
                        </a>
                    </li>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.plan_categories.index')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-boxes"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.plan-categories', 'plan categories')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Subscription')): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.subscriptions.index')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-money-bill"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.subscriptions', 'subscriptions')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Invoice')): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.invoices.index')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-file-invoice-dollar"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.invoices', 'invoices')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Order')): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.orders.index')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-server"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.orders', 'orders')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Settings-crm')): ?>
                    <li class="pc-item pc-hasmenu">
                        <a href="#!" class="pc-link">
                            <span class="pc-micon">
                                <i class="fas fa-users"></i>
                            </span>
                            <span class="pc-mtext">
                               <?php echo e(t('dashboard.CRM_management', 'CRM management')); ?>

                            </span>
                            <?php if(App::getLocale() == 'en'): ?>
                                <span class="pc-arrow"><i data-feather="chevron-right"></i></span>
                            <?php else: ?>
                                <span class="pc-arrow"><i data-feather="chevron-left"></i></span>
                            <?php endif; ?>
                        </a>
                        <ul class="pc-submenu">
                            <li class="pc-item">
                                <a class="pc-link" href="<?php echo e(route('dashboard.servers.index')); ?>">
                                    <?php echo e(t('dashboard.servers', 'servers')); ?>

                                </a>
                            </li>
                            <li class="pc-item">
                                <a class="pc-link" href="<?php echo e(route('dashboard.domain_providers.index')); ?>">
                                    <?php echo e(t('dashboard.domain_providers', 'domain providers')); ?>

                                </a>
                            </li>
                            <li class="pc-item">
                                <a class="pc-link" href="<?php echo e(route('dashboard.domain_tlds.index')); ?>">
                                    <?php echo e(t('dashboard.domain-tlds', 'domain tlds')); ?>

                                </a>
                            </li>
                            <li class="pc-item">
                                <a class="pc-link" href="<?php echo e(route('dashboard.subscriptions.sync-logs')); ?>">
                                    <?php echo e(t('dashboard.sync-logs', 'sync-logs')); ?>

                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <li class="pc-item pc-caption">
                    <label><?php echo e(t('dashboard.Site_settings', 'Site settings')); ?></label>
                    <svg class="pc-icon">
                        <use xlink:href="#custom-presentation-chart"></use>
                    </svg>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Media')): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.media')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-images"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.media', 'Media')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\Header')): ?>
                    <li class="pc-item pc-hasmenu">
                        <a href="#!" class="pc-link">
                            <span class="pc-micon">
                                <svg class="pc-icon">
                                    <use xlink:href="#custom-layer"></use>
                                </svg>
                            </span>
                            <span class="pc-mtext"
                                data-i18n="Online Courses"><?php echo e(t('dashboard.Appearance', 'Appearance')); ?></span>
                            <span class="pc-arrow"><i data-feather="chevron-right" class="rtl:rotate-180"></i></span>
                        </a>
                        <ul class="pc-submenu">
                            <li class="pc-item"><a class="pc-link" href="<?php echo e(route('dashboard.headers')); ?>"
                                    data-i18n="Menus"><?php echo e(t('dashboard.Menus', 'Menus')); ?></a></li>
                            <li class="pc-item"><a class="pc-link" href="<?php echo e(route('dashboard.languages.index')); ?>"
                                    data-i18n="Menus"><?php echo e(t('dashboard.languages', 'languages')); ?></a></li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\User')): ?>
                    <li class="pc-item pc-hasmenu">
                        <a href="#!" class="pc-link">
                            <span class="pc-micon">
                                <i class="fas fa-users"></i>
                            </span>
                            <span class="pc-mtext">
                                <?php echo e(__('Users')); ?>

                            </span>
                            <?php if(App::getLocale() == 'en'): ?>
                                <span class="pc-arrow"><i data-feather="chevron-right"></i></span>
                            <?php else: ?>
                                <span class="pc-arrow"><i data-feather="chevron-left"></i></span>
                            <?php endif; ?>
                        </a>
                        <ul class="pc-submenu">
                            <li class="pc-item">
                                <a class="pc-link" href="<?php echo e(route('dashboard.users.index')); ?>">
                                    <?php echo e(t('dashboard.Users_show', 'Users show')); ?>

                                </a>
                            </li>
                            <li class="pc-item">
                                <a class="pc-link" href="<?php echo e(route('dashboard.users.create')); ?>">
                                    <?php echo e(t('dashboard.Add_User', 'Add User')); ?>

                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\\Models\\GeneralSetting')): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard.general_settings')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <span class="pc-micon">
                                    <i class="fas fa-cog"></i>
                                </span>
                            </span>
                            <span class="pc-mtext"><?php echo e(t('dashboard.General_Setting', 'General Setting')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/layouts/partials/dashboard/nav.blade.php ENDPATH**/ ?>