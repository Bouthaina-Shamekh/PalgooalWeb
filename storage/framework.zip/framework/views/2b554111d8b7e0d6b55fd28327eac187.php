<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['defaultTlds','fallbackPrices','currency']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['defaultTlds','fallbackPrices','currency']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginal982c712068cd324c487450726e32fd3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal982c712068cd324c487450726e32fd3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.template.sections.search-domain','data' => ['defaultTlds' => $defaultTlds,'fallbackPrices' => $fallbackPrices,'currency' => $currency]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('template.sections.search-domain'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['default-tlds' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($defaultTlds),'fallback-prices' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($fallbackPrices),'currency' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currency)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal982c712068cd324c487450726e32fd3b)): ?>
<?php $attributes = $__attributesOriginal982c712068cd324c487450726e32fd3b; ?>
<?php unset($__attributesOriginal982c712068cd324c487450726e32fd3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal982c712068cd324c487450726e32fd3b)): ?>
<?php $component = $__componentOriginal982c712068cd324c487450726e32fd3b; ?>
<?php unset($__componentOriginal982c712068cd324c487450726e32fd3b); ?>
<?php endif; ?><?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\storage\framework\views/85903125ce1e179fb52a5ee91d6e0ef8.blade.php ENDPATH**/ ?>