<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['data','templates']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['data','templates']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginal5762ff11261be82ec8be6008068c1495 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5762ff11261be82ec8be6008068c1495 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.template.sections.hero','data' => ['data' => $data,'templates' => $templates]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('template.sections.hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'templates' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($templates)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5762ff11261be82ec8be6008068c1495)): ?>
<?php $attributes = $__attributesOriginal5762ff11261be82ec8be6008068c1495; ?>
<?php unset($__attributesOriginal5762ff11261be82ec8be6008068c1495); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5762ff11261be82ec8be6008068c1495)): ?>
<?php $component = $__componentOriginal5762ff11261be82ec8be6008068c1495; ?>
<?php unset($__componentOriginal5762ff11261be82ec8be6008068c1495); ?>
<?php endif; ?><?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\storage\framework\views/366365b4318a9ba151d65511c1d5538c.blade.php ENDPATH**/ ?>