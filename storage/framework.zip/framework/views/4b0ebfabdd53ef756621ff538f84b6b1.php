<?php
    $testimonial = $testimonial ?? ($feedback ?? null);
    $testimonialTranslations = $testimonialTranslations ?? ($feedbackTranslations ?? []);

    // 🔹 قراءة الـ id الحالي للصورة (من old أو من الموديل)
    $featuredImageId = old('featured_image_id', $testimonial->image_id ?? null);

    // 🔹 تجهيز روابط المعاينة (تُستخدم في حالة التعديل فقط)
    $featuredImageUrls = [];

    if ($featuredImageId && $testimonial && $testimonial->image) {
        // نستخدم الـ accessor getImageUrlAttribute في موديل Testimonial
        $featuredImageUrls[] = $testimonial->image_url;
    }
?>


<?php if (isset($component)) { $__componentOriginal02b99813b559a8f0e43f75eb7c36d251 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal02b99813b559a8f0e43f75eb7c36d251 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.media-picker','data' => ['id' => 'featured_image_id','name' => 'featured_image_id','label' => 'الصورة الرئيسية','value' => $featuredImageId,'previewUrls' => $featuredImageUrls,'buttonText' => 'اختر صورة من المكتبة']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.media-picker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'featured_image_id','name' => 'featured_image_id','label' => 'الصورة الرئيسية','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($featuredImageId),'preview-urls' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($featuredImageUrls),'button-text' => 'اختر صورة من المكتبة']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal02b99813b559a8f0e43f75eb7c36d251)): ?>
<?php $attributes = $__attributesOriginal02b99813b559a8f0e43f75eb7c36d251; ?>
<?php unset($__attributesOriginal02b99813b559a8f0e43f75eb7c36d251); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal02b99813b559a8f0e43f75eb7c36d251)): ?>
<?php $component = $__componentOriginal02b99813b559a8f0e43f75eb7c36d251; ?>
<?php unset($__componentOriginal02b99813b559a8f0e43f75eb7c36d251); ?>
<?php endif; ?>

<?php $__errorArgs = ['featured_image_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-sm text-red-600 mt-2"><?php echo e($message); ?></p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


<div class="col-span-6">
    <div class="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 h-full">
        <label class="flex items-center text-sm font-semibold text-gray-700 mb-2">
            <svg class="w-5 h-5 ml-2 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4">
                </path>
            </svg>
            ترتيب الظهور
        </label>
        <input type="number" name="order" min="1" value="<?php echo e(old('order', $testimonial?->order ?? 1)); ?>"
            class="form-control" placeholder="مثال: 1 للظهور أولاً">
        <p class="text-xs text-gray-500 mt-2">استخدم أرقامًا متسلسلة للتحكم في ترتيب بطاقات الشهادات.</p>
        <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-sm text-red-600 mt-2"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>



<div class="col-span-6">
    <div class="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 h-full">
        <label class="flex items-center text-sm font-semibold text-gray-700 mb-2">
            <svg class="w-4 h-4 ml-2 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.967a1 1 0 00.95.69h4.174c.969 0 1.371 1.24.588 1.81l-3.378 2.455a1 1 0 00-.364 1.118l1.286 3.966c.3.922-.755 1.688-1.54 1.118l-3.379-2.454a1 1 0 00-1.175 0l-3.379 2.454c-.784.57-1.838-.196-1.539-1.118l1.285-3.966a1 1 0 00-.364-1.118L2.96 9.394c-.783-.57-.38-1.81.588-1.81h4.174a1 1 0 00.95-.69l1.286-3.967z">
                </path>
            </svg>
            عدد النجوم
        </label>
        <input type="number" name="star" min="1" max="5"
            value="<?php echo e(old('star', $testimonial?->star ?? '')); ?>" class="form-control"
            placeholder="اختر قيمة من 1 إلى 5">
        <p class="text-xs text-gray-500 mt-2">يستخدم هذا الحقل لعرض معدل التقييم (الحد الأدنى 1 والحد الأقصى 5).</p>
        <?php $__errorArgs = ['star'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-sm text-red-600 mt-2"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>


<?php
    $isApprovedValue = (int) old('is_approved', $testimonial?->is_approved ?? 1);
?>
<div class="col-span-6">
    <div class="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 h-full">
        <label class="flex items-center text-sm font-semibold text-gray-700 mb-2">
            <svg class="w-5 h-5 ml-2 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7">
                </path>
            </svg>
            حالة النشر
        </label>
        <div class="flex items-center gap-4">
            <input type="hidden" name="is_approved" value="0">
            <label class="inline-flex items-center cursor-pointer">
                <input type="checkbox" name="is_approved" value="1" class="sr-only peer"
                    <?php echo e($isApprovedValue ? 'checked' : ''); ?>>
                <div
                    class="w-14 h-8 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-200 rounded-full peer peer-checked:bg-green-500 transition">
                </div>
                <span class="mr-3 text-sm text-gray-600">
                    <?php echo e($isApprovedValue ? 'سيظهر فوراً في الموقع' : 'سيبقى قيد المراجعة'); ?>

                </span>
            </label>
        </div>
        <p class="text-xs text-gray-500 mt-2">قم بإلغاء التحديد لإبقاء التقييم في وضع قيد المراجعة حتى يتم اعتماده
            لاحقاً.</p>
    </div>
</div>
<?php
    $languageErrorMap = [];
    $firstErrorLang = null;

    foreach ($languages as $language) {
        $code = $language->code;
        $languageErrorMap[$code] =
            $errors->has("testimonialTranslations.$code.name") ||
            $errors->has("testimonialTranslations.$code.feedback") ||
            $errors->has("testimonialTranslations.$code.major") ||
            $errors->has("testimonialTranslations.$code.locale");

        if ($languageErrorMap[$code] && $firstErrorLang === null) {
            $firstErrorLang = $code;
        }
    }

    $initialTabCode = $firstErrorLang ?? ($languages->first()->code ?? null);
?>


<div class="col-span-12 mt-8">
    <div class="bg-gradient-to-r from-indigo-50 to-blue-50 p-6 rounded-2xl border border-indigo-200 shadow-sm mb-6">
        <h3 class="flex items-center text-xl font-semibold text-gray-800 mb-2">
            <svg class="w-6 h-6 ml-2 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 5h12M9 3v2m3.5 13.5a18.5 18.5 0 01-6-7.5m6 7.5h7M11 21l4.5-10L20 21M12.75 5C11.8 10.8 8.1 15.6 3 18.1">
                </path>
            </svg>
            الترجمات
        </h3>
        <p class="text-gray-600 text-sm">قم بتعبئة بيانات التقييم لكل لغة متاحة لضمان تجربة متكاملة.</p>
    </div>

    <div class="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
        <div class="flex border-b border-gray-200 mb-0 space-x-2 rtl:space-x-reverse px-6 pt-6 overflow-x-auto scrollbar-thin scrollbar-thumb-gray-300"
            role="tablist" id="languageTabs">
            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $code = $lang->code;
                    $hasLanguageError = $languageErrorMap[$code] ?? false;
                    $isDefaultActive = $firstErrorLang ? $firstErrorLang === $code : $loop->first;
                    $tabClasses =
                        'lang-tab lang-tab-btn px-4 py-3 rounded-t-lg transition-all duration-200 focus:outline-none whitespace-nowrap hover:bg-gray-50 ';

                    if ($isDefaultActive) {
                        $tabClasses .= $hasLanguageError
                            ? 'bg-red-50 text-red-700 border-b-2 border-red-500 font-semibold focus:ring-red-400 '
                            : 'bg-white text-indigo-600 border-b-2 border-indigo-500 font-semibold focus:ring-indigo-400 ';
                    } else {
                        $tabClasses .= $hasLanguageError
                            ? 'bg-red-50 text-red-700 border border-red-200 focus:ring-red-400 '
                            : 'bg-gray-100 text-gray-600 border-transparent focus:ring-indigo-400 ';
                    }
                ?>
                <button type="button" onclick="switchLanguageTab('<?php echo e($code); ?>')"
                    onkeydown="handleTabKeydown(event, '<?php echo e($code); ?>')" id="lang-tab-<?php echo e($code); ?>"
                    role="tab" aria-controls="lang-panel-<?php echo e($code); ?>"
                    aria-selected="<?php echo e($isDefaultActive ? 'true' : 'false'); ?>"
                    tabindex="<?php echo e($isDefaultActive ? '0' : '-1'); ?>"
                    aria-invalid="<?php echo e($hasLanguageError ? 'true' : 'false'); ?>" data-lang-code="<?php echo e($code); ?>"
                    data-has-error="<?php echo e($hasLanguageError ? 'true' : 'false'); ?>" class="<?php echo e(trim($tabClasses)); ?>">
                    <div class="lang-tab-label flex items-center space-x-2 rtl:space-x-reverse">
                        <div
                            class="w-6 h-6 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center text-xs font-bold">
                            <?php echo e(strtoupper(substr($code, 0, 2))); ?>

                        </div>
                        <span><?php echo e($lang->native); ?></span>
                        <?php if($hasLanguageError): ?>
                            <span
                                class="lang-error-indicator inline-flex items-center gap-1 text-xs font-semibold text-red-600">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 9v2m0 4h.01M12 5a7 7 0 100 14 7 7 0 000-14z"></path>
                                </svg>
                                <span>تحقق</span>
                            </span>
                        <?php endif; ?>
                        <?php if($isDefaultActive): ?>
                            <svg class="lang-checkmark w-4 h-4 <?php echo e($hasLanguageError ? 'text-red-500' : 'text-indigo-500'); ?>"
                                fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M5 13l4 4L19 7"></path>
                            </svg>
                        <?php endif; ?>
                    </div>
                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="p-6 bg-gray-50">
            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $translation = $testimonialTranslations[$lang->code] ?? null;
                    $panelCode = $lang->code;
                    $panelHasError = $languageErrorMap[$panelCode] ?? false;
                    $shouldShowPanel = $firstErrorLang ? $firstErrorLang === $panelCode : $loop->first;
                ?>
                <div id="lang-panel-<?php echo e($panelCode); ?>" role="tabpanel"
                    aria-labelledby="lang-tab-<?php echo e($panelCode); ?>"
                    class="lang-panel <?php echo e($shouldShowPanel ? 'block' : 'hidden'); ?> transition-all duration-300 ease-out"
                    data-lang-panel="<?php echo e($panelCode); ?>" data-has-error="<?php echo e($panelHasError ? 'true' : 'false'); ?>">
                    <div class="space-y-6">
                        <div>
                            <label class="flex items-center text-sm font-semibold text-gray-700 mb-2">
                                <svg class="w-4 h-4 ml-2 text-indigo-500" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 11c0 4.418-1.79 8-4 8s-4-3.582-4-8 1.79-8 4-8 4 3.582 4 8zm0 0c0 4.418 1.79 8 4 8s4-3.582 4-8-1.79-8-4-8-4 3.582-4 8z">
                                    </path>
                                </svg>
                                اسم صاحب التقييم
                            </label>
                            <input type="text" name="testimonialTranslations[<?php echo e($lang->code); ?>][name]"
                                value="<?php echo e(old('testimonialTranslations.' . $lang->code . '.name', $translation['name'] ?? '')); ?>"
                                class="form-control" placeholder="أدخل اسم صاحب التقييم">
                            <?php $__errorArgs = ['testimonialTranslations.' . $lang->code . '.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-sm text-red-600 mt-2"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="flex items-center text-sm font-semibold text-gray-700 mb-2">
                                <svg class="w-4 h-4 ml-2 text-indigo-500" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M7 8h10M7 12h8m-5 4h5M5 6h-.01M5 10h-.01M5 14h-.01M5 18h-.01"></path>
                                </svg>
                                نص التقييم
                            </label>
                            <textarea rows="4" name="testimonialTranslations[<?php echo e($lang->code); ?>][feedback]"
                                class="form-control min-h-[120px]" placeholder="اكتب التقييم"><?php echo e(old('testimonialTranslations.' . $lang->code . '.feedback', $translation['feedback'] ?? '')); ?></textarea>
                            <?php $__errorArgs = ['testimonialTranslations.' . $lang->code . '.feedback'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-sm text-red-600 mt-2"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="flex items-center text-sm font-semibold text-gray-700 mb-2">
                                <svg class="w-4 h-4 ml-2 text-indigo-500" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.69 6.479A11.952 11.952 0 0112 21.75a11.952 11.952 0 01-6.85-4.693 12.086 12.086 0 01.69-6.479L12 14z">
                                    </path>
                                </svg>
                                المسمى الوظيفي أو مجال العمل
                            </label>
                            <input type="text" name="testimonialTranslations[<?php echo e($lang->code); ?>][major]"
                                value="<?php echo e(old('testimonialTranslations.' . $lang->code . '.major', $translation['major'] ?? '')); ?>"
                                class="form-control" placeholder="مثال: مدير التسويق">
                            <?php $__errorArgs = ['testimonialTranslations.' . $lang->code . '.major'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-sm text-red-600 mt-2"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <input type="hidden" name="testimonialTranslations[<?php echo e($lang->code); ?>][locale]"
                            value="<?php echo e($lang->code); ?>">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<div class="col-span-12 mt-8">
    <div
        class="bg-gradient-to-r from-gray-50 to-white p-6 rounded-2xl border border-gray-200 flex flex-col sm:flex-row items-center justify-end gap-4">
        <a href="<?php echo e(route('dashboard.testimonials.index')); ?>"
            class="inline-flex items-center px-8 py-3 bg-gray-500 hover:bg-gray-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-gray-300">
            <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12">
                </path>
            </svg>
            إلغاء
        </a>
        <button type="submit" class="inline-flex items-center px-8 py-3 btn btn-primary">
            <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            حفظ التقييم
        </button>
    </div>
</div>


<?php $__env->startPush('scripts'); ?>
    <script>
        (() => {
            const tabIds = <?php echo json_encode($languages->pluck('code'), 15, 512) ?>;
            const firstErrorLang = <?php echo json_encode($firstErrorLang ?? '', 15, 512) ?>;
            const defaultLang = <?php echo json_encode($languages->first()->code ?? '', 15, 512) ?>;
            const storageKey = 'testimonialActiveLangTab';

            function applyTabClasses(tab, isActive) {
                const hasError = tab.dataset.hasError === 'true';
                const classesToRemove = [
                    'bg-white', 'text-indigo-600', 'border-b-2', 'border-indigo-500', 'font-semibold',
                    'bg-gray-100', 'text-gray-600', 'border-transparent',
                    'bg-red-50', 'text-red-700', 'border-red-500', 'border-red-200', 'border',
                    'focus:ring-indigo-400', 'focus:ring-red-400'
                ];
                tab.classList.remove(...classesToRemove);

                if (isActive) {
                    if (hasError) {
                        tab.classList.add('bg-red-50', 'text-red-700', 'border-b-2', 'border-red-500', 'font-semibold',
                            'focus:ring-red-400');
                    } else {
                        tab.classList.add('bg-white', 'text-indigo-600', 'border-b-2', 'border-indigo-500',
                            'font-semibold', 'focus:ring-indigo-400');
                    }
                } else {
                    if (hasError) {
                        tab.classList.add('bg-red-50', 'text-red-700', 'border', 'border-red-200',
                            'focus:ring-red-400');
                    } else {
                        tab.classList.add('bg-gray-100', 'text-gray-600', 'border-transparent',
                            'focus:ring-indigo-400');
                    }
                }
            }

            function updatePanelVisibility(activeCode) {
                document.querySelectorAll('.lang-panel').forEach(panel => {
                    panel.classList.add('hidden');
                });
                const panel = document.getElementById(`lang-panel-${activeCode}`);
                if (panel) {
                    panel.classList.remove('hidden');
                }
            }

            function switchLanguageTab(langCode) {
                const tabs = document.querySelectorAll('.lang-tab-btn');
                tabs.forEach(tab => {
                    const isActive = tab.id === `lang-tab-${langCode}`;
                    applyTabClasses(tab, isActive);
                    tab.setAttribute('aria-selected', isActive ? 'true' : 'false');
                    tab.setAttribute('tabindex', isActive ? '0' : '-1');
                    tab.querySelector('.lang-checkmark')?.remove();
                });

                const activeTab = document.getElementById(`lang-tab-${langCode}`);
                if (activeTab) {
                    const label = activeTab.querySelector('.lang-tab-label');
                    if (label && !label.querySelector('.lang-checkmark')) {
                        const checkIcon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                        checkIcon.setAttribute('class',
                            `lang-checkmark w-4 h-4 ${activeTab.dataset.hasError === 'true' ? 'text-red-500' : 'text-indigo-500'}`
                        );
                        checkIcon.setAttribute('fill', 'none');
                        checkIcon.setAttribute('stroke', 'currentColor');
                        checkIcon.setAttribute('viewBox', '0 0 24 24');
                        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                        path.setAttribute('stroke-linecap', 'round');
                        path.setAttribute('stroke-linejoin', 'round');
                        path.setAttribute('stroke-width', '2');
                        path.setAttribute('d', 'M5 13l4 4L19 7');
                        checkIcon.appendChild(path);
                        label.appendChild(checkIcon);
                    }
                }

                updatePanelVisibility(langCode);

                if (tabIds.includes(langCode)) {
                    localStorage.setItem(storageKey, langCode);
                }
            }

            function handleTabKeydown(event, langCode) {
                const tabs = Array.from(document.querySelectorAll('.lang-tab-btn'));
                const currentIndex = tabs.findIndex(tab => tab.id === `lang-tab-${langCode}`);
                if (currentIndex === -1) {
                    return;
                }

                let nextIndex = null;
                switch (event.key) {
                    case 'ArrowLeft':
                        nextIndex = (currentIndex - 1 + tabs.length) % tabs.length;
                        break;
                    case 'ArrowRight':
                        nextIndex = (currentIndex + 1) % tabs.length;
                        break;
                    case 'Home':
                        nextIndex = 0;
                        break;
                    case 'End':
                        nextIndex = tabs.length - 1;
                        break;
                }

                if (nextIndex !== null) {
                    event.preventDefault();
                    const nextCode = tabs[nextIndex].id.replace('lang-tab-', '');
                    switchLanguageTab(nextCode);
                    tabs[nextIndex].focus();
                }
            }

            window.switchLanguageTab = switchLanguageTab;
            window.handleTabKeydown = handleTabKeydown;

            document.addEventListener('DOMContentLoaded', () => {
                const saved = localStorage.getItem(storageKey);
                const initial = firstErrorLang || (saved && tabIds.includes(saved) ? saved : (defaultLang ||
                    tabIds[0]));
                if (initial) {
                    switchLanguageTab(initial);
                }
            });
        })();
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\testimonials\_form.blade.php ENDPATH**/ ?>