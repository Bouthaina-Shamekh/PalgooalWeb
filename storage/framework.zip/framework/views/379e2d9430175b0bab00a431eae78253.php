<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.clients')); ?>">Clients</a></li>
                <li class="breadcrumb-item" aria-current="page">Client Details</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0"><?php echo e($client->first_name); ?> <?php echo e($client->last_name); ?></h2>
            </div>
        </div>
    </div>

    <?php echo $__env->make('dashboard.clients._alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12 lg:col-span-4">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img src="<?php echo e($client->avatar ? asset('storage/' . $client->avatar) : asset('assets/images/user/avatar-1.jpg')); ?>"
                            class="w-24 h-24 mx-auto rounded-full object-cover border-4 border-gray-200 shadow-lg"
                            alt="Client avatar">
                    </div>

                    <h4 class="mb-1 font-semibold"><?php echo e($client->first_name); ?> <?php echo e($client->last_name); ?></h4>
                    <p class="text-gray-600 mb-2"><?php echo e($client->email); ?></p>

                    <?php if($client->company_name): ?>
                        <p class="text-sm text-gray-500 mb-3">
                            <i class="ti ti-building mr-1"></i><?php echo e($client->company_name); ?>

                        </p>
                    <?php endif; ?>

                    <div class="flex justify-center gap-2 mb-4">
                        <?php if($client->status === 'active'): ?>
                            <span class="badge bg-success-500/10 text-success-500 rounded-full px-3 py-1">
                                <i class="ti ti-check w-3 h-3 mr-1"></i>Active
                            </span>
                        <?php else: ?>
                            <span class="badge bg-danger-500/10 text-danger rounded-full px-3 py-1">
                                <i class="ti ti-ban w-3 h-3 mr-1"></i>Inactive
                            </span>
                        <?php endif; ?>

                        <?php if($client->can_login): ?>
                            <span class="badge bg-blue-500/10 text-blue-500 rounded-full px-3 py-1">
                                <i class="ti ti-login w-3 h-3 mr-1"></i>Can Login
                            </span>
                        <?php else: ?>
                            <span class="badge bg-gray-500/10 text-gray-500 rounded-full px-3 py-1">
                                <i class="ti ti-lock w-3 h-3 mr-1"></i>No Login
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="grid grid-cols-3 gap-4 mt-4">
                        <div class="text-center">
                            <div class="text-2xl font-bold text-blue-600"><?php echo e($client->subscriptions_count ?? 0); ?></div>
                            <div class="text-xs text-gray-500">Subscriptions</div>
                        </div>
                        <div class="text-center">
                            <div class="text-2xl font-bold text-green-600"><?php echo e($client->domains_count ?? 0); ?></div>
                            <div class="text-xs text-gray-500">Domains</div>
                        </div>
                        <div class="text-center">
                            <div class="text-2xl font-bold text-purple-600"><?php echo e($client->contacts_count ?? 0); ?></div>
                            <div class="text-xs text-gray-500">Contacts</div>
                        </div>
                    </div>

                    <div class="flex gap-2 mt-6">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', 'App\\Models\\Client')): ?>
                            <a href="<?php echo e(route('dashboard.clients.edit', $client)); ?>" class="btn btn-primary btn-sm flex-1">
                                <i class="ti ti-edit mr-1"></i>Edit
                            </a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('dashboard.clients')); ?>" class="btn btn-secondary btn-sm flex-1">
                            <i class="ti ti-arrow-left mr-1"></i>Back
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-span-12 lg:col-span-8">
            <div class="card">
                <div class="card-header">
                    <div class="border-b border-gray-200 mb-6">
                        <nav class="flex flex-wrap gap-2" aria-label="Tabs">
                            <a href="<?php echo e(route('dashboard.clients.show', ['client' => $client, 'tab' => 'details'])); ?>"
                                class="flex items-center px-4 py-3 text-sm font-medium rounded-t-lg transition-colors duration-200 <?php echo e($activeTab === 'details' ? 'bg-blue-50 text-blue-700 border-b-2 border-blue-700' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'); ?>">
                                <i class="ti ti-user text-lg mr-2"></i>
                                <span>Details</span>
                            </a>
                            <a href="<?php echo e(route('dashboard.clients.show', ['client' => $client, 'tab' => 'contacts'])); ?>"
                                class="flex items-center px-4 py-3 text-sm font-medium rounded-t-lg transition-colors duration-200 <?php echo e($activeTab === 'contacts' ? 'bg-blue-50 text-blue-700 border-b-2 border-blue-700' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'); ?>">
                                <i class="ti ti-users text-lg mr-2"></i>
                                <span>Contacts</span>
                                <?php if($clientContacts->count() > 0): ?>
                                    <span class="ml-2 inline-flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-blue-500 rounded-full">
                                        <?php echo e($clientContacts->count()); ?>

                                    </span>
                                <?php endif; ?>
                            </a>
                            <a href="<?php echo e(route('dashboard.clients.show', ['client' => $client, 'tab' => 'notes'])); ?>"
                                class="flex items-center px-4 py-3 text-sm font-medium rounded-t-lg transition-colors duration-200 <?php echo e($activeTab === 'notes' ? 'bg-blue-50 text-blue-700 border-b-2 border-blue-700' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'); ?>">
                                <i class="ti ti-notes text-lg mr-2"></i>
                                <span>Notes</span>
                                <?php if($clientNotes->count() > 0): ?>
                                    <span class="ml-2 inline-flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-green-500 rounded-full">
                                        <?php echo e($clientNotes->count()); ?>

                                    </span>
                                <?php endif; ?>
                            </a>
                            <a href="<?php echo e(route('dashboard.clients.show', ['client' => $client, 'tab' => 'activities'])); ?>"
                                class="flex items-center px-4 py-3 text-sm font-medium rounded-t-lg transition-colors duration-200 <?php echo e($activeTab === 'activities' ? 'bg-blue-50 text-blue-700 border-b-2 border-blue-700' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'); ?>">
                                <i class="ti ti-history text-lg mr-2"></i>
                                <span>Activities</span>
                                <?php if($clientActivities->count() > 0): ?>
                                    <span class="ml-2 inline-flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-purple-500 rounded-full">
                                        <?php echo e($clientActivities->count()); ?>

                                    </span>
                                <?php endif; ?>
                            </a>
                        </nav>
                    </div>
                </div>

                <div class="card-body">
                    <?php if($activeTab === 'details'): ?>
                        <div class="grid grid-cols-12 gap-4">
                            <div class="col-span-12">
                                <h5 class="mb-4 font-semibold text-gray-900">Personal Information</h5>
                            </div>
                            <div class="col-span-12 md:col-span-6">
                                <label class="text-sm text-gray-600">First Name</label>
                                <p class="font-medium"><?php echo e($client->first_name); ?></p>
                            </div>
                            <div class="col-span-12 md:col-span-6">
                                <label class="text-sm text-gray-600">Last Name</label>
                                <p class="font-medium"><?php echo e($client->last_name); ?></p>
                            </div>
                            <div class="col-span-12 md:col-span-6">
                                <label class="text-sm text-gray-600">Email</label>
                                <p class="font-medium"><?php echo e($client->email); ?></p>
                            </div>
                            <div class="col-span-12 md:col-span-6">
                                <label class="text-sm text-gray-600">Phone</label>
                                <p class="font-medium"><?php echo e($client->phone ?: 'Not provided'); ?></p>
                            </div>
                            <div class="col-span-12 md:col-span-6">
                                <label class="text-sm text-gray-600">Company</label>
                                <p class="font-medium"><?php echo e($client->company_name ?: 'Not provided'); ?></p>
                            </div>
                            <div class="col-span-12 md:col-span-6">
                                <label class="text-sm text-gray-600">Member Since</label>
                                <p class="font-medium"><?php echo e($client->created_at->format('M j, Y')); ?></p>
                            </div>

                            <?php if($client->country || $client->city || $client->address): ?>
                                <div class="col-span-12 mt-4">
                                    <h5 class="mb-4 font-semibold text-gray-900">Address Information</h5>
                                </div>
                                <div class="col-span-12 md:col-span-6">
                                    <label class="text-sm text-gray-600">Country</label>
                                    <p class="font-medium"><?php echo e($client->country ?: 'Not provided'); ?></p>
                                </div>
                                <div class="col-span-12 md:col-span-6">
                                    <label class="text-sm text-gray-600">City</label>
                                    <p class="font-medium"><?php echo e($client->city ?: 'Not provided'); ?></p>
                                </div>
                                <div class="col-span-12 md:col-span-8">
                                    <label class="text-sm text-gray-600">Address</label>
                                    <p class="font-medium"><?php echo e($client->address ?: 'Not provided'); ?></p>
                                </div>
                                <div class="col-span-12 md:col-span-4">
                                    <label class="text-sm text-gray-600">Zip Code</label>
                                    <p class="font-medium"><?php echo e($client->zip_code ?: 'Not provided'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if($activeTab === 'contacts'): ?>
                        <div class="space-y-6">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', 'App\\Models\\Client')): ?>
                                <div class="bg-gray-50 border border-gray-200 rounded-lg p-4">
                                    <h5 class="font-semibold text-gray-900 mb-4">Add Contact</h5>
                                    <form method="POST" action="<?php echo e(route('dashboard.clients.contacts.store', $client)); ?>" class="grid grid-cols-12 gap-4">
                                        <?php echo csrf_field(); ?>
                                        <div class="col-span-12 md:col-span-6">
                                            <label for="contact_name" class="form-label">Name</label>
                                            <input id="contact_name" name="name" type="text" class="form-control" value="<?php echo e(old('name')); ?>">
                                        </div>
                                        <div class="col-span-12 md:col-span-6">
                                            <label for="contact_email" class="form-label">Email</label>
                                            <input id="contact_email" name="email" type="email" class="form-control" value="<?php echo e(old('email')); ?>">
                                        </div>
                                        <div class="col-span-12 md:col-span-4">
                                            <label for="contact_phone" class="form-label">Phone</label>
                                            <input id="contact_phone" name="phone" type="text" class="form-control" value="<?php echo e(old('phone')); ?>">
                                        </div>
                                        <div class="col-span-12 md:col-span-4">
                                            <label for="contact_role" class="form-label">Role</label>
                                            <select id="contact_role" name="role" class="form-select">
                                                <?php $__currentLoopData = $contactRoleOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value); ?>" <?php if(old('role', 'general') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-span-12 md:col-span-4">
                                            <label for="contact_can_login" class="form-label">Login Access</label>
                                            <select id="contact_can_login" name="can_login" class="form-select">
                                                <option value="0" <?php if(old('can_login', '0') === '0'): echo 'selected'; endif; ?>>No Login</option>
                                                <option value="1" <?php if(old('can_login') === '1'): echo 'selected'; endif; ?>>Can Login</option>
                                            </select>
                                        </div>
                                        <div class="col-span-12">
                                            <label for="contact_password" class="form-label">Password</label>
                                            <input id="contact_password" name="password_hash" type="password" class="form-control">
                                            <small class="text-muted">Required only if login access is enabled.</small>
                                        </div>
                                        <div class="col-span-12 flex justify-end">
                                            <button type="submit" class="btn btn-primary">Add Contact</button>
                                        </div>
                                    </form>
                                </div>
                            <?php endif; ?>

                            <?php if($clientContacts->count() > 0): ?>
                                <div class="space-y-3">
                                    <?php $__currentLoopData = $clientContacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="border border-gray-200 rounded-lg p-4">
                                            <div class="flex justify-between items-start gap-3">
                                                <div class="flex-1">
                                                    <h6 class="font-semibold"><?php echo e($contact->name); ?></h6>
                                                    <p class="text-sm text-gray-600"><?php echo e($contact->email); ?></p>
                                                    <?php if($contact->phone): ?>
                                                        <p class="text-sm text-gray-600"><?php echo e($contact->phone); ?></p>
                                                    <?php endif; ?>
                                                    <span class="badge bg-blue-500/10 text-blue-500 rounded-full text-xs mt-2">
                                                        <?php echo e(ucfirst($contact->role)); ?>

                                                    </span>
                                                    <?php if($contact->can_login): ?>
                                                        <span class="badge bg-green-500/10 text-green-500 rounded-full text-xs mt-2 ml-1">
                                                            Can Login
                                                        </span>
                                                    <?php endif; ?>
                                                </div>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', 'App\\Models\\Client')): ?>
                                                    <form method="POST" action="<?php echo e(route('dashboard.clients.contacts.destroy', ['client' => $client, 'contact' => $contact])); ?>"
                                                        onsubmit="return confirm('Delete this contact?');">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm">
                                                            <i class="ti ti-trash"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-8">
                                    <i class="ti ti-users text-4xl text-gray-300 mb-2"></i>
                                    <p class="text-gray-500">No contacts added yet</p>
                                    <p class="text-sm text-gray-400">Add contacts to manage client communication</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if($activeTab === 'notes'): ?>
                        <div class="space-y-4">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', 'App\\Models\\Client')): ?>
                                <div class="bg-gray-50 border border-gray-200 rounded-lg p-4">
                                    <h5 class="font-semibold text-gray-900 mb-3">Add Note</h5>
                                    <form method="POST" action="<?php echo e(route('dashboard.clients.notes.store', $client)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="flex gap-3">
                                            <textarea name="note" class="form-control flex-1" rows="3" placeholder="Add a new note about this client..."><?php echo e(old('note')); ?></textarea>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="ti ti-send"></i>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            <?php endif; ?>

                            <?php if($clientNotes->count() > 0): ?>
                                <div class="space-y-3">
                                    <?php $__currentLoopData = $clientNotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="border border-gray-200 rounded-lg p-4">
                                            <div class="flex justify-between items-start mb-2 gap-3">
                                                <div class="flex items-center gap-2">
                                                    <span class="font-medium text-sm"><?php echo e($note->admin->name ?? 'Admin'); ?></span>
                                                    <span class="text-xs text-gray-500"><?php echo e($note->created_at->diffForHumans()); ?></span>
                                                </div>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', 'App\\Models\\Client')): ?>
                                                    <form method="POST" action="<?php echo e(route('dashboard.clients.notes.destroy', ['client' => $client, 'note' => $note])); ?>"
                                                        onsubmit="return confirm('Delete this note?');">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-xs">
                                                            <i class="ti ti-trash"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                            <p class="text-gray-700 mb-0"><?php echo e($note->note); ?></p>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-8">
                                    <i class="ti ti-notes text-4xl text-gray-300 mb-2"></i>
                                    <p class="text-gray-500">No notes added yet</p>
                                    <p class="text-sm text-gray-400">Add internal notes about this client</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if($activeTab === 'activities'): ?>
                        <div>
                            <h5 class="font-semibold text-gray-900 mb-4">Activity Log</h5>

                            <?php if($clientActivities->count() > 0): ?>
                                <div class="space-y-3">
                                    <?php $__currentLoopData = $clientActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="flex items-start gap-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                                            <div class="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0
                                                <?php echo e(str_contains($activity->action, 'created') ? 'bg-green-100 text-green-600' : ''); ?>

                                                <?php echo e(str_contains($activity->action, 'updated') ? 'bg-blue-100 text-blue-600' : ''); ?>

                                                <?php echo e(str_contains($activity->action, 'deleted') ? 'bg-red-100 text-red-600' : ''); ?>

                                                <?php echo e(str_contains($activity->action, 'suspended') ? 'bg-yellow-100 text-yellow-600' : ''); ?>">
                                                <?php if(str_contains($activity->action, 'created')): ?>
                                                    <i class="ti ti-plus text-lg"></i>
                                                <?php elseif(str_contains($activity->action, 'updated')): ?>
                                                    <i class="ti ti-edit text-lg"></i>
                                                <?php elseif(str_contains($activity->action, 'deleted')): ?>
                                                    <i class="ti ti-trash text-lg"></i>
                                                <?php elseif(str_contains($activity->action, 'suspended')): ?>
                                                    <i class="ti ti-ban text-lg"></i>
                                                <?php else: ?>
                                                    <i class="ti ti-activity text-lg"></i>
                                                <?php endif; ?>
                                            </div>

                                            <div class="flex-1 min-w-0">
                                                <div class="flex items-center justify-between gap-3">
                                                    <h6 class="font-medium text-gray-900">
                                                        <?php echo e(ucfirst(str_replace(['.', '_'], ' ', $activity->action))); ?>

                                                    </h6>
                                                    <span class="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                                                        <?php echo e($activity->created_at->diffForHumans()); ?>

                                                    </span>
                                                </div>

                                                <p class="text-sm text-gray-600 mt-1">
                                                    <?php echo e($activity->created_at->format('M j, Y \a\t g:i A')); ?>

                                                </p>

                                                <?php if($activity->meta && is_array($activity->meta) && count($activity->meta) > 0): ?>
                                                    <div class="mt-3 p-3 bg-gray-50 rounded-lg">
                                                        <p class="text-xs font-medium text-gray-700 mb-2">Details:</p>
                                                        <div class="grid grid-cols-1 gap-1">
                                                            <?php $__currentLoopData = $activity->meta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(!is_array($value) && !is_object($value)): ?>
                                                                    <div class="flex text-xs">
                                                                        <span class="font-medium text-gray-600 w-24 flex-shrink-0">
                                                                            <?php echo e(ucfirst(str_replace('_', ' ', $key))); ?>:
                                                                        </span>
                                                                        <span class="text-gray-800"><?php echo e($value); ?></span>
                                                                    </div>
                                                                <?php elseif(is_array($value)): ?>
                                                                    <div class="flex text-xs">
                                                                        <span class="font-medium text-gray-600 w-24 flex-shrink-0">
                                                                            <?php echo e(ucfirst(str_replace('_', ' ', $key))); ?>:
                                                                        </span>
                                                                        <span class="text-gray-800"><?php echo e(implode(', ', $value)); ?></span>
                                                                    </div>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-12">
                                    <div class="w-16 h-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-4">
                                        <i class="ti ti-history text-2xl text-gray-400"></i>
                                    </div>
                                    <h6 class="text-lg font-medium text-gray-900 mb-2">No Activities Yet</h6>
                                    <p class="text-gray-500">Client activities and system events will appear here</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\clients\show.blade.php ENDPATH**/ ?>