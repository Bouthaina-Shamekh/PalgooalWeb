<?php
// resources/views/dashboard/management/servers/accounts.blade.php
?>
<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">الرئيسية</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.servers.index')); ?>">السيرفرات</a></li>
                <li class="breadcrumb-item" aria-current="page">مواقع السيرفر</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">مواقع السيرفر: <?php echo e($server->name); ?></h2>
            </div>
        </div>
    </div>
    <div class="card mt-6">
        <div class="card-header">
            <h5 class="mb-0">قائمة المواقع (الحسابات)</h5>
        </div>
        <div class="card-body">
            <?php if(isset($error)): ?>
                <div class="alert alert-danger mb-4"><?php echo e($error); ?></div>
            <?php endif; ?>
            <?php if(isset($accounts) && count($accounts)): ?>
                <div class="table-responsive">
                    <table class="table table-hover w-full">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>الدومين</th>
                                <th>المستخدم</th>
                                <th>البريد</th>
                                <th>الحالة</th>
                                <th>إنشاء</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><?php echo e($acc['domain'] ?? '-'); ?></td>
                                    <td><?php echo e($acc['user'] ?? '-'); ?></td>
                                    <td><?php echo e($acc['email'] ?? '-'); ?></td>
                                    <td><?php echo e($acc['suspended'] ? 'موقوف' : 'نشط'); ?></td>
                                    <td><?php echo e($acc['startdate'] ?? '-'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center text-gray-500 py-8">لا يوجد مواقع أو لم يتم جلب البيانات.</div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\servers\accounts.blade.php ENDPATH**/ ?>