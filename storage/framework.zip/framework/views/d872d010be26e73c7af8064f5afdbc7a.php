<?php
    $showPromoBar = (bool) ($settings?->header_show_promo_bar ?? true);
    $headerIsSticky = (bool) ($settings?->header_is_sticky ?? true);
?>

<?php if($showPromoBar): ?>
    <?php echo $__env->make('front.layouts.partials.promo-bar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>

<header class="bg-white dark:bg-[#1c1c1c] shadow-md <?php echo e($headerIsSticky ? 'sticky top-0 z-50' : 'relative z-30'); ?>">
    <div class="flex items-center justify-between py-3 px-4 md:px-8 lg:px-24 h-20">
        <?php echo $__env->make('front.layouts.partials.header-brand', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('front.layouts.partials.desktop-nav', ['header' => $header], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('front.layouts.partials.header-actions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div id="sidebar-overlay"
        class="fixed inset-0 bg-black bg-opacity-20 z-40 hidden opacity-0 md:hidden transition-opacity duration-300">
    </div>

    <?php echo $__env->make('front.layouts.partials.mobile-sidebar', ['header' => $header], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</header>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\front\layouts\headers\default.blade.php ENDPATH**/ ?>