<?php if (isset($component)) { $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $attributes; } ?>
<?php $component = App\View\Components\ClientLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ClientLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('client.home')); ?>">اللوحة</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('client.subscriptions')); ?>">اشتراكاتي</a></li>
                <li class="breadcrumb-item" aria-current="page">#<?php echo e($subscription->id); ?></li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">تفاصيل الاشتراك</h2>
            </div>
        </div>
    </div>

    <?php if(session('ok')): ?>
        <div class="alert alert-success mb-4"><?php echo e(session('ok')); ?></div>
    <?php endif; ?>

    <div class="grid grid-cols-12 gap-6">
        <div class="col-span-12 lg:col-span-4">
            <div class="card p-6 space-y-4">
                <div>
                    <p class="text-sm text-gray-500">القالب</p>
                    <p class="font-semibold text-lg"><?php echo e($subscription->template?->translation()?->name ?? $subscription->template?->name ?? '-'); ?></p>
                </div>
                <div class="grid grid-cols-2 gap-4 text-sm text-gray-600">
                    <div>
                        <p class="text-gray-400 text-xs">الخطة</p>
                        <p class="font-medium"><?php echo e($subscription->plan?->name ?? '-'); ?></p>
                    </div>
                    <div>
                        <p class="text-gray-400 text-xs">نوع الخطة</p>
                        <p class="font-medium">
                            <?php echo e($subscription->plan?->isHosting() ? 'استضافة / WordPress' : 'داخل Palgoals'); ?>

                        </p>
                    </div>
                    <div>
                        <p class="text-gray-400 text-xs">النطاق</p>
                        <p class="font-medium break-words"><?php echo e($subscription->domain_name ?? '-'); ?></p>
                    </div>
                    <div>
                        <p class="text-gray-400 text-xs">حالة التفعيل</p>
                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium
                            <?php if($subscription->provisioning_status === 'active'): ?> bg-emerald-100 text-emerald-800
                            <?php elseif($subscription->provisioning_status === 'failed'): ?> bg-red-100 text-red-800
                            <?php else: ?> bg-yellow-100 text-yellow-800 <?php endif; ?>">
                            <?php echo e(__($subscription->provisioning_status)); ?>

                        </span>
                    </div>
                </div>
                <div class="text-xs text-gray-400">
                    <p>أُنشئ في <?php echo e(optional($subscription->provisioned_at)->format('Y-m-d H:i') ?? '—'); ?></p>
                    <p>آخر تزامن: <?php echo e(optional($subscription->last_synced_at)->diffForHumans() ?? '—'); ?></p>
                </div>
            </div>
        </div>

        <div class="col-span-12 lg:col-span-8">
            <div class="card p-6">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h3 class="text-lg font-semibold">الصفحات المنشأة</h3>
                        <p class="text-sm text-gray-500">يمكنك تعديل هذه الصفحات لاحقاً من أدوات البناء.</p>
                    </div>
                    <a href="<?php echo e(route('client.subscriptions')); ?>" class="btn btn-outline-primary text-sm">العودة للقائمة</a>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $subscription->pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $pageTrans = $page->translations->firstWhere('locale', $locale)
                            ?? $page->translations->first();
                    ?>
                    <div class="border rounded-xl mb-4">
                        <div class="px-4 py-3 bg-gray-50 rounded-t-xl flex items-center justify-between gap-3">
                            <div>
                                <h4 class="font-semibold text-gray-800">
                                    <?php echo e($pageTrans->title ?? $page->slug); ?>

                                    <?php if($page->is_home): ?>
                                        <span class="text-xs text-primary ms-2">الصفحة الرئيسية</span>
                                    <?php endif; ?>
                                </h4>
                                <p class="text-xs text-gray-500">
                                    slug: <?php echo e($pageTrans->slug ?? $page->slug); ?>

                                </p>
                            </div>
                            <div class="flex items-center gap-2">
                                <a href="<?php echo e(route('client.subscriptions.pages.builder', [$subscription, $page])); ?>"
                                    class="text-xs px-3 py-1 rounded-full bg-primary/10 text-primary hover:bg-primary/20 transition">
                                    Page Builder
                                </a>
                                <span class="text-xs px-2 py-0.5 rounded-full <?php echo e($page->is_active ? 'bg-emerald-100 text-emerald-600' : 'bg-gray-200 text-gray-600'); ?>">
                                    <?php echo e($page->is_active ? 'نشطة' : 'معطلة'); ?>

                                </span>
                            </div>
                        </div>
                        <div class="p-4 space-y-4">
                            <?php $__empty_2 = true; $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <?php
                                    $sectionTrans = $section->translations->firstWhere('locale', $locale)
                                        ?? $section->translations->first();
                                    $content = $sectionTrans->content ?? [];
                                    $isEditing = old('section_id') == $section->id;
                                    $oldTitle = $isEditing ? old('title') : null;
                                    $oldContent = $isEditing ? old('content') : null;
                                ?>
                                <div class="border border-dashed rounded-lg p-4">
                                    <p class="text-xs uppercase tracking-wide text-gray-400">
                                        <?php echo e($section->key ?? 'section'); ?> · ترتيب <?php echo e($section->sort_order); ?>

                                    </p>
                                    <h5 class="text-base font-semibold mt-1"><?php echo e($sectionTrans->title ?? '---'); ?></h5>
                                    <form method="POST"
                                        action="<?php echo e(route('client.subscriptions.sections.update', [$subscription, $section])); ?>"
                                        class="mt-4 space-y-3">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="section_id" value="<?php echo e($section->id); ?>">
                                        <div>
                                            <label class="block text-xs font-semibold text-gray-500 mb-1">عنوان القسم</label>
                                            <input type="text" name="title"
                                                value="<?php echo e($oldTitle ?? $sectionTrans->title); ?>"
                                                class="w-full border rounded-lg px-3 py-2 focus:ring focus:ring-primary/20"
                                                placeholder="مثال: رسوم التصميم تبدأ من ...">
                                        </div>
                                        <div>
                                            <label class="block text-xs font-semibold text-gray-500 mb-1">
                                                محتوى يظهر في الموقع (نص عادي أو عناصر متعددة)
                                            </label>
                                            <textarea name="content" rows="5"
                                                class="w-full border rounded-lg px-3 py-2 font-mono text-xs focus:ring focus:ring-primary/20"
                                                placeholder='مثال بسيط: نحن نخدمكم 24/7
مثال متقدم: { "title": "مميزاتنا", "items": [{ "text": "سرعة التنفيذ" }] }'><?php echo e($oldContent ?? (is_array($content) ? json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) : (is_string($content) ? $content : ''))); ?></textarea>
                                            <p class="text-xs text-gray-400 mt-1">اكتب نصاً عادياً، أو استخدم التنسيق المتقدم (JSON) إذا أردت عناصر متعددة.</p>
                                            <?php if($errors->has('content_' . $section->id)): ?>
                                                <p class="text-xs text-red-600 mt-1"><?php echo e($errors->first('content_' . $section->id)); ?></p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="flex justify-end gap-2">
                                            <?php if(session('last_section_id') == $section->id): ?>
                                                <span class="text-xs text-emerald-600 self-center">تم الحفظ للتو.</span>
                                            <?php endif; ?>
                                            <button type="submit"
                                                class="px-3 py-1.5 rounded-lg bg-primary text-white text-sm hover:bg-primary/90">
                                                حفظ التعديلات
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <p class="text-sm text-gray-500">لا توجد أقسام لهذه الصفحة بعد.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center text-gray-500 py-12">
                        لا توجد صفحات بعد لهذا الاشتراك. أعد التفعيل أو تواصل مع الدعم.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $attributes = $__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $component = $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\client\subscriptions\show.blade.php ENDPATH**/ ?>