<?php
    $url = url()->current();
?>
<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>" class="preset-1" data-pc-sidebar-caption="false" data-pc-layout="vertical"
    data-pc-direction="rtl" dir="<?php echo e(current_dir()); ?>" data-pc-theme_contrast="" data-pc-theme="light">
<!-- [Head] start -->

<head>
    <title><?php echo e(t('dashboard.features_title')); ?></title>
    <!-- [Meta] -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="Phoenixcoded" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- [Favicon] icon -->
    <link rel="icon"
        href="<?php echo e($settings?->favicon ? asset('storage/' . $settings->favicon) : asset('assets/images/favicon.ico')); ?>"
        type="image/x-icon">
    <!-- [Font] Family -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/fonts/inter/inter.css')); ?>" id="main-font-link" />
    <!-- [phosphor Icons] https://phosphoricons.com/ -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/fonts/phosphor/duotone/style.css')); ?>" />
    <!-- [Tabler Icons] https://tablericons.com -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/fonts/tabler-icons.min.css')); ?>" />
    <!-- [Feather Icons] https://feathericons.com -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/fonts/feather.css')); ?>" />
    <!-- [Font Awesome Icons] https://fontawesome.com/icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/fonts/fontawesome.css')); ?>" />
    <!-- [Material Icons] https://fonts.google.com/icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/fonts/material.css')); ?>" />
    <!-- [Template CSS Files] -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/style.css')); ?>" id="" />
    <!-- [Dashboard Custom CSS] -->
    <link rel="stylesheet" href="<?php echo e(mix('assets/dashboard/css/dashboard.css')); ?>" />
    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php if (! (request()->routeIs('dashboard.general_settings', 'dashboard.menus', 'dashboard.headers'))): ?>
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php endif; ?>
</head>
<!-- [Head] end -->
<!-- [Body] Start -->

<body>
    <!-- [ Pre-loader ] start -->
    <div class="loader-bg fixed inset-0 bg-white dark:bg-themedark-cardbg z-[1034]">
        <div class="loader-track h-[5px] w-full inline-block absolute overflow-hidden top-0 bg-primary-500/10">
            <div
                class="loader-fill w-[300px] h-[5px] bg-primary-500 absolute top-0 left-0 transition-[transform_0.2s_linear] origin-left animate-[2.1s_cubic-bezier(0.65,0.815,0.735,0.395)_0s_infinite_normal_none_running_loader-animate]">
            </div>
        </div>
    </div>
    <!-- [ Pre-loader ] End -->
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\layouts\partials\head.blade.php ENDPATH**/ ?>