<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['data','templates']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['data','templates']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginalce674b3929aa5ec28dfd318bbf780ba3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce674b3929aa5ec28dfd318bbf780ba3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.template.sections.services','data' => ['data' => $data,'templates' => $templates]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('template.sections.services'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'templates' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($templates)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce674b3929aa5ec28dfd318bbf780ba3)): ?>
<?php $attributes = $__attributesOriginalce674b3929aa5ec28dfd318bbf780ba3; ?>
<?php unset($__attributesOriginalce674b3929aa5ec28dfd318bbf780ba3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce674b3929aa5ec28dfd318bbf780ba3)): ?>
<?php $component = $__componentOriginalce674b3929aa5ec28dfd318bbf780ba3; ?>
<?php unset($__componentOriginalce674b3929aa5ec28dfd318bbf780ba3); ?>
<?php endif; ?><?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\storage\framework\views/31191f445d7de376cf4605d7bd27141e.blade.php ENDPATH**/ ?>