<?php if (isset($component)) { $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $attributes; } ?>
<?php $component = App\View\Components\ClientLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ClientLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        $statusClasses = [
            'paid' => 'bg-success-500/10 text-success-700',
            'unpaid' => 'bg-warning-500/10 text-warning-700',
            'draft' => 'bg-secondary-500/10 text-secondary-700',
            'cancelled' => 'bg-danger-500/10 text-danger-700',
        ];
    ?>

    <div class="page-header">
        <div class="page-block">
            <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('client.home')); ?>"><?php echo e(t('frontend.client_nav.home', 'Home')); ?></a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <?php echo e(t('frontend.client_nav.invoices', 'Invoices')); ?>

                        </li>
                    </ul>
                    <div class="page-header-title">
                        <h2 class="mb-1"><?php echo e(t('frontend.client_invoices.index.title', 'Invoices')); ?></h2>
                        <p class="mb-0 text-sm text-muted">
                            <?php echo e(t('frontend.client_invoices.index.subtitle', 'Review invoice history and reopen any unpaid invoice in the demo payment flow.')); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if(session('info')): ?>
        <div class="alert alert-info" role="alert"><?php echo e(session('info')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <h5 class="mb-0"><?php echo e(t('frontend.client_invoices.index.list_title', 'Invoice List')); ?></h5>
                <span class="text-sm text-muted">
                    <?php echo e(t('frontend.client_invoices.index.total_records', ':count invoices', ['count' => $invoices->total()])); ?>

                </span>
            </div>
        </div>
        <div class="card-body">
            <div class="overflow-x-auto">
                <table class="table table-hover w-full align-middle">
                    <thead>
                        <tr>
                            <th><?php echo e(t('frontend.client_invoices.index.number', 'Number')); ?></th>
                            <th><?php echo e(t('frontend.client_invoices.index.items', 'Items')); ?></th>
                            <th><?php echo e(t('frontend.client_invoices.index.total', 'Total')); ?></th>
                            <th><?php echo e(t('frontend.client_invoices.index.status', 'Status')); ?></th>
                            <th><?php echo e(t('frontend.client_invoices.index.due_date', 'Due Date')); ?></th>
                            <th class="text-end"><?php echo e(t('frontend.client_invoices.index.actions', 'Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $status = (string) ($invoice->status ?? 'draft');
                                $statusClass = $statusClasses[$status] ?? 'bg-secondary-500/10 text-secondary-700';
                                $itemsSummary = $invoice->items
                                    ->take(2)
                                    ->pluck('description')
                                    ->filter()
                                    ->implode(', ');
                            ?>
                            <tr>
                                <td>
                                    <div class="font-medium text-body"><?php echo e($invoice->number); ?></div>
                                    <div class="text-xs text-muted"><?php echo e($invoice->created_at?->format('Y-m-d H:i')); ?></div>
                                </td>
                                <td>
                                    <div class="text-sm text-body"><?php echo e($itemsSummary ?: t('frontend.client_invoices.index.no_items', 'No items')); ?></div>
                                    <div class="text-xs text-muted">
                                        <?php echo e(t('frontend.client_invoices.index.item_count', ':count item(s)', ['count' => $invoice->items->count()])); ?>

                                    </div>
                                </td>
                                <td class="font-medium text-body">
                                    <?php echo e(number_format(($invoice->total_cents ?? 0) / 100, 2)); ?> <?php echo e($invoice->currency ?? 'USD'); ?>

                                </td>
                                <td>
                                    <span class="badge <?php echo e($statusClass); ?>">
                                        <?php echo e(t('frontend.client_invoices.status.' . $status, ucfirst($status))); ?>

                                    </span>
                                </td>
                                <td><?php echo e($invoice->due_date?->format('Y-m-d') ?? '-'); ?></td>
                                <td class="text-end">
                                    <?php if(in_array($status, ['draft', 'unpaid'], true)): ?>
                                        <a href="<?php echo e(route('client.invoices.checkout', $invoice)); ?>" class="btn btn-sm btn-primary">
                                            <?php echo e(t('frontend.client_invoices.index.pay_now', 'Pay Now')); ?>

                                        </a>
                                    <?php elseif($status === 'paid'): ?>
                                        <a href="<?php echo e(route('client.invoices.checkout', $invoice)); ?>" class="btn btn-sm btn-light-success">
                                            <?php echo e(t('frontend.client_invoices.index.view_result', 'View Result')); ?>

                                        </a>
                                    <?php else: ?>
                                        <span class="text-sm text-muted">
                                            <?php echo e(t('frontend.client_invoices.index.no_action', 'No action')); ?>

                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="py-8 text-center text-muted">
                                    <?php echo e(t('frontend.client_invoices.index.empty', 'No invoices found yet.')); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                <?php echo e($invoices->links()); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $attributes = $__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $component = $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\client\invoices.blade.php ENDPATH**/ ?>