<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name',                 // اسم الحقل في الفورم (إجباري)
    'label' => null,        // عنوان الحقل
    'buttonText' => 'اختر من مكتبة الوسائط', // نص الزر
    'multiple' => false,    // هل الاختيار متعدد؟
    'value' => null,        // القيمة الحالية (id أو "1,2,3")
    'previewUrls' => [],    // مصفوفة روابط للمعاينة المبدئية
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name',                 // اسم الحقل في الفورم (إجباري)
    'label' => null,        // عنوان الحقل
    'buttonText' => 'اختر من مكتبة الوسائط', // نص الزر
    'multiple' => false,    // هل الاختيار متعدد؟
    'value' => null,        // القيمة الحالية (id أو "1,2,3")
    'previewUrls' => [],    // مصفوفة روابط للمعاينة المبدئية
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    // نقرأ الـ id القادم من الـ attributes (مثلاً featured_image_id)
    $rawId = $attributes->get('id');

    // هذا هو الـ id الذي سيُستخدم للـ <input> المخفي
    $inputId = $rawId ?: 'mp_' . uniqid();
    $previewId = $inputId . '_preview';

    // نتأكد أن الـ wrapper ما ياخذش نفس الـ id عشان ما يكونش عندنا عنصرين بنفس الـ id
    $containerAttributes = $attributes->except('id');

    $isMultiple = (bool) $multiple;

    // تجهيز قيمة الـ input حسب نوع الحقل
    if ($isMultiple) {
        if (is_string($value)) {
            $idsArray = array_filter(explode(',', $value));
        } elseif (is_array($value)) {
            $idsArray = $value;
        } else {
            $idsArray = [];
        }
        $inputValue = implode(',', $idsArray);
    } else {
        // single
        if (is_array($value)) {
            $inputValue = reset($value) ?: '';
        } else {
            $inputValue = $value ?? '';
        }
    }

    // نتأكد أن الـ previewUrls مصفوفة عادية
    if ($previewUrls instanceof \Illuminate\Support\Collection) {
        $previewUrls = $previewUrls->all();
    }
?>

<div <?php echo e($containerAttributes->class('col-span-6')); ?>>
    <?php if($label): ?>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
            <?php echo e($label); ?>

        </label>
    <?php endif; ?>

    
    <input
        type="hidden"
        id="<?php echo e($inputId); ?>"
        name="<?php echo e($name); ?>"
        value="<?php echo e($inputValue); ?>"
    >

    
    <button
        type="button"
        class="inline-flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-200 btn-open-media-picker"
        data-target-input="<?php echo e($inputId); ?>"
        data-target-preview="<?php echo e($previewId); ?>"
        data-multiple="<?php echo e($isMultiple ? 'true' : 'false'); ?>"
    >
        <?php echo e($buttonText); ?>

    </button>

    
    <div id="<?php echo e($previewId); ?>" class="mt-2 flex flex-wrap gap-2">
        <?php $__currentLoopData = $previewUrls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($url): ?>
                <div class="relative w-20 h-20 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <img src="<?php echo e($url); ?>" alt="" class="w-full h-full object-cover">
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\components\dashboard\media-picker.blade.php ENDPATH**/ ?>