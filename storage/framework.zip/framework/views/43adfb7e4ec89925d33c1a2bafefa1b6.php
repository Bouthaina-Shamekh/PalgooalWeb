<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Breadcrumb -->
    <div class="page-header mb-6">
        <div class="page-block">
            <ul class="flex flex-wrap gap-2 text-sm text-gray-500 mb-2">
                <li><a href="<?php echo e(route('dashboard.home')); ?>" class="hover:underline">Home</a></li>
                <li>/</li>
                <li><a href="<?php echo e(route('dashboard.plans.index')); ?>" class="hover:underline">Plans</a></li>
                <li>/</li>
                <li class="font-semibold">Add Plan</li>
            </ul>
            <h2 class="text-2xl font-bold">Add Hosting Plan</h2>
        </div>
    </div>

    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Basic Information</h5>
                </div>
                <div class="card-body">

                    <form id="planForm" action="<?php echo e(route('dashboard.plans.store')); ?>" method="POST" class="space-y-6">
                        <?php echo csrf_field(); ?>
                        <?php
                            $localesCollection = $languages?->pluck('name', 'code');
                            $locales = $localesCollection ? $localesCollection->filter()->toArray() : [];
                            if (empty($locales)) {
                                $locales = config('app.locales', ['ar' => 'العربية', 'en' => 'English']);
                            }
                            $activeLocale = old('active_locale', app()->getLocale());
                        ?>

                        <!-- Basic Info -->
                        <div class="grid grid-cols-12 gap-6">
                            <!-- Category -->
                            <div class="col-span-12 md:col-span-6">
                                <label class="block text-sm font-medium mb-1">Category</label>
                                <select name="plan_category_id"
                                    class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary/30">
                                    <option value="">-- None --</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $label =
                                                $cat->translation()?->title ??
                                                ($cat->translations->first()?->title ?? '#' . $cat->id);
                                        ?>
                                        <option value="<?php echo e($cat->id); ?>"
                                            <?php echo e(old('plan_category_id') == $cat->id ? 'selected' : ''); ?>>
                                            <?php echo e($label); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['plan_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Slug -->
                            <div class="col-span-12 md:col-span-6">
                                <label class="block text-sm font-medium mb-1">Plan Slug <span
                                        class="text-gray-400">(optional)</span></label>
                                <input type="text" name="slug" class="w-full border rounded-lg px-3 py-2"
                                    value="<?php echo e(old('slug')); ?>" placeholder="auto-generated if empty">
                                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-span-12 md:col-span-6">
                                <label class="block text-sm font-medium mb-1">Plan Type</label>
                                <?php
                                    $selectedType = old('plan_type', \App\Models\Plan::TYPE_MULTI_TENANT);
                                ?>
                                <select name="plan_type"
                                    class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary/30">
                                    <option value="<?php echo e(\App\Models\Plan::TYPE_MULTI_TENANT); ?>"
                                        <?php echo e($selectedType === \App\Models\Plan::TYPE_MULTI_TENANT ? 'selected' : ''); ?>>
                                        Multi-Tenant (بدون cPanel)
                                    </option>
                                    <option value="<?php echo e(\App\Models\Plan::TYPE_HOSTING); ?>"
                                        <?php echo e($selectedType === \App\Models\Plan::TYPE_HOSTING ? 'selected' : ''); ?>>
                                        Hosting / WordPress (يتضمن cPanel)
                                    </option>
                                </select>
                                <p class="text-xs text-gray-500 mt-1">يحدد إذا كان الاشتراك يعمل داخل منصة Palgoals أو يحتاج
                                    مساحة استضافة مستقلة.</p>
                                <?php $__errorArgs = ['plan_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Monthly Price -->
                            <div class="col-span-12 md:col-span-6">
                                <label class="block text-sm font-medium mb-1">Monthly Price (USD)</label>
                                <div class="flex">
                                    <span class="inline-flex items-center px-3 rounded-l-lg border bg-gray-50">$</span>
                                    <input type="number" step="0.01" min="0" id="monthly_price_ui"
                                        name="monthly_price_ui" class="w-full border rounded-r-lg px-3 py-2"
                                        value="<?php echo e(old('monthly_price_ui')); ?>">
                                </div>
                                <input type="hidden" name="monthly_price_cents" id="monthly_price_cents"
                                    value="<?php echo e(old('monthly_price_cents')); ?>">
                                <?php $__errorArgs = ['monthly_price_cents'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Annual Price -->
                            <div class="col-span-12 md:col-span-6">
                                <label class="block text-sm font-medium mb-1">Annual Price (USD)</label>
                                <div class="flex">
                                    <span class="inline-flex items-center px-3 rounded-l-lg border bg-gray-50">$</span>
                                    <input type="number" step="0.01" min="0" id="annual_price_ui"
                                        name="annual_price_ui" class="w-full border rounded-r-lg px-3 py-2"
                                        value="<?php echo e(old('annual_price_ui')); ?>">
                                </div>
                                <input type="hidden" name="annual_price_cents" id="annual_price_cents"
                                    value="<?php echo e(old('annual_price_cents')); ?>">
                                <?php $__errorArgs = ['annual_price_cents'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Status -->
                            <div class="col-span-12 md:col-span-6 flex items-center gap-2">
                                <input type="checkbox" name="is_active" value="1" <?php if(old('is_active', true)): echo 'checked'; endif; ?>
                                    class="w-4 h-4">
                                <span class="text-sm">Active (available to sell)</span>
                                <?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Featured toggle -->
                            <div class="col-span-12 md:col-span-6">
                                <label class="block text-sm font-medium mb-1">Featured Plan</label>
                                <div class="flex items-center gap-2">
                                    <input type="checkbox" name="is_featured" value="1"
                                        <?php if(old('is_featured', false)): echo 'checked'; endif; ?> class="w-4 h-4">
                                    <span class="text-sm">Highlight this plan with a special badge</span>
                                </div>
                                <?php $__errorArgs = ['is_featured'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Server -->
                            <div class="col-span-12 md:col-span-6">
                                <label class="block text-sm font-medium mb-1">Server</label>
                                <select id="server_select" name="server_id"
                                    class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary/30">
                                    <option value="">-- None --</option>
                                    <?php $__currentLoopData = $servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($server->id); ?>"
                                            <?php echo e(old('server_id') == $server->id ? 'selected' : ''); ?>>
                                            <?php echo e($server->name); ?> (<?php echo e($server->ip ?? $server->hostname); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['server_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Server Package -->
                            <div class="col-span-12 md:col-span-6">
                                <label class="block text-sm font-medium mb-1">Server Package</label>
                                <select name="server_package" id="server_package_select"
                                    class="w-full border rounded-lg px-3 py-2">
                                    <option value="">-- (select server first) --</option>
                                </select>
                                <?php $__errorArgs = ['server_package'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Translations Tabs -->
                        <div class="mt-6">
                            <h3 class="font-semibold mb-2">Translations</h3>
                            <div class="flex gap-2 mb-4 rtl:space-x-reverse">
                                <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button type="button" onclick="showLangTab('<?php echo e($locale); ?>')"
                                        class="px-4 py-2 rounded-t-lg focus:outline-none transition-all <?php echo e($activeLocale == $locale ? 'bg-white border border-b-0 font-bold' : 'bg-gray-200 text-gray-600'); ?>"
                                        id="tab-<?php echo e($locale); ?>">
                                        <?php echo e($label); ?>

                                    </button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <input type="hidden" name="active_locale" id="active_locale" value="<?php echo e($activeLocale); ?>">
                            <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="pane-<?php echo e($locale); ?>"
                                    class="lang-pane <?php echo e($activeLocale == $locale ? 'block' : 'hidden'); ?>">
                                    <div class="grid grid-cols-12 gap-6">
                                        <!-- Name -->
                                        <div class="col-span-12 md:col-span-6">
                                            <label class="block text-sm font-medium mb-1">Plan Name
                                                (<?php echo e($label); ?>)
                                                *</label>
                                            <input type="text" name="name[<?php echo e($locale); ?>]"
                                                class="w-full border rounded-lg px-3 py-2"
                                                value="<?php echo e(old('name.' . $locale)); ?>"
                                                <?php if($activeLocale == $locale): ?> required <?php endif; ?>>
                                            <?php $__errorArgs = ['name.' . $locale];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <!-- Description -->
                                        <div class="col-span-12">
                                            <label class="block text-sm font-medium mb-1">Description
                                                (<?php echo e($label); ?>)</label>
                                            <textarea name="description[<?php echo e($locale); ?>]" rows="3" class="w-full border rounded-lg px-3 py-2"><?php echo e(old('description.' . $locale)); ?></textarea>
                                            <?php $__errorArgs = ['description.' . $locale];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <!-- Featured badge label -->
                                        <div class="col-span-12 md:col-span-6">
                                            <label class="block text-sm font-medium mb-1"><?php echo e(__('Featured Badge Label')); ?>

                                                (<?php echo e($label); ?>)</label>
                                            <input type="text" name="featured_label[<?php echo e($locale); ?>]"
                                                class="w-full border rounded-lg px-3 py-2"
                                                value="<?php echo e(old('featured_label.' . $locale)); ?>" placeholder="<?php echo e(__('Most Popular')); ?>">
                                            <p class="text-xs text-gray-500 mt-1">
                                                <?php echo e(__('Shown when the plan is marked as featured. Leave empty to use the default text.')); ?>

                                            </p>
                                            <?php $__errorArgs = ['featured_label.' . $locale];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <!-- Features -->
                                        <div class="col-span-12">
                                            <label class="block text-sm font-medium mb-1">Features
                                                (<?php echo e($label); ?>)</label>
                                            <?php
                                                $rawFeatures = old('features.' . $locale);
                                                if ($rawFeatures === null) {
                                                    $rawFeatures = [];
                                                }
                                                $billingOptions = [
                                                    'monthly' => __('Monthly'),
                                                    'annual' => __('Annual'),
                                                ];
                                                $rawFeatures = is_array($rawFeatures) ? $rawFeatures : [];
                                                $hasBillingSplit = array_intersect(array_keys($rawFeatures), array_keys($billingOptions)) !== [];

                                                $normalizeFeature = function ($item) {
                                                    if (is_array($item)) {
                                                        $text = isset($item['text']) ? trim((string) $item['text']) : '';
                                                        $available = array_key_exists('available', $item)
                                                            ? filter_var($item['available'], FILTER_VALIDATE_BOOLEAN)
                                                            : true;
                                                    } else {
                                                        $text = trim((string) $item);
                                                        $available = true;
                                                    }

                                                    return [
                                                        'text' => $text,
                                                        'available' => (bool) $available,
                                                    ];
                                                };

                                                $featureBuckets = [];
                                                foreach ($billingOptions as $billingKey => $billingLabel) {
                                                    $bucketSource = $hasBillingSplit
                                                        ? ($rawFeatures[$billingKey] ?? [])
                                                        : ($billingKey === 'monthly' ? $rawFeatures : []);
                                                    $featureBuckets[$billingKey] = collect(
                                                        is_array($bucketSource) ? $bucketSource : []
                                                    )
                                                        ->map($normalizeFeature)
                                                        ->filter(fn($feature) => $feature['text'] !== '')
                                                        ->values();
                                                }
                                            ?>

                                            <div class="flex flex-wrap items-center gap-2 mb-3" data-feature-tabs>
                                                <?php $__currentLoopData = $billingOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $billingKey => $billingLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <button type="button"
                                                        class="feature-cycle-tab px-3 py-1 rounded-md border transition text-sm <?php echo e($loop->first ? 'bg-white border-gray-300 text-gray-800 font-semibold shadow-sm' : 'bg-gray-100 border-transparent text-gray-500'); ?>"
                                                        data-feature-tab
                                                        data-locale="<?php echo e($locale); ?>"
                                                        data-billing="<?php echo e($billingKey); ?>">
                                                        <?php echo e($billingLabel); ?>

                                                    </button>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                            <?php $__currentLoopData = $billingOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $billingKey => $billingLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    /** @var \Illuminate\Support\Collection $featureItems */
                                                    $featureItems = $featureBuckets[$billingKey] ?? collect();
                                                ?>
                                                <div class="<?php echo e($loop->first ? 'block' : 'hidden'); ?>"
                                                    data-feature-panel
                                                    data-locale="<?php echo e($locale); ?>"
                                                    data-billing="<?php echo e($billingKey); ?>">
                                                    <div class="space-y-2"
                                                        data-feature-wrapper
                                                        data-locale="<?php echo e($locale); ?>"
                                                        data-billing="<?php echo e($billingKey); ?>"
                                                        data-next-index="<?php echo e($featureItems->count()); ?>"
                                                        data-available-label="<?php echo e(__('Available')); ?>"
                                                        data-remove-label="<?php echo e(__('Remove feature')); ?>">
                                                        <?php $__currentLoopData = $featureItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="flex flex-col sm:flex-row sm:items-center gap-3"
                                                                data-feature-row>
                                                                <div class="flex-1 w-full">
                                                                    <input type="text"
                                                                        name="features[<?php echo e($locale); ?>][<?php echo e($billingKey); ?>][<?php echo e($index); ?>][text]"
                                                                        class="w-full border rounded-lg px-3 py-2"
                                                                        value="<?php echo e($feature['text']); ?>"
                                                                        placeholder="e.g. Domain">
                                                                </div>
                                                                <label class="inline-flex items-center gap-2 text-sm">
                                                                    <input type="hidden"
                                                                        name="features[<?php echo e($locale); ?>][<?php echo e($billingKey); ?>][<?php echo e($index); ?>][available]"
                                                                        value="0">
                                                                    <input type="checkbox"
                                                                        name="features[<?php echo e($locale); ?>][<?php echo e($billingKey); ?>][<?php echo e($index); ?>][available]"
                                                                        value="1"
                                                                        class="h-4 w-4 text-primary border-gray-300 rounded"
                                                                        <?php if($feature['available']): echo 'checked'; endif; ?>>
                                                                    <span><?php echo e(__('Available')); ?></span>
                                                                </label>
                                                                <button type="button"
                                                                    class="text-red-600 hover:text-red-800"
                                                                    data-remove-feature>
                                                                    &times;
                                                                    <span class="sr-only"><?php echo e(__('Remove feature')); ?></span>
                                                                </button>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>

                                                    <div class="mt-2 flex items-center gap-2">
                                                        <button type="button"
                                                            class="px-3 py-2 bg-primary text-white rounded-lg"
                                                            data-add-feature
                                                            data-locale="<?php echo e($locale); ?>"
                                                            data-billing="<?php echo e($billingKey); ?>">
                                                            <?php echo e(__('Add Feature')); ?>

                                                        </button>
                                                        <span class="text-xs text-gray-500">
                                                            <?php echo e(__('Use the availability toggle to highlight whether the feature is included.')); ?>

                                                        </span>
                                                    </div>

                                                    <?php if($errors->has("features.$locale.$billingKey")): ?>
                                                        <p class="text-red-600 text-sm mt-1">
                                                            <?php echo e($errors->first("features.$locale.$billingKey")); ?></p>
                                                    <?php endif; ?>
                                                    <?php if($errors->has("features.$locale.$billingKey.*.text")): ?>
                                                        <p class="text-red-600 text-sm mt-1">
                                                            <?php echo e($errors->first("features.$locale.$billingKey.*.text")); ?>

                                                        </p>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <!-- Form Buttons -->
                        <div class="flex justify-end gap-3 mt-4">
                            <a href="<?php echo e(route('dashboard.plans.index')); ?>"
                                class="px-4 py-2 border rounded-lg bg-gray-200 hover:bg-gray-300">Cancel</a>
                            <button type="submit"
                                class="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark">Create
                                Plan</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script>
        function showLangTab(locale) {
            document.querySelectorAll('.lang-pane').forEach(p => p.classList.add('hidden'));
            document.getElementById('pane-' + locale).classList.remove('hidden');
            document.getElementById('active_locale').value = locale;
            document.querySelectorAll('[id^="tab-"]').forEach(btn => btn.classList.remove('bg-white', 'border',
                'border-b-0', 'font-bold', 'text-gray-800'));
            document.getElementById('tab-' + locale).classList.add('bg-white', 'border', 'border-b-0', 'font-bold');
        }

        // Sync cents
        const monthlyUI = document.getElementById('monthly_price_ui');
        const monthlyCents = document.getElementById('monthly_price_cents');
        const annualUI = document.getElementById('annual_price_ui');
        const annualCents = document.getElementById('annual_price_cents');

        function syncCents() {
            monthlyCents.value = monthlyUI?.value ? Math.round(parseFloat(monthlyUI.value) * 100) : '';
            annualCents.value = annualUI?.value ? Math.round(parseFloat(annualUI.value) * 100) : '';
        }

        monthlyUI?.addEventListener('input', syncCents);
        annualUI?.addEventListener('input', syncCents);
        document.getElementById('planForm')?.addEventListener('submit', syncCents);

        // Fetch server packages and populate select
        async function fetchPackagesForServer(serverId, selected = '') {
            const select = document.getElementById('server_package_select');
            if (!select) {
                return;
            }
            select.innerHTML = '<option value="">Loading...</option>';
            if (!serverId) {
                select.innerHTML = '<option value="">-- (select server first) --</option>';
                return;
            }
            try {
                const res = await fetch(`<?php echo e(url('admin/servers')); ?>/${serverId}/packages`, {
                    credentials: 'same-origin',
                    headers: {
                        'Accept': 'application/json'
                    }
                });
                if (!res.ok) {
                    const text = await res.text();
                    let msg = `HTTP ${res.status}`;
                    try {
                        const j = JSON.parse(text);
                        if (j.message) msg = j.message;
                        else if (j.error) msg = j.error;
                    } catch (err) {
                        if (text) msg = text.substring(0, 200);
                    }
                    select.innerHTML = `<option value="">-- Error loading packages: ${msg} --</option>`;
                    console.error('Package fetch failed', res.status, text);
                    return;
                }

                const data = await res.json();
                select.innerHTML = '<option value="">-- None --</option>';
                const packages = data?.packages || data?.pkg || data?.data || [];
                if (Array.isArray(packages) && packages.length) {
                    packages.forEach(pkg => {
                        const opt = document.createElement('option');
                        opt.value = typeof pkg === 'string' ? pkg : (pkg.name || pkg.package || pkg.pkg || JSON.stringify(pkg));
                        opt.textContent = typeof pkg === 'string' ? pkg : (pkg.name || pkg.package || pkg.pkg || JSON.stringify(pkg));
                        if (opt.value === selected) opt.selected = true;
                        select.appendChild(opt);
                    });
                } else if (packages && typeof packages === 'object' && !Array.isArray(packages)) {
                    Object.keys(packages).forEach(k => {
                        const opt = document.createElement('option');
                        opt.value = k;
                        opt.textContent = k;
                        if (k === selected) opt.selected = true;
                        select.appendChild(opt);
                    });
                }
            } catch (e) {
                const msg = e?.message || e;
                select.innerHTML = `<option value="">-- Error loading packages: ${msg} --</option>`;
                console.error('Exception while fetching packages', e);
            }
        }

        function escapeFeatureValue(value) {
            return String(value || '')
                .replace(/&/g, '&amp;')
                .replace(/"/g, '&quot;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
        }

        function appendFeatureRow(wrapper, locale, billing, textValue = '', available = true) {
            const bucket = billing || wrapper.dataset.billing || 'monthly';
            const nextIndex = parseInt(wrapper.dataset.nextIndex || '0', 10);
            const namePrefix = 'features[' + locale + '][' + bucket + '][' + nextIndex + ']';
            const row = document.createElement('div');
            row.className = 'flex flex-col sm:flex-row sm:items-center gap-3';
            row.setAttribute('data-feature-row', '');

            const availableLabel = wrapper.dataset.availableLabel || 'Available';
            const removeLabel = wrapper.dataset.removeLabel || 'Remove feature';
            const escapedValue = escapeFeatureValue(textValue);
            const checkedAttr = available ? ' checked' : '';

            row.innerHTML =
                "<div class=\"flex-1 w-full\">" +
                "<input type=\"text\" name=\"" + namePrefix + "[text]\" class=\"w-full border rounded-lg px-3 py-2\" placeholder=\"e.g. Domain\" value=\"" + escapedValue + "\">" +
                "</div>" +
                "<label class=\"inline-flex items-center gap-2 text-sm\">" +
                "<input type=\"hidden\" name=\"" + namePrefix + "[available]\" value=\"0\">" +
                "<input type=\"checkbox\" name=\"" + namePrefix + "[available]\" value=\"1\" class=\"h-4 w-4 text-primary border-gray-300 rounded\"" + checkedAttr + ">" +
                "<span>" + availableLabel + "</span>" +
                "</label>" +
                "<button type=\"button\" class=\"text-red-600 hover:text-red-800\" data-remove-feature>&times;<span class=\"sr-only\">" + removeLabel + "</span></button>";

            wrapper.appendChild(row);
            wrapper.dataset.nextIndex = nextIndex + 1;
            const textInput = row.querySelector('input[type=\"text\"]');
            if (textInput) {
                textInput.focus();
            }
        }

        document.addEventListener('DOMContentLoaded', () => {
            syncCents();

            const serverSelect = document.getElementById('server_select');
            const serverPackageOld = <?php echo json_encode(old('server_package'), 15, 512) ?>;
            if (serverSelect && serverSelect.value) {
                fetchPackagesForServer(serverSelect.value, serverPackageOld ?? '');
            }
            serverSelect?.addEventListener('change', (e) => fetchPackagesForServer(e.target.value, ''));

            document.querySelectorAll('[data-feature-wrapper]').forEach(wrapper => {
                if (!wrapper.dataset.nextIndex) {
                    const preset = wrapper.querySelectorAll('[data-feature-row]').length;
                    wrapper.dataset.nextIndex = preset;
                }
                wrapper.addEventListener('click', (event) => {
                    const removeBtn = event.target.closest('[data-remove-feature]');
                    if (removeBtn) {
                        const row = removeBtn.closest('[data-feature-row]');
                        if (row) {
                            row.remove();
                        }
                    }
                });
            });

            document.querySelectorAll('[data-add-feature]').forEach(button => {
                button.addEventListener('click', () => {
                    const locale = button.dataset.locale;
                    const billing = button.dataset.billing;
                    const selector = '[data-feature-wrapper][data-locale=\"' + locale + '\"][data-billing=\"' + billing + '\"]';
                    const wrapper = document.querySelector(selector);
                    if (!wrapper) {
                        return;
                    }
                    appendFeatureRow(wrapper, locale, billing, '', true);
                });
            });

            const ACTIVE_TAB_CLASSES = ['bg-white', 'border-gray-300', 'text-gray-800', 'font-semibold', 'shadow-sm'];
            const INACTIVE_TAB_CLASSES = ['bg-gray-100', 'border-transparent', 'text-gray-500'];

            document.querySelectorAll('[data-feature-tab]').forEach(tab => {
                tab.addEventListener('click', () => {
                    const locale = tab.dataset.locale;
                    const billing = tab.dataset.billing;

                    document
                        .querySelectorAll('[data-feature-tab][data-locale=\"' + locale + '\"]')
                        .forEach(btn => {
                            btn.classList.remove(...ACTIVE_TAB_CLASSES);
                            btn.classList.add(...INACTIVE_TAB_CLASSES);
                        });
                    tab.classList.remove(...INACTIVE_TAB_CLASSES);
                    tab.classList.add(...ACTIVE_TAB_CLASSES);

                    document
                        .querySelectorAll('[data-feature-panel][data-locale=\"' + locale + '\"]')
                        .forEach(panel => {
                            if (panel.dataset.billing === billing) {
                                panel.classList.remove('hidden');
                                panel.classList.add('block');
                            } else {
                                panel.classList.add('hidden');
                                panel.classList.remove('block');
                            }
                        });
                });
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\plans\create.blade.php ENDPATH**/ ?>