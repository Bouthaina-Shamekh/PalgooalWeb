<?php
    $features = collect($data['features'] ?? [])
        ->filter(function ($item) {
            if (!is_array($item)) {
                return false;
            }

            $title = trim((string) ($item['title'] ?? ''));
            $description = trim((string) ($item['description'] ?? ''));
            $icon = trim((string) ($item['icon'] ?? ''));

            return $title !== '' || $description !== '' || $icon !== '';
        })
        ->values();
?>


<section class="bg-background dark:bg-gray-950 py-20 px-4 sm:px-8 lg:px-24" dir="auto" aria-labelledby="features-three-heading">
    <div class="max-w-6xl mx-auto text-center mb-12">
        <h2 id="features-three-heading" class="text-3xl lg:text-4xl font-extrabold text-primary mb-4">
            <?php echo e($data['title'] ?? __('Key Advantages')); ?>

        </h2>
        <?php if(!empty($data['subtitle'])): ?>
            <p class="text-base text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                <?php echo e($data['subtitle']); ?>

            </p>
        <?php endif; ?>
    </div>

    <div class="grid gap-8 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
        <?php $__empty_1 = true; $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white dark:bg-gray-900 rounded-xl p-6 shadow hover:shadow-lg transition flex flex-col h-full">
                <div class="flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4 shrink-0">
                    <?php if(!empty($feature['icon'])): ?>
                        <?php echo $feature['icon']; ?>

                    <?php else: ?>
                        <span class="text-lg font-semibold"><?php echo e($loop->iteration); ?></span>
                    <?php endif; ?>
                </div>
                <h3 class="text-xl font-semibold text-primary mb-2">
                    <?php echo e($feature['title'] ?? __('Feature Title')); ?>

                </h3>
                <?php if(!empty($feature['description'])): ?>
                    <p class="text-sm text-gray-600 dark:text-gray-300">
                        <?php echo e($feature['description']); ?>

                    </p>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="sm:col-span-2 lg:col-span-3 text-center text-gray-500 dark:text-gray-400">
                <?php echo e(__('No features configured yet.')); ?>

            </div>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\components\template\sections\features-3.blade.php ENDPATH**/ ?>