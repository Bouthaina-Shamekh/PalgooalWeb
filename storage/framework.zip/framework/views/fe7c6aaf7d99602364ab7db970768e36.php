<?php
    $subtitle = data_get($content, 'subtitle');
    $buttonLabel = data_get($content, 'button_label', 'Reserve a Table');
    $buttonUrl = data_get($content, 'button_url', '#');
    $image = data_get($content, 'image');
?>
<section class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-orange-500 to-red-500 text-white">
    <?php if($image): ?>
        <img src="<?php echo e($image); ?>" alt="hero" class="absolute inset-0 w-full h-full object-cover opacity-25 pointer-events-none">
    <?php endif; ?>
    <div class="relative z-10 px-8 py-14 flex flex-col gap-4">
        <p class="text-sm uppercase tracking-[0.3em] text-white/80"><?php echo e(__('Restaurant')); ?></p>
        <h2 class="text-4xl font-extrabold leading-tight"><?php echo e($translation->title ?? __('A story of flavors')); ?></h2>
        <?php if($subtitle): ?>
            <p class="text-lg text-white/90 max-w-2xl"><?php echo e($subtitle); ?></p>
        <?php endif; ?>
        <div class="mt-6">
            <a href="<?php echo e($buttonUrl); ?>" class="inline-flex items-center gap-2 bg-white text-orange-600 font-semibold px-5 py-2 rounded-full shadow hover:bg-white/90">
                <?php echo e($buttonLabel); ?>

                <span aria-hidden="true">&rarr;</span>
            </a>
        </div>
    </div>
</section><?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\tenant\sections\hero.blade.php ENDPATH**/ ?>