<?php
    use App\Support\SeoMeta;

    $baseTitle       = $title
        ?? (config('seo.default_title') ?? config('app.name', 'Palgoals'));

    $baseDescription = $description
        ?? config('seo.default_description');

    $baseKeywords    = $keywords
        ?? config('seo.default_keywords', []);

    $baseOgImage     = $ogImage
        ?? asset(config('seo.default_image', 'assets/images/default-og.jpg'));

    $baseSeo = SeoMeta::make([
        'title'       => $baseTitle,
        'description' => $baseDescription,
        'keywords'    => $baseKeywords,
        'image'       => $baseOgImage,
    ]);

    $seoPayload = isset($seo)
        ? $baseSeo->with($seo instanceof SeoMeta ? $seo->toArray() : (array) $seo)
        : $baseSeo;

    $defaultSchema = trim(view('front.layouts.partials.schema')->render());
    if ($defaultSchema !== '') {
        $existingSchema = $seoPayload->toArray()['schema'] ?? [];
        $existingSchema[] = $defaultSchema;
        $seoPayload = $seoPayload->with(['schema' => $existingSchema]);
    }
?>


<?php echo $__env->make('front.layouts.partials.head', [
    'seo' => $seoPayload ?? null,   
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php echo $__env->make('front.layouts.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="pc-container">
    <div class="pc-content">
        
        <?php echo e($slot ?? ''); ?>


        
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>


<?php echo $__env->make('front.layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php echo $__env->make('front.layouts.partials.end', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\front\layouts\app.blade.php ENDPATH**/ ?>