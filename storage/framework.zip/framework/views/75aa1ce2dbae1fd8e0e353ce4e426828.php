<div class="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg mb-8 border border-gray-200 dark:border-gray-700 space-y-6">
    
    <?php if(session()->has('success')): ?>
        <div class="flex items-center gap-3 bg-green-100 text-green-900 border border-green-300 dark:bg-green-800/20 dark:text-green-100 dark:border-green-600 px-4 py-3 rounded-lg shadow transition-all duration-300" role="alert">
            <svg class="w-5 h-5 text-green-600 dark:text-green-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
            </svg>
            <span class="text-sm font-medium"><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <div class="flex justify-between items-center">
        <h3 class="text-xl font-semibold text-gray-800 dark:text-white"><?php echo e(ucfirst($section->key)); ?></h3>
        <button onclick="confirmDeleteSection(<?php echo e($section->id); ?>)" class="text-red-600 hover:underline text-sm"><?php echo e(t('section.Delete', 'Delete')); ?></button>
    </div>

    <!-- Section order -->
    <div class="col-span-12 md:col-span-2 mb-4">
        <label class="form-label"><?php echo e(t('section.Order', 'Order')); ?></label>
        <input type="number" wire:model.defer="order" class="form-control" placeholder="<?php echo e(t('section.Example:', 'Example: 1, 2, 3')); ?>" />
    </div>

    <!-- Language tabs -->
    <div class="flex flex-wrap gap-2 mt-4">
        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button wire:click="setActiveLang('<?php echo e($lang->code); ?>')"
                class="px-4 py-2 text-sm font-medium rounded-lg transition 
                    <?php echo e($activeLang === $lang->code 
                        ? 'bg-primary text-white' 
                        : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-primary hover:text-white'); ?>">
                <?php echo e($lang->native); ?>

            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div wire:key="hosting-plans-<?php echo e($activeLang); ?>" class="grid grid-cols-12 gap-6">
        <div class="col-span-12 md:col-span-6 mb-4">
            <label class="form-label"><?php echo e(t('section.Title', 'Title')); ?></label>
            <input type="text" wire:model.defer="translationsData.<?php echo e($activeLang); ?>.title" class="form-control" placeholder="<?php echo e(t('section.Title', 'Title')); ?>" />
            <?php $__errorArgs = ["translationsData.{$activeLang}.title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-span-12 md:col-span-6 mb-4">
            <label class="form-label"><?php echo e(t('section.Brief_description', 'Brief description')); ?></label>
            <input type="text" wire:model.defer="translationsData.<?php echo e($activeLang); ?>.subtitle" class="form-control" placeholder="<?php echo e(t('section.Brief_description', 'Brief description')); ?>" />
            <?php $__errorArgs = ["translationsData.{$activeLang}.subtitle"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="col-span-12 md:col-span-6 mb-4">
            <label class="form-label"><?php echo e(t('section.Select category', 'Select category')); ?></label>
            <select wire:model="selectedCategoryId" class="form-select">
                <option value=""><?php echo e(t('section.None', '-- None --')); ?></option>
                <?php $__currentLoopData = $availableCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $catLabel = $cat->translation()?->title ?? $cat->translations->first()?->title ?? ('#' . $cat->id);
                    ?>
                    <option value="<?php echo e($cat->id); ?>"><?php echo e($catLabel); ?> (id: <?php echo e($cat->id); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <p class="text-xs text-gray-500 mt-1"><?php echo e(t('section.Or provide slug', 'Or provide category slug for finer control')); ?></p>
        </div>

        <div class="col-span-12 md:col-span-6 mb-4">
            <label class="form-label"><?php echo e(t('section.Category slug', 'Category slug (optional)')); ?></label>
            <input type="text" wire:model.defer="categorySlug" class="form-control" placeholder="<?php echo e(t('section.Slug_example', 'e.g. web-hosting')); ?>" />
            <?php $__errorArgs = ['categorySlug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <!-- Small preview -->
    <div class="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg border border-dashed">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-600 dark:text-gray-300"><?php echo e(t('section.Preview', 'Preview')); ?></p>
                <?php if($selectedCategory): ?>
                    <p class="font-semibold"><?php echo e($selectedCategory->translation()?->title ?? $selectedCategory->translations->first()?->title ?? __('Category :id', ['id' => $selectedCategory->id])); ?></p>
                    <p class="text-xs text-gray-500"><?php echo e($selectedCategory->translation()?->description ?? ''); ?></p>
                <?php elseif(!empty($categorySlug)): ?>
                    <p class="font-semibold">Slug: <?php echo e($categorySlug); ?></p>
                    <p class="text-xs text-gray-500"><?php echo e(t('section.Slug_will_be_used', 'The slug will be resolved on frontend')); ?></p>
                <?php else: ?>
                    <p class="text-sm text-gray-500"><?php echo e(t('section.No_category_selected', 'No category selected — all plans will be shown')); ?></p>
                <?php endif; ?>

                <div class="mt-3 space-y-1 text-sm text-gray-600 dark:text-gray-300">
                    <p>
                        <span class="font-semibold"><?php echo e(t('section.Title', 'Title')); ?>:</span>
                        <?php echo e(trim((string)($translationsData[$activeLang]['title'] ?? '')) !== '' ? $translationsData[$activeLang]['title'] : '—'); ?>

                    </p>
                    <p>
                        <span class="font-semibold"><?php echo e(t('section.Brief_description', 'Brief description')); ?>:</span>
                        <?php echo e(trim((string)($translationsData[$activeLang]['subtitle'] ?? '')) !== '' ? $translationsData[$activeLang]['subtitle'] : '—'); ?>

                    </p>
                </div>
            </div>

            <div>
                <p class="text-sm text-gray-500"><?php echo e(t('section.Available_plans', 'Available plans count')); ?></p>
                <p class="text-lg font-semibold"><?php echo e($previewPlansCount); ?></p>
            </div>
        </div>
    </div>

    <!-- Save -->
    <div class="text-end">
        <button wire:click="updateHostingPlansSection" wire:loading.attr="disabled" class="btn btn-primary">
            <?php echo e(t('section.Save_changes', 'Save changes')); ?>

        </button>
    </div>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\livewire\admin\sections\hosting-plans-section.blade.php ENDPATH**/ ?>