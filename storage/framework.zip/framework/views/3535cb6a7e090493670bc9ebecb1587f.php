<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('breadcrumbs', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>"><?php echo e(__('admin.Home')); ?></a></li>
        <li class="breadcrumb-item" aria-current="page"><?php echo e(__('admin.Users List')); ?></li>
     <?php $__env->endSlot(); ?>
    <div class="col-span-12">
    <div class="card">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', 'App\Models\User')): ?>
        <div class="card-header">
            <div class="sm:flex items-center justify-between">
                <h5 class="mb-3 mb-sm-0"><?php echo e(__('admin.Users List')); ?></h5>
                <div>
                    <a href="<?php echo e(route('dashboard.users.create')); ?>" class="btn btn-primary">
                        <?php echo e(__('admin.Add User')); ?>

                    </a>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="p-4">
                <form method="GET" action="<?php echo e(route('dashboard.users.index')); ?>" class="flex items-center gap-2">
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control w-1/4" placeholder="بحث حسب الاسم">
                    <button type="submit" class="btn btn-danger"><?php echo e(__('admin.Search')); ?></button>
                </form>
            </div>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', 'App\Models\User')): ?>
        <div class="card-body">
            <div class="table-responsive dt-responsive">
                <table class="table table-striped table-bordered nowrap">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('admin.Name')); ?></th>
                            <th><?php echo e(__('admin.Email')); ?></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <div class="flex items-center w-44">
                                    
                                    <div class="grow ltr:ml-3 rtl:mr-3">
                                        <h6 class="mb-0"><?php echo e($user->name); ?></h6>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo e($user->email); ?></td>
                            <td  class="d-flex">
                                <a href="<?php echo e(route('dashboard.users.edit',$user->id)); ?>" class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary">
                                    <i class="ti ti-edit text-xl leading-none"></i>
                                </a>
                                <form action="<?php echo e(route('dashboard.users.destroy',$user->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary" title="<?php echo e(__('Delete')); ?>">
                                        <i class="ti ti-trash text-xl leading-none"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div>
                <?php echo e($users->links()); ?>

            </div>
        </div>
        <?php endif; ?>
    </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\users\index.blade.php ENDPATH**/ ?>