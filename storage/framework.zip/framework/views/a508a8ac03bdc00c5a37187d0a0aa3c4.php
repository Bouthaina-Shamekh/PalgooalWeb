<?php $title = 'نجاح حجز الدومينات'; ?>
<?php if (isset($component)) { $__componentOriginal0785005caee783032a496108c55d26d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0785005caee783032a496108c55d26d5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.template.layouts.index-layouts','data' => ['title' => ''.e($title).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('template.layouts.index-layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($title).'']); ?>
    <section class="max-w-4xl mx-auto px-4 py-12">
        <div
            class="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl shadow p-6 text-center">
            <h1 class="text-2xl font-bold mb-4">تم حجز الدومينات بنجاح</h1>
            <p class="text-sm text-gray-600 dark:text-gray-300 mb-6">تم حفظ طلبك وستتلقى تفاصيل الحجز عبر البريد
                الإلكتروني.</p>
            <div class="mt-6">
                <a href="/" class="px-4 py-2 rounded-xl bg-[#240B36] text-white">العودة للرئيسية</a>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0785005caee783032a496108c55d26d5)): ?>
<?php $attributes = $__attributesOriginal0785005caee783032a496108c55d26d5; ?>
<?php unset($__attributesOriginal0785005caee783032a496108c55d26d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0785005caee783032a496108c55d26d5)): ?>
<?php $component = $__componentOriginal0785005caee783032a496108c55d26d5; ?>
<?php unset($__componentOriginal0785005caee783032a496108c55d26d5); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\front\pages\checkout-domains-success.blade.php ENDPATH**/ ?>