<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>"><?php echo e(t('dashboard.Home', 'Home')); ?></a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.languages.index')); ?>"><?php echo e(t('dashboard.Languages', 'Languages')); ?></a></li>
                <li class="breadcrumb-item" aria-current="page"><?php echo e(t('dashboard.Languages_List', 'Languages List')); ?></li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0"><?php echo e(t('dashboard.Languages_List', 'Languages List')); ?></h2>
            </div>
        </div>
    </div>
    <!-- [ breadcrumb ] end -->
    <!-- [ Main Content ] start -->
    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card table-card">
                <div class="card-header">
                    <div class="sm:flex items-center justify-between">
                        <h5 class="mb-3 sm:mb-0"><?php echo e(t('dashboard.Languages_List', 'Languages List')); ?></h5>
                        <div>
                            <a href="<?php echo e(route('dashboard.languages.create')); ?>" class="btn btn-primary"><?php echo e(t('dashboard.Add_Languages', 'Add Languages')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    
                                    <th>#</th>
                                    <th><?php echo e(t('dashboard.Name', 'Name')); ?></th>
                                    <th><?php echo e(t('dashboard.Native_Name', 'Native Name')); ?></th>
                                    <th><?php echo e(t('dashboard.Code', 'Code')); ?></th>
                                    <th><?php echo e(t('dashboard.Flag', 'Flag')); ?></th>
                                    <th><?php echo e(t('dashboard.RTL', 'RTL')); ?></th>
                                    <th><?php echo e(t('dashboard.Status', 'Status')); ?></th>
                                    <th><?php echo e(t('dashboard.Actiont', 'Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(($langs ->currentPage() - 1) * $langs ->perPage() + $loop->iteration); ?></td>
                                    <td><?php echo e($lang->name); ?></td>
                                    <td><?php echo e($lang->native); ?></td>
                                    <td><?php echo e(strtoupper($lang->code)); ?></td>
                                    <td>
                                        <?php if($lang->flag): ?>
                                            <img src="<?php echo e(asset($lang->flag)); ?>" alt="flag" class="w-6 h-4 inline-block">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch switch-lg">
                                            <input type="checkbox" <?php echo e($lang->is_rtl ? 'checked' : ''); ?> class="form-check-input checked:!bg-success-500 checked:!border-success-500 text-lg" onclick="toggleRtl(<?php echo e($lang->id); ?>, this.checked)" >
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch switch-lg">
                                            <input type="checkbox" <?php echo e($lang->is_active ? 'checked' : ''); ?> class="form-check-input checked:!bg-success-500 checked:!border-success-500 text-lg" onclick="toggleStatus(<?php echo e($lang->id); ?>, this.checked)" >
                                        </div>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('dashboard.translation-values.index', ['locale' => $lang->code])); ?>" class="btn btn-sm btn-info">
                                            <?php echo e(t('dashboard.languages_edit', 'Languages Edit')); ?>

                                        </a>
                                        <a href="<?php echo e(route('dashboard.languages.edit', $lang->id)); ?>" class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary">
                                            <i class="ti ti-edit text-xl leading-none"></i>
                                        </a>
                                        <a href="#" onclick="deleteLanguage(<?php echo e($lang->id); ?>)"  class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary">
                                            <i class="ti ti-trash text-xl leading-none"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="mt-4">
                    <?php echo e($langs->links()); ?>

                </div>
            </div>
        </div>
    </div>

<!-- ✅ SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    function toggleRtl(langId, isChecked) {
        fetch('admin/languages/' + langId + '/toggle-rtl', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: JSON.stringify({
                is_rtl: isChecked ? 1 : 0
            })
        })
        .then(response => response.json())
        .then(data => {
            if(data.success){
                showSuccessToast('✅ RTL updated successfully');
            } else {
                showErrorToast('❌ Error updating RTL');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showErrorToast('❌ Error occurred');
        });
    }

    function toggleStatus(langId, isChecked) {
        fetch('admin/languages/' + langId + '/toggle-status', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: JSON.stringify({
                is_active: isChecked ? 1 : 0
            })
        })
        .then(response => response.json())
        .then(data => {
            if(data.success){
                showSuccessToast('✅ Status updated successfully');
            } else {
                showErrorToast('❌ Error updating Status');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showErrorToast('❌ Error occurred');
        });
    }

    // ✅ Toast functions:
    function showSuccessToast(message) {
        Swal.fire({
            toast: true,
            position: 'top-end',
            icon: 'success',
            title: message,
            showConfirmButton: false,
            timer: 1500,
            timerProgressBar: true
        });
    }

    function showErrorToast(message) {
        Swal.fire({
            toast: true,
            position: 'top-end',
            icon: 'error',
            title: message,
            showConfirmButton: false,
            timer: 2000,
            timerProgressBar: true
        });
    }
</script>
<script>
    function deleteLanguage(langId) {
        if (confirm('Are you sure you want to delete this language?')) {
            fetch('admin/languages/' + langId + '/delete', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            })
            .then(response => response.json())
            .then(data => {
                console.log(data);
                if(data.success){
                    showSuccessToast('✅ Language deleted successfully');
                    // Optionally, reload the page:
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                } else {
                    showErrorToast('❌ Error deleting language');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showErrorToast('❌ Error occurred');
            });
        }
    }
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>    <?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/dashboard/lang/index.blade.php ENDPATH**/ ?>