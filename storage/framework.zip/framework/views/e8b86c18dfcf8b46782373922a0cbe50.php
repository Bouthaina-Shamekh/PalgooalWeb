<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">الرئيسية</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.domain_providers.index')); ?>">مزودو الدومينات</a></li>
                <li class="breadcrumb-item" aria-current="page">تعديل مزود</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">تعديل مزود دومين</h2>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="bg-white shadow-sm rounded-lg overflow-visible p-6">
                <form method="POST" action="<?php echo e(route('dashboard.domain_providers.update', $domainProvider->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    
                    <div class="mb-4">
                        <label class="form-label">اسم المزود</label>
                        <input type="text" name="name" class="form-control" required
                               value="<?php echo e(old('name', $domainProvider->name)); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-4">
                        <label class="form-label">نوع المزود</label>
                        <select name="type" id="provider-type" class="form-select" required>
                            <option value="">اختر النوع</option>
                            <option value="enom"       <?php if(old('type', $domainProvider->type) === 'enom'): echo 'selected'; endif; ?>>Enom</option>
                            <option value="namecheap"  <?php if(old('type', $domainProvider->type) === 'namecheap'): echo 'selected'; endif; ?>>Namecheap</option>
                            <option value="cloudflare" <?php if(old('type', $domainProvider->type) === 'cloudflare'): echo 'selected'; endif; ?>>Cloudflare</option>
                        </select>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-4">
                        <label class="form-label">رابط الـ API (Endpoint)</label>
                        <select name="endpoint" id="endpoint" class="form-select" required></select>
                        <small class="text-muted">اختر البيئة المناسبة (فعلي/اختباري) للمزوّد.</small>
                        <?php $__errorArgs = ['endpoint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-4">
                        <label class="form-label">وضع الاتصال</label>
                        <select name="mode" class="form-select">
                            <option value="live" <?php if(old('mode', $domainProvider->mode) === 'live'): echo 'selected'; endif; ?>>Live (فعلي)</option>
                            <option value="test" <?php if(old('mode', $domainProvider->mode) === 'test'): echo 'selected'; endif; ?>>Test (اختباري)</option>
                        </select>
                        <?php $__errorArgs = ['mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-4">
                        <label class="form-label">الحالة</label>
                        <select name="is_active" class="form-select">
                            <option value="1" <?php if(old('is_active', $domainProvider->is_active) == 1): echo 'selected'; endif; ?>>مفعل</option>
                            <option value="0" <?php if(old('is_active', $domainProvider->is_active) == 0): echo 'selected'; endif; ?>>معطل</option>
                        </select>
                        <?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div id="common-fields">
                        <div class="mb-4">
                            <label class="form-label">اسم المستخدم</label>
                            <input type="text" name="username" class="form-control"
                                   value="<?php echo e(old('username', $domainProvider->username)); ?>">
                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div id="enom-fields" class="hidden">
                        <div class="mb-4">
                            <label class="form-label">كلمة المرور (Enom)</label>
                            <input type="password" name="password" class="form-control" autocomplete="new-password">
                            <small class="text-muted">لن نعرض كلمة المرور الحالية لأسباب أمنية. اتركها فارغة إن لم ترغب في تغييرها.</small>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">API Token (Enom)</label>
                            <input type="text" name="api_token" class="form-control"
                                   value="<?php echo e(old('api_token', $domainProvider->api_token)); ?>">
                            <small class="text-muted">أدخل إما كلمة المرور أو الـ Token.</small>
                            <?php $__errorArgs = ['api_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div id="namecheap-fields" class="hidden">
                        <div class="mb-4">
                            <label class="form-label">API Key (Namecheap)</label>
                            <input type="text" name="api_key" class="form-control"
                                   value="<?php echo e(old('api_key', $domainProvider->api_key)); ?>">
                            <?php $__errorArgs = ['api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Client IP (Namecheap)</label>
                            <input type="text" name="client_ip" class="form-control"
                                   value="<?php echo e(old('client_ip', $domainProvider->client_ip)); ?>"
                                   placeholder="مثال: 5.9.172.153">
                            <small class="text-muted">لازم يكون هذا الـ IP مبيّضًا في لوحة Namecheap.</small>
                            <?php $__errorArgs = ['client_ip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div id="cloudflare-fields" class="hidden">
                        <div class="mb-2">
                            <label class="form-label">API Token (Cloudflare)</label>
                            <input type="text" name="api_token" class="form-control"
                                   value="<?php echo e(old('api_token', $domainProvider->api_token)); ?>">
                            <?php $__errorArgs = ['api_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="flex gap-2 mt-6">
                        <button type="submit" class="btn btn-primary">تحديث</button>
                        <a href="<?php echo e(route('dashboard.domain_providers.index')); ?>" class="btn btn-light">إلغاء</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <script>
        const endpointsByType = {
            enom: [
                { label: 'Enom Live', url: 'https://reseller.enom.com/interface.asp' },
                { label: 'Enom Test', url: 'https://resellertest.enom.com/interface.asp' },
            ],
            namecheap: [
                { label: 'Namecheap Live',    url: 'https://api.namecheap.com/xml.response' },
                { label: 'Namecheap Sandbox', url: 'https://api.sandbox.namecheap.com/xml.response' },
            ],
            cloudflare: [
                { label: 'Cloudflare API', url: 'https://api.cloudflare.com/client/v4' },
            ]
        };

        function $(sel){ return document.querySelector(sel); }
        function show(el){ el.classList.remove('hidden'); }
        function hide(el){ el.classList.add('hidden'); }

        function fillEndpoints(type, current = '') {
            const sel = $('#endpoint');
            sel.innerHTML = '';
            (endpointsByType[type] || []).forEach(e => {
                const opt = document.createElement('option');
                opt.value = e.url;
                opt.textContent = `${e.label} — ${e.url}`;
                if (current && current === e.url) opt.selected = true;
                sel.appendChild(opt);
            });

            // في حال لم يطابق current أي خيار، اختر الأول افتراضياً
            if (!sel.value && sel.options.length) {
                sel.options[0].selected = true;
            }
        }

        function toggleFields(type) {
            const enom = $('#enom-fields');
            const nc   = $('#namecheap-fields');
            const cf   = $('#cloudflare-fields');
            hide(enom); hide(nc); hide(cf);
            if (type === 'enom') show(enom);
            else if (type === 'namecheap') show(nc);
            else if (type === 'cloudflare') show(cf);
        }

        document.addEventListener('DOMContentLoaded', () => {
            const typeSel = $('#provider-type');

            const oldType      = "<?php echo e(old('type', $domainProvider->type)); ?>";
            const currentEP    = "<?php echo e(old('endpoint', $domainProvider->endpoint)); ?>";

            // اضبط النوع الحالي
            if (oldType) typeSel.value = oldType;

            // عبّي قائمة الـ endpoints حسب النوع، مع تحديد الحالي
            fillEndpoints(typeSel.value || 'enom', currentEP);

            // أظهر الحقول المناسبة
            toggleFields(typeSel.value || '');

            // عند تغيير النوع
            typeSel.addEventListener('change', (e) => {
                fillEndpoints(e.target.value);
                toggleFields(e.target.value);
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\domain_providers\edit.blade.php ENDPATH**/ ?>