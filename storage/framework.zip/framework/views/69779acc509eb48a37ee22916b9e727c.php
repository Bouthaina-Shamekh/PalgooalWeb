<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">الرئيسية</a></li>
                <li class="breadcrumb-item" aria-current="page">الاشتراكات</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">قائمة الاشتراكات</h2>
            </div>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="bg-white dark:bg-gray-800 shadow-sm rounded-lg overflow-visible">
                <?php if(session('ok')): ?>
                    <div class="alert alert-success mb-4"><?php echo e(session('ok')); ?></div>
                <?php endif; ?>
                <?php if(session('connection_result')): ?>
                    <div class="alert alert-info mb-4"><?php echo session('connection_result'); ?></div>
                <?php endif; ?>
                <div class="px-4 py-4 border-b border-gray-100 dark:border-gray-700">
                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                        <div class="flex items-center gap-3">
                            <h5 class="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-0">قائمة الاشتراكات
                            </h5>
                            <span class="text-sm text-gray-500">إجمالي:
                                <?php echo e($subscriptions->total() ?? $subscriptions->count()); ?></span>
                        </div>
                        <div class="flex items-center gap-2">
                            <form method="GET" class="flex items-center gap-2">
                                <input type="search" name="q" value="<?php echo e(request('q')); ?>"
                                    class="block w-56 rounded-md border border-gray-200 dark:border-gray-700 px-3 py-2 text-sm bg-white dark:bg-gray-900 text-gray-700 dark:text-gray-200"
                                    placeholder="بحث بالعميل أو الدومين..." />
                                <input type="search" name="domain" value="<?php echo e(request('domain')); ?>"
                                    class="block w-48 rounded-md border border-gray-200 dark:border-gray-700 px-3 py-2 text-sm bg-white dark:bg-gray-900 text-gray-700 dark:text-gray-200"
                                    placeholder="فلتر بالدومين (مثال: example.com)" />
                                <select name="status"
                                    class="rounded-md border border-gray-200 dark:border-gray-700 px-2 py-2 text-sm bg-white dark:bg-gray-900 text-gray-700 dark:text-gray-200">
                                    <option value="">الكل</option>
                                    <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>نشط
                                    </option>
                                    <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>معلق
                                    </option>
                                    <option value="suspended" <?php echo e(request('status') == 'suspended' ? 'selected' : ''); ?>>
                                        موقوف</option>
                                    <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>
                                        ملغي</option>
                                </select>
                                <select name="sort"
                                    class="rounded-md border border-gray-200 px-2 py-2 text-sm bg-white">
                                    <option value="">ترتيب</option>
                                    <option value="domain_name"
                                        <?php echo e(request('sort') == 'domain_name' ? 'selected' : ''); ?>>الدومين</option>
                                    <option value="starts_at" <?php echo e(request('sort') == 'starts_at' ? 'selected' : ''); ?>>
                                        تاريخ البدء</option>
                                </select>
                                <select name="direction"
                                    class="rounded-md border border-gray-200 px-2 py-2 text-sm bg-white">
                                    <option value="asc" <?php echo e(request('direction') == 'asc' ? 'selected' : ''); ?>>تصاعدي
                                    </option>
                                    <option value="desc" <?php echo e(request('direction') == 'desc' ? 'selected' : ''); ?>>
                                        تنازلي</option>
                                </select>
                                <button type="submit"
                                    class="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-700 hover:bg-gray-50">بحث</button>
                            </form>
                            <a href="<?php echo e(route('dashboard.subscriptions.create')); ?>"
                                class="inline-flex items-center px-3 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700">
                                <svg class="w-4 h-4 ml-2" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M12 5v14M5 12h14"></path>
                                </svg>
                                <span>إضافة اشتراك جديد</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="p-4">
                    <div class="flex items-center justify-between mb-3">
                        <form id="bulk_form" method="POST" action="<?php echo e(route('dashboard.subscriptions.bulk')); ?>"
                            class="flex items-center gap-3">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="ids[]" id="bulk_ids" />
                            <div
                                class="flex items-center gap-2 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-md px-3 py-2 shadow-sm">
                                <label for="bulk_action" class="sr-only">إجراء جماعي</label>
                                <select name="action" id="bulk_action"
                                    class="rounded-md border-none px-2 py-1 text-sm bg-transparent">
                                    <option value="">اختر إجراء جماعي</option>
                                    <option value="suspend">تعليق</option>
                                    <option value="unsuspend">إلغاء التعليق</option>
                                    <option value="sync">مزامنة</option>
                                    <option value="terminate">حذف نهائي</option>
                                    <option value="delete">حذف</option>
                                </select>
                                <button type="button" id="bulk_apply"
                                    class="inline-flex items-center px-3 py-2 bg-blue-500 text-white rounded-md text-sm hover:bg-blue-700 ">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                        stroke-width="2">
                                        <path d="M5 12h14M12 5l7 7-7 7"></path>
                                    </svg>
                                    تطبيق
                                </button>
                            </div>
                        </form>
                        <div></div>
                    </div>
                    <div class="overflow-x-auto">
                        
                        <div id="global-flash" class="px-4 mb-3">
                            <?php if(session('success')): ?>
                                <div class="alert alert-success mb-2"><?php echo e(session('success')); ?></div>
                            <?php endif; ?>
                            <?php if(session('error')): ?>
                                <div class="alert alert-danger mb-2"><?php echo e(session('error')); ?></div>
                            <?php endif; ?>
                            <?php if(session('warning')): ?>
                                <div class="alert alert-warning mb-2"><?php echo e(session('warning')); ?></div>
                            <?php endif; ?>
                            <?php if(session('info')): ?>
                                <div class="alert alert-info mb-2"><?php echo e(session('info')); ?></div>
                            <?php endif; ?>
                        </div>
                        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                            <thead class="bg-gray-50 dark:bg-gray-900">
                                <tr>
                                    <th scope="col"
                                        class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <input type="checkbox" id="select_all" />
                                    </th>
                                    <th scope="col"
                                        class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        العميل</th>
                                    <th scope="col"
                                        class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        الخطة</th>
                                    <th scope="col"
                                        class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        حزمة السيرفر</th>
                                    <th scope="col"
                                        class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        الدومين</th>
                                    <th scope="col"
                                        class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        الحالة</th>
                                    <th scope="col"
                                        class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        خيارات</th>
                                    <th scope="col"
                                        class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        نتيجة المزامنة</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-100 dark:divide-gray-700">
                                <?php $__empty_1 = true; $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr data-subscription-row="<?php echo e($sub->id); ?>"
                                        class="hover:bg-gray-50 dark:hover:bg-gray-900">
                                        <td class="px-4 py-2 text-sm text-gray-700 dark:text-gray-200">
                                            <input type="checkbox" class="row_checkbox" name="ids[]"
                                                value="<?php echo e($sub->id); ?>" />
                                        </td>

                                        <td class="px-4 py-2 text-sm text-gray-700 dark:text-gray-200">
                                            <?php echo e($sub->client->first_name ?? ''); ?> <?php echo e($sub->client->last_name ?? ''); ?>

                                        </td>
                                        <td class="px-4 py-2 text-sm text-gray-700 dark:text-gray-200">
                                            <?php echo e($sub->plan->name ?? ''); ?></td>
                                        <td class="px-4 py-2 text-sm text-gray-700 dark:text-gray-200">
                                            <?php echo e($sub->server_package ?? ($sub->plan->server_package ?? ($sub->plan->name ?? '-'))); ?>

                                        </td>
                                        <td class="px-4 py-2 text-sm text-gray-700 dark:text-gray-200">
                                            <?php if($sub->domain_name): ?>
                                                <div class="flex items-center gap-2">
                                                    <?php
                                                        $link = \Illuminate\Support\Str::startsWith($sub->domain_name, [
                                                            'http://',
                                                            'https://',
                                                        ])
                                                            ? $sub->domain_name
                                                            : 'http://' . $sub->domain_name;
                                                    ?>
                                                    <a href="<?php echo e($link); ?>" target="_blank" rel="noopener"
                                                        class="text-blue-600 hover:underline"><?php echo e($sub->domain_name); ?></a>
                                                    <button type="button" data-copy-domain="<?php echo e($sub->domain_name); ?>"
                                                        class="text-sm text-gray-500 hover:text-gray-800">نسخ</button>
                                                </div>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>

                                        <td class="px-4 py-2">
                                            <?php if($sub->status == 'active'): ?>
                                                <span
                                                    class="sub-status-badge inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">نشط</span>
                                            <?php elseif($sub->status == 'pending'): ?>
                                                <span
                                                    class="sub-status-badge inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">معلق</span>
                                            <?php elseif($sub->status == 'suspended'): ?>
                                                <span
                                                    class="sub-status-badge inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">موقوف</span>
                                            <?php elseif($sub->status == 'cancelled'): ?>
                                                <span
                                                    class="sub-status-badge inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">ملغي</span>
                                            <?php else: ?>
                                                <span
                                                    class="sub-status-badge inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"><?php echo e(__($sub->status)); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td
                                            class="px-4 py-2 text-sm text-gray-700 dark:text-gray-200 whitespace-nowrap">
                                            
                                            <div class="inline-flex items-center gap-2 mr-2">
                                                
                                                <a href="<?php echo e(route('dashboard.subscriptions.cpanel-login', $sub)); ?>"
                                                    target="_blank" rel="noopener" title="دخول cPanel"
                                                    class="w-8 h-8 inline-flex items-center justify-center rounded-md bg-white border border-gray-200 hover:bg-gray-50 text-gray-600">
                                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none"
                                                        stroke="currentColor" stroke-width="2">
                                                        <path
                                                            d="M12 2v4M12 18v4M4 12h4M16 12h4M5 5l4 4M15 15l4 4M5 19l4-4M15 9l4-4">
                                                        </path>
                                                    </svg>
                                                </a>
                                                
                                                <form action="<?php echo e(route('dashboard.subscriptions.sync', $sub)); ?>"
                                                    method="POST" class="ajax-action">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" title="مزامنة"
                                                        class="w-8 h-8 inline-flex items-center justify-center rounded-md bg-white border border-gray-200 hover:bg-gray-50 text-gray-600">
                                                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none"
                                                            stroke="currentColor" stroke-width="2">
                                                            <path d="M21 12a9 9 0 1 0-3.2 6.6L21 12z"></path>
                                                            <path d="M21 3v6h-6"></path>
                                                        </svg>
                                                    </button>
                                                </form>
                                                
                                                <?php if($sub->status == 'active'): ?>
                                                    <form
                                                        action="<?php echo e(route('dashboard.subscriptions.suspend', $sub)); ?>"
                                                        method="POST" class="ajax-action">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" title="تعليق"
                                                            class="w-8 h-8 inline-flex items-center justify-center rounded-md bg-white border border-gray-200 hover:bg-gray-50 text-gray-600">
                                                            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none"
                                                                stroke="currentColor" stroke-width="2">
                                                                <path d="M10 6h4v12h-4z"></path>
                                                            </svg>
                                                        </button>
                                                    </form>
                                                <?php elseif($sub->status == 'suspended'): ?>
                                                    <form
                                                        action="<?php echo e(route('dashboard.subscriptions.unsuspend', $sub)); ?>"
                                                        method="POST" class="ajax-action">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" title="إلغاء التعليق"
                                                            class="w-8 h-8 inline-flex items-center justify-center rounded-md bg-white border border-gray-200 hover:bg-gray-50 text-gray-600">
                                                            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none"
                                                                stroke="currentColor" stroke-width="2">
                                                                <path d="M6 4h4v16H6zM14 4h4v16h-4z"></path>
                                                            </svg>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                
                                                <form action="<?php echo e(route('dashboard.subscriptions.terminate', $sub)); ?>"
                                                    method="POST" class="ajax-action ajax-destructive"
                                                    onsubmit="return confirm('سيتم حذف الموقع من السيرفر نهائيًا. هل أنت متأكد؟')">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" title="حذف نهائي"
                                                        class="w-8 h-8 inline-flex items-center justify-center rounded-md bg-white border border-gray-200 hover:bg-gray-50 text-red-600">
                                                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none"
                                                            stroke="currentColor" stroke-width="2">
                                                            <path d="M3 6h18M8 6v12a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V6">
                                                            </path>
                                                            <path d="M10 11v6M14 11v6"></path>
                                                        </svg>
                                                    </button>
                                                </form>
                                            </div>
                                            <div class="relative inline-block">
                                                <a class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary dropdown-toggle arrow-none"
                                                    href="#" data-pc-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                    <span class="sr-only">خيارات</span>
                                                    <i class="ti ti-dots-vertical text-lg leading-none"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end hidden origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white dark:bg-gray-900 ring-1 ring-black ring-opacity-5 p-2 z-50"
                                                    data-pc-dropdown role="menu" aria-hidden="true">
                                                    <a href="<?php echo e(route('dashboard.subscriptions.edit', $sub)); ?>"
                                                        role="menuitem"
                                                        class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-50 dark:hover:bg-gray-800 text-sm text-gray-700">
                                                        <svg class="w-4 h-4 text-gray-500" viewBox="0 0 24 24"
                                                            fill="none" stroke="currentColor" stroke-width="2">
                                                            <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z">
                                                            </path>
                                                        </svg>
                                                        تعديل
                                                    </a>
                                                    <form
                                                        action="<?php echo e(route('dashboard.subscriptions.destroy', $sub)); ?>"
                                                        method="POST"
                                                        onsubmit="return confirm('هل أنت متأكد من الحذف؟')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" role="menuitem"
                                                            class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-50 dark:hover:bg-gray-800 text-sm text-gray-700">
                                                            <svg class="w-4 h-4 text-gray-500" viewBox="0 0 24 24"
                                                                fill="none" stroke="currentColor"
                                                                stroke-width="2">
                                                                <path
                                                                    d="M3 6h18M8 6v12a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V6M10 6V4a2 2 0 0 1 2-2h0a2 2 0 0 1 2 2v2">
                                                                </path>
                                                            </svg>
                                                            حذف
                                                        </button>
                                                    </form>
                                                    <?php if($sub->status == 'active'): ?>
                                                        <form
                                                            action="<?php echo e(route('dashboard.subscriptions.suspend', $sub)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" role="menuitem"
                                                                class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-50 dark:hover:bg-gray-800 text-sm text-gray-700">
                                                                <svg class="w-4 h-4 text-gray-500" viewBox="0 0 24 24"
                                                                    fill="none" stroke="currentColor"
                                                                    stroke-width="2">
                                                                    <path d="M10 6h4v12h-4z"></path>
                                                                </svg>
                                                                تعليق
                                                            </button>
                                                        </form>
                                                    <?php elseif($sub->status == 'suspended'): ?>
                                                        <form
                                                            action="<?php echo e(route('dashboard.subscriptions.unsuspend', $sub)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" role="menuitem"
                                                                class="w-full text-left px-3 py-2 rounded hover:bg-gray-50 dark:hover:bg-gray-800 text-sm">
                                                                <svg class="w-4 h-4 text-gray-500 inline-block ml-2"
                                                                    viewBox="0 0 24 24" fill="none"
                                                                    stroke="currentColor" stroke-width="2">
                                                                    <path
                                                                        d="M21 12v.01M3 12v.01M6.2 6.2l.01.01M17.8 17.8l.01.01M6.2 17.8l.01.01M17.8 6.2l.01.01">
                                                                    </path>
                                                                </svg>
                                                                إلغاء التعليق
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                    <form
                                                        action="<?php echo e(route('dashboard.subscriptions.provision', $sub)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" role="menuitem"
                                                            class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-50 dark:hover:bg-gray-800 text-sm text-gray-700">
                                                            <svg class="w-4 h-4 text-gray-500" viewBox="0 0 24 24"
                                                                fill="none" stroke="currentColor"
                                                                stroke-width="2">
                                                                <path d="M12 6v6l4 2"></path>
                                                                <path
                                                                    d="M21 12a9 9 0 1 0-9 9 9 9 0 0 0 9-9Z">
                                                                </path>
                                                            </svg>
                                                            إعادة التفعيل
                                                        </button>
                                                    </form>
                                                    <form action="<?php echo e(route('dashboard.subscriptions.sync', $sub)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" role="menuitem"
                                                            class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-50 dark:hover:bg-gray-800 text-sm text-gray-700">
                                                            <svg class="w-4 h-4 text-gray-500" viewBox="0 0 24 24"
                                                                fill="none" stroke="currentColor"
                                                                stroke-width="2">
                                                                <path d="M21 12a9 9 0 1 0-3.2 6.6L21 12z"></path>
                                                                <path d="M21 3v6h-6"></path>
                                                            </svg>
                                                            مزامنة
                                                        </button>
                                                    </form>
                                                    <form
                                                        action="<?php echo e(route('dashboard.subscriptions.terminate', $sub)); ?>"
                                                        method="POST"
                                                        onsubmit="return confirm('سيتم حذف الموقع من السيرفر نهائيًا. هل أنت متأكد؟')">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" role="menuitem"
                                                            class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-50 dark:hover:bg-gray-800 text-sm text-red-600">
                                                            <svg class="w-4 h-4 text-red-600" viewBox="0 0 24 24"
                                                                fill="none" stroke="currentColor"
                                                                stroke-width="2">
                                                                <path
                                                                    d="M3 6h18M8 6v12a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V6">
                                                                </path>
                                                                <path d="M10 11v6M14 11v6"></path>
                                                            </svg>
                                                            حذف نهائي
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-4 py-2 text-sm text-gray-700 dark:text-gray-200">
                                            <?php
                                                $syncStatus = $sub->last_sync_status ?? null; // possible values: success, failed, pending
                                                $syncAt = $sub->last_synced_at ?? null;
                                            ?>
                                            <?php if($syncStatus == 'success'): ?>
                                                <span
                                                    class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">نجحت</span>
                                            <?php elseif($syncStatus == 'failed'): ?>
                                                <span
                                                    class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">فشل</span>
                                            <?php elseif($syncStatus == 'pending'): ?>
                                                <span
                                                    class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">قيد
                                                    التنفيذ</span>
                                            <?php else: ?>
                                                <span
                                                    class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">غير
                                                    معروف</span>
                                            <?php endif; ?>
                                            <?php if($syncAt): ?>
                                                <div class="text-xs text-gray-400 mt-1">
                                                    <?php echo e(\Illuminate\Support\Carbon::parse($syncAt)->diffForHumans()); ?>

                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-6">لا توجد اشتراكات
                                            لعرضها.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-4">
                        <?php echo e($subscriptions->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<script>
    // showToast is global so other scripts can call it
    function showToast(msg, ok = true) {
        var el = document.createElement('div');
        el.textContent = msg;
        el.style.position = 'fixed';
        el.style.right = '20px';
        el.style.bottom = '20px';
        el.style.padding = '10px 14px';
        el.style.background = ok ? '#16a34a' : '#dc2626';
        el.style.color = 'white';
        el.style.borderRadius = '6px';
        el.style.zIndex = 9999;
        document.body.appendChild(el);
        setTimeout(function() {
            document.body.removeChild(el);
        }, 3500);
    }

    // Trigger toasts for server-side session flashes
    (function triggerSessionToasts() {
        <?php if(session('success')): ?>
            showToast(<?php echo json_encode(session('success'), 15, 512) ?>, true);
        <?php endif; ?>
        <?php if(session('error')): ?>
            showToast(<?php echo json_encode(session('error'), 15, 512) ?>, false);
        <?php endif; ?>
        <?php if(session('warning')): ?>
            showToast(<?php echo json_encode(session('warning'), 15, 512) ?>, false);
        <?php endif; ?>
        <?php if(session('info')): ?>
            showToast(<?php echo json_encode(session('info'), 15, 512) ?>, true);
        <?php endif; ?>
    })();

    document.addEventListener('click', function(e) {
        // close other open dropdowns when clicking outside
        // AJAX handler for subscription quick-action forms
        (function() {
            // reuse global showToast

            document.addEventListener('submit', function(e) {
                var form = e.target;
                if (!form.classList || !form.classList.contains('ajax-action')) return;
                e.preventDefault();
                var url = form.action;
                var method = (form.method || 'POST').toUpperCase();
                var data = new FormData(form);
                var headers = {
                    'X-Requested-With': 'XMLHttpRequest'
                };
                var tokenMeta = document.querySelector('meta[name="csrf-token"]');
                if (tokenMeta) headers['X-CSRF-TOKEN'] = tokenMeta.getAttribute('content');

                fetch(url, {
                        method: method,
                        headers: headers,
                        body: data,
                        credentials: 'same-origin'
                    })
                    .then(function(res) {
                        return res.json().catch(function() {
                            return {
                                ok: res.ok
                            };
                        });
                    })
                    .then(function(json) {
                        if (json && json.error) {
                            showToast(json.error, false);
                            return;
                        }
                        if (json && json.message) showToast(json.message, true);

                        // If action returned updated subscription status, update badge
                        if (json && json.subscription && json.subscription.id) {
                            var id = json.subscription.id;
                            var row = document.querySelector('[data-subscription-row="' + id +
                                '"]');
                            if (row) {
                                var badge = row.querySelector('.sub-status-badge');
                                if (badge) {
                                    badge.textContent = json.subscription.status || badge
                                        .textContent;
                                    // set simple color mapping
                                    badge.className =
                                        'sub-status-badge inline-flex items-center gap-2 px-2 py-1 rounded text-xs ' +
                                        (json.subscription.status == 'active' ?
                                            'bg-green-100 text-green-700' : (json.subscription
                                                .status == 'suspended' ?
                                                'bg-yellow-100 text-yellow-700' :
                                                'bg-gray-100 text-gray-700'));
                                }
                            }
                        }

                        // If form was destructive terminate, remove row
                        if (form.classList.contains('ajax-destructive')) {
                            var tr = form.closest('tr');
                            if (tr) tr.parentNode.removeChild(tr);
                        }
                    }).catch(function(err) {
                        console.error(err);
                        showToast('حدث خطأ، حاول مرة أخرى', false);
                    });
            });
        })();

        document.querySelectorAll('[data-pc-dropdown]').forEach(function(el) {
            if (!el.contains(e.target) && !el.previousElementSibling?.contains(e.target)) {
                el.classList.add('hidden');
            }
        });
    });
    document.querySelectorAll('[data-pc-toggle="dropdown"]').forEach(function(btn) {
        btn.addEventListener('click', function(ev) {
            ev.preventDefault();
            ev.stopPropagation();
            const menu = btn.parentElement.querySelector('[data-pc-dropdown]');
            if (menu) {
                const isHidden = menu.classList.contains('hidden');
                // close others
                document.querySelectorAll('[data-pc-dropdown]').forEach(function(el) {
                    el.classList.add('hidden');
                    el.setAttribute('aria-hidden', 'true');
                    const tb = el.parentElement.querySelector('[data-pc-toggle="dropdown"]');
                    if (tb) tb.setAttribute('aria-expanded', 'false');
                });
                if (isHidden) {
                    menu.classList.remove('hidden');
                    menu.setAttribute('aria-hidden', 'false');
                    btn.setAttribute('aria-expanded', 'true');
                    // focus first actionable element
                    const first = menu.querySelector('[role="menuitem"]');
                    if (first) first.focus();
                } else {
                    menu.classList.add('hidden');
                    menu.setAttribute('aria-hidden', 'true');
                    btn.setAttribute('aria-expanded', 'false');
                }
            }
        });
    });

    // close on escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('[data-pc-dropdown]').forEach(function(el) {
                el.classList.add('hidden');
                el.setAttribute('aria-hidden', 'true');
                const tb = el.parentElement.querySelector('[data-pc-toggle="dropdown"]');
                if (tb) tb.setAttribute('aria-expanded', 'false');
            });
        }
    });

    // select all
    const selectAll = document.getElementById('select_all');
    if (selectAll) {
        selectAll.addEventListener('change', function() {
            document.querySelectorAll('.row_checkbox').forEach(cb => cb.checked = selectAll.checked);
        });
    }

    // copy domain buttons
    document.querySelectorAll('[data-copy-domain]').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const val = btn.getAttribute('data-copy-domain');
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(val);
            } else {
                const ta = document.createElement('textarea');
                ta.value = val;
                document.body.appendChild(ta);
                ta.select();
                document.execCommand('copy');
                ta.remove();
            }
            btn.innerText = 'تم النسخ';
            setTimeout(() => btn.innerText = 'نسخ', 1500);
        });
    });

    // bulk apply
    const bulkApply = document.getElementById('bulk_apply');
    if (bulkApply) {
        bulkApply.addEventListener('click', function() {
            const action = document.getElementById('bulk_action').value;
            if (!action) {
                alert('اختر إجراءً أولاً');
                return;
            }
            const checked = Array.from(document.querySelectorAll('.row_checkbox:checked')).map(cb => cb.value);
            if (checked.length === 0) {
                alert('اختر اشتراك واحد على الأقل');
                return;
            }
            // create hidden inputs
            const form = document.getElementById('bulk_form');
            // remove any previous inputs
            form.querySelectorAll('input[name="ids[]"]').forEach(i => i.remove());
            checked.forEach(id => {
                const inp = document.createElement('input');
                inp.type = 'hidden';
                inp.name = 'ids[]';
                inp.value = id;
                form.appendChild(inp);
            });
            if (confirm('سيتم تنفيذ الإجراء على ' + checked.length + ' اشتراكاً. متابعة؟')) {
                form.submit();
            }
        });
    }
</script>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\subscriptions\index.blade.php ENDPATH**/ ?>