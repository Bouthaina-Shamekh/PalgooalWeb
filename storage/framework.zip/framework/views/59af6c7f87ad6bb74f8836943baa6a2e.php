<?php
    $seoMeta = $seo ?? null;
?>
<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(current_dir()); ?>">

<head>
    <?php if (isset($component)) { $__componentOriginal5d0a24dd43287eafaf3e24ec153646b3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d0a24dd43287eafaf3e24ec153646b3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.seo.meta','data' => ['meta' => $seoMeta]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('seo.meta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['meta' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seoMeta)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d0a24dd43287eafaf3e24ec153646b3)): ?>
<?php $attributes = $__attributesOriginal5d0a24dd43287eafaf3e24ec153646b3; ?>
<?php unset($__attributesOriginal5d0a24dd43287eafaf3e24ec153646b3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d0a24dd43287eafaf3e24ec153646b3)): ?>
<?php $component = $__componentOriginal5d0a24dd43287eafaf3e24ec153646b3; ?>
<?php unset($__componentOriginal5d0a24dd43287eafaf3e24ec153646b3); ?>
<?php endif; ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Favicons -->
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon">

    <!-- Fonts and Styles -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Almarai:wght@300;400;700;800&family=Cairo:wght@200..1000&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(mix('assets/tamplate/css/app.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

    <?php echo $__env->yieldPushContent('meta'); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body x-data="languageSwitcher()" class="font-Cairo scroll-smooth">
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/tamplate/layouts/head.blade.php ENDPATH**/ ?>