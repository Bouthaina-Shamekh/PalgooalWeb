<?php if (isset($component)) { $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $attributes; } ?>
<?php $component = App\View\Components\ClientLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ClientLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        $statusStyles = [
            'active' => 'bg-success-500/10 text-success-600',
            'pending' => 'bg-warning-500/10 text-warning-600',
            'expired' => 'bg-danger-500/10 text-danger-600',
        ];
    ?>

    <div class="page-header">
        <div class="page-block">
            <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('client.home')); ?>"><?php echo e(t('frontend.client_nav.home', 'Home')); ?></a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <?php echo e(t('frontend.client_domains.index.title', 'My Domains')); ?>

                        </li>
                    </ul>
                    <div class="page-header-title">
                        <h2 class="mb-1"><?php echo e(t('frontend.client_domains.index.title', 'My Domains')); ?></h2>
                        <p class="mb-0 text-sm text-muted">
                            <?php echo e(t('frontend.client_domains.index.subtitle', 'Review your registered domains, renewal dates, and current status.')); ?>

                        </p>
                    </div>
                </div>
                <div class="flex flex-wrap items-center gap-2">
                    <a href="<?php echo e(route('client.domains.search')); ?>" class="btn btn-primary">
                        <i class="ti ti-search me-1"></i>
                        <?php echo e(t('frontend.client_domains.index.search_cta', 'Search New Domain')); ?>

                    </a>
                </div>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="grid grid-cols-12 gap-x-6 gap-y-6">
        <div class="col-span-12 md:col-span-6 xl:col-span-3">
            <div class="card">
                <div class="card-body">
                    <p class="text-sm text-gray-500 mb-2"><?php echo e(t('frontend.client_domains.index.total_domains', 'Total Domains')); ?></p>
                    <div class="flex items-center justify-between">
                        <h3 class="mb-0"><?php echo e($domainStats['total'] ?? 0); ?></h3>
                        <span class="w-10 h-10 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center">
                            <i class="ti ti-world text-lg leading-none"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-span-12 md:col-span-6 xl:col-span-3">
            <div class="card">
                <div class="card-body">
                    <p class="text-sm text-gray-500 mb-2"><?php echo e(t('frontend.client_domains.index.active_domains', 'Active Domains')); ?></p>
                    <div class="flex items-center justify-between">
                        <h3 class="mb-0"><?php echo e($domainStats['active'] ?? 0); ?></h3>
                        <span class="w-10 h-10 rounded-full bg-success-500/10 text-success-500 inline-flex items-center justify-center">
                            <i class="ti ti-circle-check text-lg leading-none"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-span-12 md:col-span-6 xl:col-span-3">
            <div class="card">
                <div class="card-body">
                    <p class="text-sm text-gray-500 mb-2"><?php echo e(t('frontend.client_domains.index.pending_domains', 'Pending Domains')); ?></p>
                    <div class="flex items-center justify-between">
                        <h3 class="mb-0"><?php echo e($domainStats['pending'] ?? 0); ?></h3>
                        <span class="w-10 h-10 rounded-full bg-warning-500/10 text-warning-500 inline-flex items-center justify-center">
                            <i class="ti ti-loader-2 text-lg leading-none"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-span-12 md:col-span-6 xl:col-span-3">
            <div class="card">
                <div class="card-body">
                    <p class="text-sm text-gray-500 mb-2"><?php echo e(t('frontend.client_domains.index.expired_domains', 'Expired Domains')); ?></p>
                    <div class="flex items-center justify-between">
                        <h3 class="mb-0"><?php echo e($domainStats['expired'] ?? 0); ?></h3>
                        <span class="w-10 h-10 rounded-full bg-danger-500/10 text-danger-500 inline-flex items-center justify-center">
                            <i class="ti ti-alert-circle text-lg leading-none"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-span-12">
            <div class="card table-card">
                <div class="card-header">
                    <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                        <div>
                            <h5 class="mb-1"><?php echo e(t('frontend.client_domains.index.portfolio_title', 'Domain Portfolio')); ?></h5>
                            <p class="mb-0 text-sm text-muted">
                                <?php echo e(t('frontend.client_domains.index.portfolio_subtitle', 'All domains associated with your account are listed below.')); ?>

                            </p>
                        </div>
                        <span class="badge bg-light-primary text-primary px-3 py-2">
                            <?php echo e($domains->total()); ?> <?php echo e(t('frontend.client_domains.index.records_label', 'records')); ?>

                        </span>
                    </div>
                </div>
                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th><?php echo e(t('frontend.client_domains.index.domain_name', 'Domain Name')); ?></th>
                                    <th><?php echo e(t('frontend.client_domains.index.registration_date', 'Registered At')); ?></th>
                                    <th><?php echo e(t('frontend.client_domains.index.renewal_date', 'Renewal Date')); ?></th>
                                    <th><?php echo e(t('frontend.client_domains.index.auto_renew', 'Auto-Renew')); ?></th>
                                    <th><?php echo e(t('frontend.client_domains.index.status', 'Status')); ?></th>
                                    <th><?php echo e(t('frontend.client_domains.index.template', 'Template')); ?></th>
                                    <th class="text-end"><?php echo e(t('frontend.client_domains.index.actions', 'Actions')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $statusKey = strtolower((string) $domain->status);
                                        $statusClass = $statusStyles[$statusKey] ?? 'bg-light-secondary text-secondary';
                                    ?>
                                    <tr>
                                        <td>
                                            <div class="flex flex-col">
                                                <span class="font-semibold text-body"><?php echo e($domain->domain_name); ?></span>
                                                <span class="text-xs text-muted">
                                                    <?php echo e(t('frontend.client_domains.index.domain_id', 'ID')); ?> #<?php echo e($domain->id); ?>

                                                </span>
                                            </div>
                                        </td>
                                        <td><?php echo e($domain->registration_date ? \Illuminate\Support\Carbon::parse($domain->registration_date)->format('Y-m-d') : '-'); ?></td>
                                        <td><?php echo e($domain->renewal_date ? \Illuminate\Support\Carbon::parse($domain->renewal_date)->format('Y-m-d') : '-'); ?></td>
                                        <td>
                                            <div class="flex flex-col gap-2">
                                                <span class="badge <?php echo e($domain->auto_renew ? 'bg-success-500/10 text-success-600' : 'bg-secondary-500/10 text-secondary-600'); ?>">
                                                    <?php echo e($domain->auto_renew ? t('frontend.client_domains.index.auto_renew_on', 'On') : t('frontend.client_domains.index.auto_renew_off', 'Off')); ?>

                                                </span>
                                                <form action="<?php echo e(route('client.domains.auto-renew', $domain->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <button type="submit" class="btn btn-sm <?php echo e($domain->auto_renew ? 'btn-light-danger' : 'btn-light-success'); ?>">
                                                        <?php echo e($domain->auto_renew ? t('frontend.client_domains.index.disable_auto_renew', 'Disable') : t('frontend.client_domains.index.enable_auto_renew', 'Enable')); ?>

                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge rounded-full px-3 py-2 <?php echo e($statusClass); ?>">
                                                <?php echo e(ucfirst($statusKey ?: 'unknown')); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($domain->template?->name ?: t('frontend.client_domains.index.no_template', 'No template assigned')); ?></td>
                                        <td class="text-end">
                                            <div class="flex flex-wrap justify-end gap-2">
                                                <a href="<?php echo e(route('client.domains.dns.edit', $domain->id)); ?>"
                                                    class="btn btn-sm btn-light-info"
                                                    title="<?php echo e(t('frontend.client_domains.index.change_dns', 'Change DNS')); ?>">
                                                    <i class="ti ti-world me-1 text-base leading-none"></i>
                                                    <?php echo e(t('frontend.client_domains.index.change_dns', 'Change DNS')); ?>

                                                </a>
                                                <form action="<?php echo e(route('client.domains.renew', $domain->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit"
                                                        class="btn btn-sm btn-light-warning"
                                                        title="<?php echo e(t('frontend.client_domains.index.renew', 'Renew')); ?>">
                                                        <i class="ti ti-refresh me-1 text-base leading-none"></i>
                                                        <?php echo e(t('frontend.client_domains.index.renew', 'Renew')); ?>

                                                    </button>
                                                </form>
                                                <a href="<?php echo e(route('client.domains.edit', $domain->id)); ?>"
                                                    class="w-9 h-9 rounded-xl inline-flex items-center justify-center btn-light-primary"
                                                    title="<?php echo e(t('frontend.client_domains.index.edit', 'Edit')); ?>">
                                                    <i class="ti ti-edit text-lg leading-none"></i>
                                                </a>
                                                <form action="<?php echo e(route('client.domains.destroy', $domain->id)); ?>" method="POST"
                                                    onsubmit="return confirm('<?php echo e(t('frontend.client_domains.index.confirm_delete', 'Are you sure you want to delete this domain?')); ?>');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                        class="w-9 h-9 rounded-xl inline-flex items-center justify-center btn-light-danger"
                                                        title="<?php echo e(t('frontend.client_domains.index.delete', 'Delete')); ?>">
                                                        <i class="ti ti-trash text-lg leading-none"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="py-10">
                                            <div class="flex flex-col items-center justify-center text-center">
                                                <span class="w-16 h-16 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center mb-4">
                                                    <i class="ti ti-world text-2xl leading-none"></i>
                                                </span>
                                                <h6 class="mb-2"><?php echo e(t('frontend.client_domains.index.empty_title', 'No domains found yet')); ?></h6>
                                                <p class="mb-4 text-sm text-muted">
                                                    <?php echo e(t('frontend.client_domains.index.empty_subtitle', 'Start by searching for a new domain and add it to your account.')); ?>

                                                </p>
                                                <a href="<?php echo e(route('client.domains.search')); ?>" class="btn btn-primary">
                                                    <?php echo e(t('frontend.client_domains.index.empty_cta', 'Search for a Domain')); ?>

                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php if($domains->hasPages()): ?>
            <div class="col-span-12">
                <div class="flex justify-end">
                    <?php echo e($domains->links()); ?>

                </div>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $attributes = $__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $component = $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\client\domains\index.blade.php ENDPATH**/ ?>