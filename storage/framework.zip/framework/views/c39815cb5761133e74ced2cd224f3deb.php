<?php
    $menuItems = collect();

    if (!empty($footerMenu?->items)) {
        foreach ($footerMenu->items as $item) {
            if (in_array($item->type, ['link', 'page'], true)) {
                $menuItems->push([
                    'label' => (string) $item->label,
                    'url' => (string) $item->url,
                ]);
            }

            if ($item->type === 'dropdown') {
                foreach ($item->processedChildren as $child) {
                    $menuItems->push([
                        'label' => (string) ($child['current_label'] ?? ''),
                        'url' => (string) ($child['current_url'] ?? '#'),
                    ]);
                }
            }
        }
    }

    $menuItems = $menuItems
        ->filter(fn (array $link) => trim((string) ($link['label'] ?? '')) !== '')
        ->values();
?>

<?php if($menuItems->isEmpty()): ?>
    <li><a href="<?php echo e(route('frontend.home')); ?>" class="<?php echo e($linkClass ?? ''); ?>"><?php echo e(t('frontend.Home', 'Home')); ?></a></li>
    <li><a href="<?php echo e(route('domains.page')); ?>" class="<?php echo e($linkClass ?? ''); ?>"><?php echo e(t('frontend.Domain', 'Domains')); ?></a></li>
    <li><a href="<?php echo e(route('cart')); ?>" class="<?php echo e($linkClass ?? ''); ?>"><?php echo e(t('frontend.Cart', 'Cart')); ?></a></li>
    <li><a href="<?php echo e(route('testimonials.submit')); ?>" class="<?php echo e($linkClass ?? ''); ?>"><?php echo e(t('frontend.Contact_Us', 'Contact Us')); ?></a></li>
<?php else: ?>
    <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e($menuItem['url'] ?: '#'); ?>" class="<?php echo e($linkClass ?? ''); ?>">
                <?php echo e($menuItem['label']); ?>

            </a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\front\layouts\partials\footer\menu-links.blade.php ENDPATH**/ ?>