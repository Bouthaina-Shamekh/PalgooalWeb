<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-5xl mx-auto py-8 px-4 sm:px-6 lg:px-8">

        
        <div class="flex items-center justify-between gap-4 mb-6">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 dark:text-gray-100">➕ إضافة قالب جديد</h1>
                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    قم بإضافة قالب جديد مع كل الترجمات، المميزات، الصور، التفاصيل والوسوم.
                </p>
            </div>
        </div>

        
        <?php if($errors->any()): ?>
            <div class="mb-6 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
                <ul class="list-disc ps-5 space-y-1">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('dashboard.templates.store')); ?>" method="POST" enctype="multipart/form-data"
            class="space-y-6 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm p-6 sm:p-8">
            <?php echo csrf_field(); ?>

            
            <div>
                <label class="block font-bold mb-1 text-gray-800 dark:text-gray-100">تصنيف القالب:</label>
                <select name="category_template_id" required
                    class="w-full border border-gray-300 dark:border-gray-600 rounded-lg p-2.5 bg-white dark:bg-gray-900 text-sm focus:ring-primary focus:border-primary">
                    <option value="">اختر التصنيف</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php if(old('category_template_id') == $category->id): echo 'selected'; endif; ?>>
                            <?php echo e($category->translation?->name ?? 'بدون اسم'); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div>
                <label class="block font-bold mb-1 text-gray-800 dark:text-gray-100">خطة الاستضافة المرتبطة:</label>
                <select name="plan_id" required
                    class="w-full border border-gray-300 dark:border-gray-600 rounded-lg p-2.5 bg-white dark:bg-gray-900 text-sm focus:ring-primary focus:border-primary">
                    <option value="">اختر الخطة</option>
                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($plan->id); ?>" <?php if(old('plan_id') == $plan->id): echo 'selected'; endif; ?>>
                            <?php echo e($plan->name); ?> (<?php echo e(number_format($plan->price_cents / 100, 2)); ?> $)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block font-bold mb-1 text-gray-800 dark:text-gray-100">السعر ($):</label>
                    <input type="number" name="price" step="0.01" required value="<?php echo e(old('price')); ?>"
                        class="w-full border border-gray-300 dark:border-gray-600 p-2.5 rounded-lg bg-white dark:bg-gray-900 text-sm focus:ring-primary focus:border-primary" />
                </div>
                <div>
                    <label class="block font-bold mb-1 text-gray-800 dark:text-gray-100">سعر الخصم ($):</label>
                    <input type="number" name="discount_price" step="0.01" value="<?php echo e(old('discount_price')); ?>"
                        class="w-full border border-gray-300 dark:border-gray-600 p-2.5 rounded-lg bg-white dark:bg-gray-900 text-sm focus:ring-primary focus:border-primary" />
                </div>
                <div>
                    <label class="block font-bold mb-1 text-gray-800 dark:text-gray-100">تاريخ انتهاء الخصم:</label>
                    <input type="datetime-local" name="discount_ends_at" value="<?php echo e(old('discount_ends_at')); ?>"
                        class="w-full border border-gray-300 dark:border-gray-600 p-2.5 rounded-lg bg-white dark:bg-gray-900 text-sm focus:ring-primary focus:border-primary" />
                </div>
            </div>

            
            <div>
                <label class="block font-bold mb-1 text-gray-800 dark:text-gray-100">صورة القالب:</label>
                <input type="file" name="image" accept="image/*"
                    class="w-full border border-gray-300 dark:border-gray-600 p-2.5 rounded-lg bg-white dark:bg-gray-900 text-sm focus:ring-primary focus:border-primary"
                    <?php if(!old('image')): ?> required <?php endif; ?> />
                <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                    يُفضّل صورة أفقية بنسبة 16:9 أو 5:3 لعرضها في صفحة التفاصيل.
                </p>
            </div>

            
            <?php
                $firstLocale = $languages->first()->code ?? null;
            ?>

            <div x-data="{ activeLocale: '<?php echo e($firstLocale); ?>' }" class="mt-6">
                <h3 class="text-lg font-bold mb-3 text-gray-900 dark:text-gray-100">الترجمات:</h3>

                
                <div
                    class="inline-flex flex-wrap items-center gap-2 border-b border-gray-200 dark:border-gray-700 pb-2 mb-4">
                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $locale = $language->code; ?>
                        <button type="button" @click="activeLocale = '<?php echo e($locale); ?>'"
                            :class="activeLocale === '<?php echo e($locale); ?>'
                                ?
                                'bg-primary text-white shadow-sm' :
                                'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-200'"
                            class="px-3 py-1.5 rounded-full text-sm font-semibold border border-transparent hover:border-primary/40 transition-colors">
                            <?php echo e($language->name); ?> (<?php echo e($locale); ?>)
                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <div class="space-y-6">
                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $locale = $language->code;
                            $i = $loop->index;
                        ?>

                        <div x-show="activeLocale === '<?php echo e($locale); ?>'" x-cloak
                            class="border border-gray-200 dark:border-gray-700 rounded-xl p-4 sm:p-5 bg-gray-50/60 dark:bg-gray-900"
                            data-locale-section>
                            <div class="flex items-center justify-between gap-2 mb-3">
                                <h4 class="font-bold text-primary text-base sm:text-lg">
                                    [<?php echo e($language->name); ?>] (<?php echo e($locale); ?>)
                                </h4>
                                <span class="text-xs text-gray-500 dark:text-gray-400">
                                    بيانات هذه اللغة فقط.
                                </span>
                            </div>

                            <input type="hidden" name="translations[<?php echo e($i); ?>][locale]"
                                value="<?php echo e($locale); ?>">

                            
                            <div class="mb-3">
                                <label class="block font-semibold mb-1 text-gray-800 dark:text-gray-100">الاسم:</label>
                                <input type="text" name="translations[<?php echo e($i); ?>][name]"
                                    class="name-input w-full border border-gray-300 dark:border-gray-600 p-2.5 rounded-lg bg-white dark:bg-gray-900 text-sm focus:ring-primary focus:border-primary"
                                    required value="<?php echo e(old("translations.$i.name")); ?>" />
                            </div>

                            
                            <div class="mb-3">
                                <label
                                    class="block font-semibold mb-1 flex justify-between items-center text-gray-800 dark:text-gray-100">
                                    <span>الرابط (slug):</span>
                                    <button type="button"
                                        class="generate-slug text-xs sm:text-sm text-blue-600 hover:underline"
                                        title="توليد تلقائي من الاسم">
                                        🔁 توليد تلقائي
                                    </button>
                                </label>
                                <input type="text" name="translations[<?php echo e($i); ?>][slug]"
                                    class="slug-input w-full border border-gray-300 dark:border-gray-600 p-2.5 rounded-lg bg-white dark:bg-gray-900 text-sm focus:ring-primary focus:border-primary"
                                    required value="<?php echo e(old("translations.$i.slug")); ?>" />
                                <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                                    يُستخدم هذا الحقل في الرابط: مثال: <code>my-store-template</code>
                                </p>
                            </div>

                            
                            <div class="mb-3">
                                <label class="block font-semibold mb-1 text-gray-800 dark:text-gray-100">
                                    رابط المعاينة (اختياري):
                                </label>
                                <input type="url" name="translations[<?php echo e($i); ?>][preview_url]"
                                    class="w-full border border-gray-300 dark:border-gray-600 p-2.5 rounded-lg bg-white dark:bg-gray-900 text-sm focus:ring-primary focus:border-primary"
                                    value="<?php echo e(old("translations.$i.preview_url")); ?>" />
                            </div>

                            
                            <div class="mb-4">
                                <label class="block font-semibold mb-1 text-gray-800 dark:text-gray-100">الوصف:</label>
                                <textarea name="translations[<?php echo e($i); ?>][description]" rows="4"
                                    class="w-full border border-gray-300 dark:border-gray-600 p-2.5 rounded-lg bg-white dark:bg-gray-900 text-sm focus:ring-primary focus:border-primary"
                                    required><?php echo e(old("translations.$i.description")); ?></textarea>
                            </div>

                            
                            <div class="mb-6 rounded-xl border border-gray-200 p-4 sm:p-5 bg-white"
                                data-features-wrapper>
                                <div class="flex items-center justify-between flex-wrap gap-3 mb-4">
                                    <h4 class="text-base sm:text-lg font-bold text-gray-800">
                                        المميزات (Features)
                                    </h4>
                                    <div class="flex items-center gap-2">
                                        <button type="button"
                                            class="add-feature inline-flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-white hover:bg-primary/90 shadow">
                                            <svg class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                                <path
                                                    d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" />
                                            </svg>
                                            إضافة ميزة
                                        </button>
                                        <button type="button"
                                            class="clear-features inline-flex items-center gap-2 rounded-lg bg-gray-100 px-3 py-2 text-gray-700 hover:bg-gray-200">
                                            مسح الكل
                                        </button>
                                    </div>
                                </div>
                                <div class="space-y-3" data-features-list>
                                    
                                </div>
                            </div>

                            
                            <div class="mb-6 rounded-xl border border-gray-200 p-4 sm:p-5 bg-white"
                                data-gallery-wrapper>
                                <div class="flex items-center justify-between flex-wrap gap-3 mb-4">
                                    <h4 class="text-base sm:text-lg font-bold text-gray-800">
                                        صور من القالب (Gallery)
                                    </h4>
                                    <div class="flex items-center gap-2">
                                        <button type="button"
                                            class="add-image inline-flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-white hover:bg-primary/90 shadow">
                                            <svg class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                                <path
                                                    d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" />
                                            </svg>
                                            إضافة صورة
                                        </button>
                                        <button type="button"
                                            class="clear-images inline-flex items-center gap-2 rounded-lg bg-gray-100 px-3 py-2 text-gray-700 hover:bg-gray-200">
                                            مسح الكل
                                        </button>
                                    </div>
                                </div>
                                <div class="space-y-3" data-images-list>
                                    
                                </div>
                            </div>

                            
                            <div class="mb-6 rounded-xl border border-gray-200 p-4 sm:p-5 bg-white"
                                data-details-wrapper>
                                <div class="flex items-center justify-between flex-wrap gap-3 mb-4">
                                    <h4 class="text-base sm:text-lg font-bold text-gray-800">
                                        تفاصيل إضافية (Details)
                                    </h4>
                                    <div class="flex items-center gap-2">
                                        <button type="button"
                                            class="add-detail inline-flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-white hover:bg-primary/90 shadow">
                                            إضافة سطر
                                        </button>
                                        <button type="button"
                                            class="clear-details inline-flex items-center gap-2 rounded-lg bg-gray-100 px-3 py-2 text-gray-700 hover:bg-gray-200">
                                            مسح الكل
                                        </button>
                                    </div>
                                </div>
                                <div class="space-y-3" data-details-list>
                                    
                                </div>
                            </div>

                            
                            <div class="mb-6 rounded-xl border border-gray-200 p-4 sm:p-5 bg-white" data-specs-wrapper>
                                <div class="flex items-center justify-between flex-wrap gap-3 mb-4">
                                    <h4 class="text-base sm:text-lg font-bold text-gray-800">
                                        مواصفات القالب (Specs)
                                    </h4>
                                    <div class="flex items-center gap-2">
                                        <button type="button"
                                            class="add-spec inline-flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-white hover:bg-primary/90 shadow">
                                            <svg class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                                <path
                                                    d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" />
                                            </svg>
                                            إضافة سطر
                                        </button>
                                        <button type="button"
                                            class="clear-specs inline-flex items-center gap-2 rounded-lg bg-gray-100 px-3 py-2 text-gray-700 hover:bg-gray-200">
                                            مسح الكل
                                        </button>
                                    </div>
                                </div>
                                <div class="space-y-3" data-specs-list>
                                    
                                </div>
                            </div>

                            
                            <div class="mb-6 rounded-xl border border-gray-200 p-4 sm:p-5 bg-white" data-tags-wrapper>
                                <div class="flex items-center justify-between flex-wrap gap-3 mb-4">
                                    <h4 class="text-base sm:text-lg font-bold text-gray-800">
                                        الوسوم (Tags)
                                    </h4>
                                </div>
                                <div class="flex items-center gap-2 mb-3">
                                    <input type="text"
                                        class="tag-input w-full rounded-md border-gray-300 focus:border-primary focus:ring-primary"
                                        placeholder="اكتب الوسم ثم اضغط إضافة (مثال: متجر)">
                                    <button type="button"
                                        class="add-tag inline-flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-white hover:bg-primary/90 shadow">
                                        إضافة
                                    </button>
                                    <button type="button"
                                        class="clear-tags inline-flex items-center gap-2 rounded-lg bg-gray-100 px-3 py-2 text-gray-700 hover:bg-gray-200">
                                        مسح الكل
                                    </button>
                                </div>
                                <div class="flex flex-wrap gap-2" data-tags-list></div>
                            </div>

                            
                            <input type="hidden" name="translations[<?php echo e($i); ?>][details]"
                                class="details-json" value="">
                            <p class="mt-2 text-xs text-gray-500">
                                يتم حفظ المميزات + المعرض + المواصفات + التفاصيل + الوسوم كـ JSON تلقائيًا.
                            </p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>


            <div class="pt-2">
                <button type="submit"
                    class="inline-flex items-center gap-2 bg-primary hover:bg-primary/90 text-white font-bold py-2.5 px-6 rounded-lg text-sm shadow">
                    💾 حفظ القالب
                </button>
            </div>
        </form>
    </div>

    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sections = document.querySelectorAll('[data-locale-section]');

            sections.forEach(section => {
                const nameInput = section.querySelector('.name-input');
                const slugInput = section.querySelector('.slug-input');
                const generateBtn = section.querySelector('.generate-slug');

                // زر التوليد التلقائي من الاسم
                if (nameInput && slugInput && generateBtn) {
                    generateBtn.addEventListener('click', function() {
                        slugInput.value = generateSlug(nameInput.value);
                    });
                }

                // تعديل مباشر داخل slug => يتم تصحيح النص بإضافة "-"
                if (slugInput) {
                    slugInput.addEventListener('input', function() {
                        this.value = generateSlug(this.value, true); // true = manual typing
                    });
                }
            });

            function generateSlug(input, isManual = false) {
                let slug = (input || '')
                    .toLowerCase()
                    .trim()
                    .replace(/[\s_]+/g, '-')
                    .replace(/[^a-zA-Z0-9\u0600-\u06FF\-]+/g, '')
                    .replace(/\-\-+/g, '-')
                    .replace(/^-+|-+$/g, '');

                return slug;
            }
        });
    </script>

    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('[data-locale-section]').forEach(section => {
                // المميزات
                const listFeatures = section.querySelector('[data-features-list]');
                const addFeature = section.querySelector('.add-feature');
                const clearFeatures = section.querySelector('.clear-features');

                // المعرض
                const listImages = section.querySelector('[data-images-list]');
                const addImage = section.querySelector('.add-image');
                const clearImages = section.querySelector('.clear-images');

                // المواصفات (Specs)
                const listSpecs = section.querySelector('[data-specs-list]');
                const addSpec = section.querySelector('.add-spec');
                const clearSpecs = section.querySelector('.clear-specs');

                // التفاصيل (Details)
                const listDetails = section.querySelector('[data-details-list]');
                const addDetail = section.querySelector('.add-detail');
                const clearDetails = section.querySelector('.clear-details');

                // الوسوم
                const tagsInput = section.querySelector('.tag-input');
                const addTagBtn = section.querySelector('.add-tag');
                const clearTagsBtn = section.querySelector('.clear-tags');
                const tagsList = section.querySelector('[data-tags-list]');

                const detailsInp = section.querySelector('.details-json');

                function escapeHtml(str) {
                    return (str || '')
                        .replace(/&/g, '&amp;')
                        .replace(/</g, '&lt;')
                        .replace(/>/g, '&gt;')
                        .replace(/"/g, '&quot;')
                        .replace(/'/g, '&#039;');
                }

                // Row: Feature
                function featureRow(item = {
                    title: '',
                    icon: ''
                }) {
                    const row = document.createElement('div');
                    row.className =
                        'feature-row grid grid-cols-1 sm:grid-cols-[1fr_160px_auto] gap-2 rounded-lg border border-gray-200 dark:border-gray-700 p-3 bg-white dark:bg-gray-900';
                    row.innerHTML = `
                        <input type="text"
                               class="feat-title w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 p-2 text-sm focus:border-primary focus:ring-primary"
                               placeholder="عنوان الميزة"
                               value="${escapeHtml(item.title)}">
                        <input type="text"
                               class="feat-icon w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 p-2 text-sm focus:border-primary focus:ring-primary"
                               placeholder="🎨 أيقونة (اختياري)"
                               value="${escapeHtml(item.icon || '')}">
                        <button type="button"
                                class="remove-feature inline-flex items-center justify-center rounded-lg bg-red-50 px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-100">
                            حذف
                        </button>`;
                    row.querySelector('.remove-feature').addEventListener('click', () => {
                        row.remove();
                        syncJson();
                    });
                    row.querySelectorAll('input').forEach(inp => inp.addEventListener('input', syncJson));
                    return row;
                }

                // Row: Image
                function imageRow(item = {
                    src: '',
                    alt: ''
                }) {
                    const row = document.createElement('div');
                    row.className =
                        'image-row grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-2 rounded-lg border border-gray-200 dark:border-gray-700 p-3 bg-white dark:bg-gray-900';
                    row.innerHTML = `
                        <input type="text"
                               class="img-src w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 p-2 text-sm focus:border-primary focus:ring-primary"
                               placeholder="رابط الصورة"
                               value="${escapeHtml(item.src)}">
                        <input type="text"
                               class="img-alt w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 p-2 text-sm focus:border-primary focus:ring-primary"
                               placeholder="نص بديل (ALT)"
                               value="${escapeHtml(item.alt || '')}">
                        <button type="button"
                                class="remove-image inline-flex items-center justify-center rounded-lg bg-red-50 px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-100">
                            حذف
                        </button>`;
                    row.querySelector('.remove-image').addEventListener('click', () => {
                        row.remove();
                        syncJson();
                    });
                    row.querySelectorAll('input').forEach(inp => inp.addEventListener('input', syncJson));
                    return row;
                }

                // Row: Spec
                function specRow(item = {
                    name: '',
                    value: ''
                }) {
                    const row = document.createElement('div');
                    row.className =
                        'spec-row grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-2 rounded-lg border border-gray-200 dark:border-gray-700 p-3 bg-white dark:bg-gray-900';
                    row.innerHTML = `
                        <input type="text"
                               class="spec-name w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 p-2 text-sm focus:border-primary focus:ring-primary"
                               placeholder="الاسم"
                               value="${escapeHtml(item.name)}">
                        <input type="text"
                               class="spec-value w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 p-2 text-sm focus:border-primary focus:ring-primary"
                               placeholder="القيمة"
                               value="${escapeHtml(item.value)}">
                        <button type="button"
                                class="remove-spec inline-flex items-center justify-center rounded-lg bg-red-50 px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-100">
                            حذف
                        </button>`;
                    row.querySelector('.remove-spec').addEventListener('click', () => {
                        row.remove();
                        syncJson();
                    });
                    row.querySelectorAll('input').forEach(inp => inp.addEventListener('input', syncJson));
                    return row;
                }

                // Row: Detail
                function detailRow(item = {
                    name: '',
                    value: ''
                }) {
                    const row = document.createElement('div');
                    row.className =
                        'detail-row grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-2 rounded-lg border border-gray-200 dark:border-gray-700 p-3 bg-white dark:bg-gray-900';
                    row.innerHTML = `
                        <input type="text"
                               class="detail-name w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 p-2 text-sm focus:border-primary focus:ring-primary"
                               placeholder="العنصر (مثال: آخر تحديث)"
                               value="${escapeHtml(item.name)}">
                        <input type="text"
                               class="detail-value w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-950 p-2 text-sm focus:border-primary focus:ring-primary"
                               placeholder="القيمة (مثال: يوليو 2025)"
                               value="${escapeHtml(item.value)}">
                        <button type="button"
                                class="remove-detail inline-flex items-center justify-center rounded-lg bg-red-50 px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-100">
                            حذف
                        </button>`;
                    row.querySelector('.remove-detail').addEventListener('click', () => {
                        row.remove();
                        syncJson();
                    });
                    row.querySelectorAll('input').forEach(inp => inp.addEventListener('input', syncJson));
                    return row;
                }

                // Tag chip
                function addTagChip(label) {
                    const text = (label || '').trim();
                    if (!text || !tagsList) return;

                    const exists = Array.from(tagsList.querySelectorAll('[data-tag]'))
                        .some(el => (el.dataset.tag || '').toLowerCase() === text.toLowerCase());
                    if (exists) return;

                    const chip = document.createElement('span');
                    chip.className =
                        'inline-flex items-center gap-1 bg-primary/10 text-primary dark:bg-primary/20 dark:text-primary-200 text-xs font-bold px-3 py-1 rounded-full';
                    chip.setAttribute('data-tag', text);
                    chip.innerHTML = `
                        ${escapeHtml(text)}
                        <button type="button" class="remove-tag ml-1 text-primary hover:text-primary/70">×</button>
                    `;
                    chip.querySelector('.remove-tag').addEventListener('click', () => {
                        chip.remove();
                        syncJson();
                    });
                    tagsList.appendChild(chip);
                    syncJson();
                }

                // Sync JSON
                function syncJson() {
                    const features = Array.from(listFeatures?.querySelectorAll('.feature-row') || [])
                        .map(r => ({
                            title: r.querySelector('.feat-title')?.value.trim() || '',
                            icon: r.querySelector('.feat-icon')?.value.trim() || '',
                        }))
                        .filter(x => x.title.length);

                    const gallery = Array.from(listImages?.querySelectorAll('.image-row') || [])
                        .map(r => ({
                            src: r.querySelector('.img-src')?.value.trim() || '',
                            alt: r.querySelector('.img-alt')?.value.trim() || '',
                        }))
                        .filter(x => x.src.length);

                    const specs = Array.from(listSpecs?.querySelectorAll('.spec-row') || [])
                        .map(r => ({
                            name: r.querySelector('.spec-name')?.value.trim() || '',
                            value: r.querySelector('.spec-value')?.value.trim() || '',
                        }))
                        .filter(x => x.name && x.value);

                    const details = Array.from(listDetails?.querySelectorAll('.detail-row') || [])
                        .map(r => ({
                            name: r.querySelector('.detail-name')?.value.trim() || '',
                            value: r.querySelector('.detail-value')?.value.trim() || '',
                        }))
                        .filter(x => x.name && x.value);

                    const tags = Array.from(tagsList?.querySelectorAll('[data-tag]') || [])
                        .map(el => (el.dataset.tag || '').trim())
                        .filter(Boolean);

                    let payload = {};
                    try {
                        if (detailsInp.value) payload = JSON.parse(detailsInp.value) || {};
                    } catch (e) {
                        payload = {};
                    }

                    payload.features = features;
                    payload.gallery = gallery;
                    payload.specs = specs;
                    payload.details = details;
                    payload.tags = tags;

                    detailsInp.value = JSON.stringify(payload);
                }

                // Init
                (function init() {
                    let existing = {};
                    try {
                        if (detailsInp.value) {
                            existing = JSON.parse(detailsInp.value) || {};
                        } else if (detailsInp.dataset.existing) {
                            existing = JSON.parse(detailsInp.dataset.existing) || {};
                        }
                    } catch (e) {
                        existing = {};
                    }

                    // Features
                    if (listFeatures) {
                        if (Array.isArray(existing.features) && existing.features.length) {
                            existing.features.forEach(f => listFeatures.appendChild(featureRow(f)));
                        } else {
                            listFeatures.appendChild(featureRow());
                        }
                    }

                    // Gallery
                    if (listImages) {
                        if (Array.isArray(existing.gallery) && existing.gallery.length) {
                            existing.gallery.forEach(img => listImages.appendChild(imageRow(img)));
                        } else {
                            listImages.appendChild(imageRow());
                        }
                    }

                    // Specs
                    if (listSpecs) {
                        if (Array.isArray(existing.specs) && existing.specs.length) {
                            existing.specs.forEach(s => listSpecs.appendChild(specRow(s)));
                        } else {
                            listSpecs.appendChild(specRow());
                        }
                    }

                    // Details
                    if (listDetails) {
                        if (Array.isArray(existing.details) && existing.details.length) {
                            existing.details.forEach(d => listDetails.appendChild(detailRow(d)));
                        } else {
                            listDetails.appendChild(detailRow());
                        }
                    }

                    // Tags
                    if (tagsList && Array.isArray(existing.tags) && existing.tags.length) {
                        existing.tags.forEach(t => addTagChip(t));
                    }

                    // Events
                    addFeature?.addEventListener('click', () => {
                        listFeatures.appendChild(featureRow());
                        syncJson();
                    });
                    clearFeatures?.addEventListener('click', () => {
                        listFeatures.innerHTML = '';
                        syncJson();
                    });

                    addImage?.addEventListener('click', () => {
                        listImages.appendChild(imageRow());
                        syncJson();
                    });
                    clearImages?.addEventListener('click', () => {
                        listImages.innerHTML = '';
                        syncJson();
                    });

                    addSpec?.addEventListener('click', () => {
                        listSpecs.appendChild(specRow());
                        syncJson();
                    });
                    clearSpecs?.addEventListener('click', () => {
                        listSpecs.innerHTML = '';
                        syncJson();
                    });

                    addDetail?.addEventListener('click', () => {
                        listDetails.appendChild(detailRow());
                        syncJson();
                    });
                    clearDetails?.addEventListener('click', () => {
                        listDetails.innerHTML = '';
                        syncJson();
                    });

                    addTagBtn?.addEventListener('click', () => {
                        addTagChip(tagsInput.value);
                        tagsInput.value = '';
                        tagsInput.focus();
                    });
                    tagsInput?.addEventListener('keydown', (e) => {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            addTagChip(tagsInput.value);
                            tagsInput.value = '';
                        }
                    });
                    clearTagsBtn?.addEventListener('click', () => {
                        if (tagsList) tagsList.innerHTML = '';
                        syncJson();
                    });

                    syncJson();
                })();
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\templates\create.blade.php ENDPATH**/ ?>