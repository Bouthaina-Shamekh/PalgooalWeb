<?php if (isset($component)) { $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $attributes; } ?>
<?php $component = App\View\Components\ClientLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ClientLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">الرئيسية</a></li>
                <li class="breadcrumb-item" aria-current="page">الاشتراكات</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">قائمة الاشتراكات الخاصة بك</h2>
            </div>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card table-card">
                <?php if(session('ok')): ?>
                    <div class="alert alert-success mb-4"><?php echo e(session('ok')); ?></div>
                <?php endif; ?>
                <?php if(session('connection_result')): ?>
                    <div class="alert alert-info mb-4"><?php echo session('connection_result'); ?></div>
                <?php endif; ?>
                <div class="card-header">
                    <div class="sm:flex items-center justify-between">
                        <h5 class="mb-3 sm:mb-0">قائمة الاشتراكات</h5>
                    </div>
                </div>
                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover w-full">
                            <thead>
                                <tr>
                                    <th class="text-right">#</th>
                                    <th class="text-right">الخطة</th>
                                    <th class="text-right">السعر</th>
                                    <th class="text-right">الحالة</th>
                                    <th class="text-right">اسم المستخدم</th>
                                    <th class="text-right">السيرفر</th>
                                    <th class="text-right">الاستحقاق القادم</th>
                                    <th class="text-right">الدومين</th>
                                    <th class="text-right">خيارات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sub->id); ?></td>
                                        </td>
                                        <td><?php echo e($sub->plan->name ?? ''); ?></td>
                                        <td><?php echo e(number_format($sub->price, 2)); ?> $</td>
                                        <td>
                                            <?php if($sub->status == 'active'): ?>
                                                <span
                                                    class="badge bg-emerald-500/10 text-emerald-600 rounded-full text-xs px-2 py-0.5">نشط</span>
                                            <?php elseif($sub->status == 'pending'): ?>
                                                <span
                                                    class="badge bg-yellow-100 text-yellow-800 rounded-full text-xs px-2 py-0.5">معلق</span>
                                            <?php elseif($sub->status == 'suspended'): ?>
                                                <span
                                                    class="badge bg-gray-500/10 text-gray-600 rounded-full text-xs px-2 py-0.5">موقوف</span>
                                            <?php elseif($sub->status == 'cancelled'): ?>
                                                <span
                                                    class="badge bg-red-100 text-red-800 rounded-full text-xs px-2 py-0.5">ملغي</span>
                                            <?php else: ?>
                                                <span
                                                    class="badge bg-gray-200 text-gray-700 rounded-full text-xs px-2 py-0.5"><?php echo e(__($sub->status)); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($sub->username); ?></td>
                                        <td><?php echo e($sub->server ? $sub->server->name : '-'); ?></td>
                                        <td><?php echo e($sub->next_due_date); ?></td>
                                        <td><?php echo e($sub->domain_name); ?></td>
                                        <td class="whitespace-nowrap text-center">
                                            <div class="flex flex-col items-center gap-1">
                                                <a href="<?php echo e(route('client.subscriptions.show', $sub)); ?>"
                                                    class="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm bg-primary/10 text-primary hover:bg-primary/20 transition">
                                                    <i class="ti ti-edit text-base"></i>
                                                    إدارة
                                                </a>
                                                <?php if(app()->environment('local')): ?>
                                                    <a href="<?php echo e(route('tenant.preview', $sub)); ?>" target="_blank"
                                                        class="text-xs text-gray-500 hover:text-primary transition">
                                                        معاينة محلية
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-4">
                        <?php echo e($subscriptions->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $attributes = $__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $component = $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?>

<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\client\subscriptions.blade.php ENDPATH**/ ?>