<div>
    <div class="alert alert-<?php echo e($alertType); ?>  justify-between items-center <?php echo e($alert === false ? 'hidden' : 'flex'); ?>">
        <?php echo e($alertMessage); ?>

        <button type="button" class="btn-close" wire:click="closeModal">
            <span class="pc-micon">
                <i class="material-icons-two-tone pc-icon">close</i>
            </span>
        </button>
    </div>
    <?php if($mode === 'index'): ?>
        <?php echo $__env->make('livewire.admin.client.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php elseif($mode === 'add'): ?>
        <?php echo $__env->make('livewire.admin.client.add', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php elseif($mode === 'edit'): ?>
        <?php echo $__env->make('livewire.admin.client.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php elseif($mode === 'show'): ?>
        <?php echo $__env->make('livewire.admin.client.show', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\livewire\client.blade.php ENDPATH**/ ?>