<?php
    // تحديد RTL: نحاول من جدول اللغات ثم نعمل fallback حسب كود اللغة
    $active = $activeLang ?? app()->getLocale();
    $isRtl = optional(
        $languages instanceof \Illuminate\Support\Collection
            ? $languages->firstWhere('code', $active)
            : collect($languages)->firstWhere('code', $active),
    )->is_rtl;
    if ($isRtl === null) {
        $isRtl = in_array($active, ['ar', 'fa', 'ur', 'he']);
    }
?>

<div class="space-y-6" dir="<?php echo e($isRtl ? 'rtl' : 'ltr'); ?>">
    <h2 class="text-xl font-bold mb-4">إدارة سكشنات الصفحة</h2>

    
    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
        <div class="bg-green-100 text-green-800 px-4 py-2 rounded"><?php echo e(session('success')); ?></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php if(session()->has('error')): ?>
        <div class="bg-red-100 text-red-800 px-4 py-2 rounded"><?php echo e(session('error')); ?></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!--[if BLOCK]><![endif]--><?php switch($section->key):
            case ('hero'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sections.hero-section', ['section' => $section]);

$__html = app('livewire')->mount($__name, $__params, 'hero-'.e($section->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('features'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sections.features-section', ['section' => $section]);

$__html = app('livewire')->mount($__name, $__params, 'features-'.e($section->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('banner'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sections.banner-section', ['section' => $section]);

$__html = app('livewire')->mount($__name, $__params, 'banner-'.e($section->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('services'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sections.services-section', ['section' => $section]);

$__html = app('livewire')->mount($__name, $__params, 'services-'.e($section->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('works'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sections.works-section', ['section' => $section]);

$__html = app('livewire')->mount($__name, $__params, 'works-'.e($section->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('home-works'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sections.home-works-section', ['section' => $section]);

$__html = app('livewire')->mount($__name, $__params, 'home-works-'.e($section->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('templates'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sections.templates-section', ['section' => $section]);

$__html = app('livewire')->mount($__name, $__params, 'templates-'.e($section->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('testimonials'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sections.testimonials-section', ['section' => $section]);

$__html = app('livewire')->mount($__name, $__params, 'testimonials-'.e($section->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('blog'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sections.blogs-section', ['section' => $section]);

$__html = app('livewire')->mount($__name, $__params, 'blog-'.e($section->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('search-domain'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sections.search-domain-section', ['section' => $section]);

$__html = app('livewire')->mount($__name, $__params, 'search-domain-'.e($section->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('hosting-plans'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sections.hosting-plan-section', ['section' => $section]);

$__html = app('livewire')->mount($__name, $__params, 'hosting-plans-'.e($section->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('templates-pages'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.sections.templates-pages-section', ['section' => $section]);

$__html = app('livewire')->mount($__name, $__params, 'templates-pages-'.e($section->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php default: ?>
                <div class="p-4 bg-gray-100 rounded shadow">سكشن غير مدعوم حالياً: <?php echo e($section->key); ?></div>
        <?php endswitch; ?><!--[if ENDBLOCK]><![endif]-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

    
    <div class="mt-10 border-t pt-6 flex items-center gap-3">
        <button type="button" wire:click="openPalette"
            class="bg-primary text-white px-6 py-2 rounded hover:bg-primary/90 transition">
            + أضف سكشن
        </button>
    </div>

    
    <div wire:key="sections-palette"
         class="fixed inset-y-0 z-50 w-[380px] max-w-[90vw] bg-white dark:bg-gray-900 shadow-2xl
               transition-transform duration-300
               <?php echo e($isRtl ? 'left-0 border-r' : 'right-0 border-l'); ?>

           flex flex-col h-screen overflow-hidden"
        style="<?php echo e($showPalette
            ? 'transform: translateX(0);'
            : ($isRtl
                ? 'transform: translateX(-105%);'
                : 'transform: translateX(105%);')); ?>"
        aria-hidden="<?php echo e($showPalette ? 'false' : 'true'); ?>">
        
        <div class="shrink-0 flex items-center justify-between px-4 py-3 border-b">
            <h3 class="text-base font-semibold">أضف سكشن</h3>
            <button type="button" class="text-gray-500 hover:text-gray-700" wire:click="closePalette"
                aria-label="إغلاق">✕</button>
        </div>

        
        <div class="shrink-0 p-4 space-y-3 border-b">
            <input type="search" wire:model.live.debounce.300ms="paletteSearch" class="w-full border rounded px-3 py-2"
                placeholder="ابحث (مثال: hero, features, blog)">

            <input type="number" wire:model="paletteOrder" class="w-full border rounded px-3 py-2"
                placeholder="الترتيب (اختياري)">
        </div>

        
        <div class="flex-1 min-h-0 overflow-y-auto p-4">
            <div class="grid grid-cols-1 gap-3">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $paletteKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $meta = $keyMeta[$k] ?? ['label' => $k, 'desc' => '', 'unique' => false, 'thumb' => null];
                    ?>

                    <div class="border rounded-xl hover:shadow-md transition overflow-hidden" wire:key="palette-item-<?php echo e($k); ?>">
                        <!--[if BLOCK]><![endif]--><?php if(!empty($meta['thumb'])): ?>
                            <div class="aspect-[16/9] bg-gray-100">
                                <img src="<?php echo e($meta['thumb']); ?>" alt="<?php echo e($meta['label']); ?>"
                                    class="w-full h-full object-cover">
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <div class="p-3 space-y-2">
                            <div class="flex items-start justify-between">
                                <div>
                                    <div class="font-semibold"><?php echo e($meta['label']); ?></div>
                                    <!--[if BLOCK]><![endif]--><?php if($meta['desc']): ?>
                                        <div class="text-xs text-gray-500 mt-1"><?php echo e($meta['desc']); ?></div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <!--[if BLOCK]><![endif]--><?php if(!empty($meta['unique'])): ?>
                                        <span
                                            class="inline-block mt-2 text-[11px] px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                                            فريد (مرة واحدة)
                                        </span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>

                            <div class="flex items-center justify-end">
                                <button type="button" wire:click.stop="addFromPalette('<?php echo e($k); ?>')"
                                    wire:loading.attr="disabled" wire:target="addFromPalette"
                                    class="px-3 py-1.5 rounded bg-primary text-white text-sm hover:bg-primary/90">
                                    إضافة
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center text-gray-500 py-8">لا توجد نتائج مطابقة لبحثك.</div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>


    
    <!--[if BLOCK]><![endif]--><?php if($showPalette): ?>
        <button type="button" class="fixed inset-0 z-40 bg-black/40" wire:click="closePalette"
            aria-label="إغلاق اللوحة"></button>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/livewire/dashboard/sections.blade.php ENDPATH**/ ?>