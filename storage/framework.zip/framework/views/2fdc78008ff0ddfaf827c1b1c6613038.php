<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>"><?php echo e(t('dashboard.Home', 'Home')); ?></a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.languages.index')); ?>"><?php echo e(t('dashboard.Languages', 'Languages')); ?></a></li>
                <li class="breadcrumb-item" aria-current="page"><?php echo e(t('dashboard.Translation_Values', 'Translation Values')); ?></li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0"><?php echo e(t('dashboard.Translation_Values', 'Translation Values')); ?></h2>
            </div>
        </div>
    </div>
    <!-- [ breadcrumb ] end -->
    <!-- [ Main Content ] start -->
    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card table-card">
                <div class="card-header">
                    <div class="sm:flex items-center justify-between">
                        <h5 class="mb-3 sm:mb-0"><?php echo e(t('dashboard.Translation_Values', 'Translation Values')); ?></h5>
                        <div>
                            <a href="<?php echo e(route('dashboard.translation-values.create')); ?>" class="btn btn-primary"><?php echo e(t('dashboard.Add_New_Translation', 'Add New Translation')); ?></a>
                        </div>
                    </div>
                </div>
                <?php if(session('success')): ?>
                <div class="alert alert-success mb-4"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <!-- Language Filter -->
                <div class="flex items-center justify-between mb-4 px-5 py-4">
                    <form method="GET" action="<?php echo e(route('dashboard.translation-values.index')); ?>" class="flex items-center gap-3 flex-wrap">
                        <!-- Language Filter -->
                        <select name="locale" onchange="this.form.submit()" class="w-48 border px-2 py-1 rounded">
                            <option value="">-- <?php echo e(t('dashboard.All_Languages', 'All Languages')); ?> --</option>
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($lang->code); ?>" <?php echo e($localeFilter == $lang->code ? 'selected' : ''); ?>>
                                <?php echo e($lang->native); ?> (<?php echo e($lang->code); ?>)
                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <!-- Type Filter -->
                        <select name="type" onchange="this.form.submit()" class="w-48 border px-2 py-1 rounded">
                            <option value="">-- <?php echo e(t('dashboard.All_Types', 'All Types')); ?> --</option>
                            <option value="dashboard" <?php echo e($typeFilter == 'dashboard' ? 'selected' : ''); ?>><?php echo e(t('dashboard.Dashboard', 'Dashboard')); ?></option>
                            <option value="frontend" <?php echo e($typeFilter == 'frontend' ? 'selected' : ''); ?>><?php echo e(t('dashboard.Frontend', 'Frontend')); ?></option>
                            <option value="general" <?php echo e($typeFilter == 'general' ? 'selected' : ''); ?>><?php echo e(t('dashboard.General', 'General')); ?></option>
                        </select>
                        <!-- Search -->
                        <input type="text" name="search" value="<?php echo e($search); ?>" placeholder="<?php echo e(t('dashboard.Search_keys...', 'Search keys...')); ?>" class="border px-2 py-1 rounded w-64">
                        <button type="submit" class="btn btn-primary"><?php echo e(t('dashboard.Search', 'Search')); ?></button>
                        <a href="<?php echo e(route('dashboard.translation-values.index')); ?>" class="btn btn-secondary"><?php echo e(t('dashboard.Reset', 'Reset')); ?></a>
                    </form>
                </div>
                <div class="flex items-center gap-2 mb-4 px-5">
                    <a href="<?php echo e(route('dashboard.translation-values.export')); ?>" class="btn btn-success">
                        <?php echo e(t('dashboard.Export_CSV', 'Export CSV')); ?>

                    </a>
                    <form action="<?php echo e(route('dashboard.translation-values.import')); ?>" method="POST" enctype="multipart/form-data" class="flex items-center gap-2">
                        <?php echo csrf_field(); ?>
                        <input type="file" name="csv_file" accept=".csv" required class="border px-2 py-1 rounded">
                        <button type="submit" class="btn btn-primary"><?php echo e(t('dashboard.Import_CSV', 'Import CSV')); ?></button>
                    </form>
                </div>

                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo e(t('dashboard.Key', 'Key')); ?></th>
                                    <th><?php echo e(t('dashboard.Value', 'Value')); ?></th>
                                    <th><?php echo e(t('dashboard.Type', 'Type')); ?></th>
                                    <th><?php echo e(t('dashboard.Actiont', 'Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $type = Str::startsWith($key, 'dashboard.') ? 'Dashboard' :
                                (Str::startsWith($key, 'frontend.') ? 'Frontend' : 'General');
                                ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($key); ?></td>
                                    <td><?php echo e(isset($items[0]) ? $items[0]->value : ''); ?></td>
                                    <td><?php echo e($type); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('dashboard.translation-values.edit', ['key' => $key])); ?>" class="btn btn-sm btn-primary">
                                            <?php echo e(t('dashboard.edit_translation', 'Edit Translation')); ?>

                                        </a>
                                        <form action="<?php echo e(route('dashboard.translation-values.destroy', ['key' => $key])); ?>" method="POST" class="inline-block" onsubmit="return confirm('<?php echo e(t('dashboard.confirm_delete', 'Confirm Delete')); ?>');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger"><?php echo e(t('dashboard.delete', 'Delete')); ?></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="mt-4">
                    
                </div>
            </div>
        </div>
    </div>
    <!-- [ Main Content ] end -->

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\lang\translation-values\index.blade.php ENDPATH**/ ?>