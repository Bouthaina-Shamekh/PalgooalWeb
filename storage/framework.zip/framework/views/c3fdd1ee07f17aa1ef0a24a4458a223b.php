<!-- Desktop Navigation -->
<nav role="navigation" aria-label="القائمة الرئيسية">
    <ul class="hidden md:flex items-center gap-7 font-semibold text-primary dark:text-white text-base">
        <?php $__empty_1 = true; $__currentLoopData = $header->items ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($item->type === 'link'): ?>
                <li><a href="<?php echo e($item->url); ?>" class="hover:text-secondary dark:hover:text-yellow-400 transition"><?php echo e($item->label); ?></a></li>
            <?php elseif($item->type === 'dropdown'): ?>
                <li class="relative group">
                    <div class="flex items-center gap-1 cursor-pointer hover:text-secondary dark:hover:text-yellow-400 transition">
                        <span><?php echo e($item->label); ?></span>
                        <svg class="w-4 h-4 mt-0.5 transform transition-transform group-hover:rotate-180"
                            fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                    </div>
                    <ul class="absolute top-full end-0 mt-2 w-48 bg-white dark:bg-[#2c2c2c] border border-gray-200 dark:border-gray-700
                        rounded-lg shadow-md z-50 text-sm font-normal flex-col opacity-0 invisible scale-95
                        group-hover:opacity-100 group-hover:visible group-hover:scale-100 transition-all duration-200">
                        <?php $__currentLoopData = $item->children ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e($child['url'] ?? '#'); ?>"
                                    class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-white/20">
                                    <?php echo e($child['label'][app()->getLocale()] ?? $child['label']['ar'] ?? '-'); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="text-sm text-gray-500 dark:text-gray-400 italic">
                    لا توجد قوائم حالياً — يمكنك إضافتها من لوحة التحكم
                </li>
        <?php endif; ?>
    </ul>
</nav><?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/tamplate/layouts/partials/desktop-nav.blade.php ENDPATH**/ ?>