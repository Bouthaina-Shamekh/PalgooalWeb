<?php
    $clientUser = Auth::guard('client')->user();
    $clientName = trim(($clientUser->first_name ?? '') . ' ' . ($clientUser->last_name ?? '')) ?: t('frontend.client_nav.default_client', 'Client');
?>

<nav class="pc-sidebar">
    <div class="navbar-wrapper">
        <div class="m-header flex items-center py-4 px-6 h-header-height">
            <a href="<?php echo e(route('client.home')); ?>" class="b-brand flex items-center gap-3">
                <!-- ========   Change your logo from here   ============ -->
                <img src="<?php echo e(asset('assets/dashboard/images/logo1.svg')); ?>" class="img-fluid logo-lg" alt="<?php echo e(t('frontend.client_nav.logo_alt', 'Logo')); ?>"
                    style="display: none" />
                <div style="width: 232px;">
                    <img src="<?php echo e(asset('assets/dashboard/images/logo1.svg')); ?>" class="img-fluid logo-lg"
                        alt="<?php echo e(t('frontend.client_nav.logo_alt', 'Logo')); ?>" />
                </div>
            </a>
        </div>
        <div class="navbar-content h-[calc(100vh_-_74px)] py-2.5">
            <div class="card pc-user-card mx-[15px] mb-[15px] bg-theme-sidebaruserbg dark:bg-themedark-sidebaruserbg">
                <div class="card-body !p-5">
                    <div class="flex items-center">
                        <?php if (isset($component)) { $__componentOriginalae4f1e05f52181f10a43f448b95052a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4f1e05f52181f10a43f448b95052a9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.avatar','data' => ['name' => $clientName,'size' => '45','class' => 'shrink-0 w-[45px] h-[45px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($clientName),'size' => '45','class' => 'shrink-0 w-[45px] h-[45px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4f1e05f52181f10a43f448b95052a9)): ?>
<?php $attributes = $__attributesOriginalae4f1e05f52181f10a43f448b95052a9; ?>
<?php unset($__attributesOriginalae4f1e05f52181f10a43f448b95052a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4f1e05f52181f10a43f448b95052a9)): ?>
<?php $component = $__componentOriginalae4f1e05f52181f10a43f448b95052a9; ?>
<?php unset($__componentOriginalae4f1e05f52181f10a43f448b95052a9); ?>
<?php endif; ?>
                        <div class="ml-4 mr-2 grow">
                            <h6 class="mb-0"><?php echo e($clientName); ?></h6>
                            <small><?php echo e(t('frontend.client_nav.role', 'Role')); ?></small>
                        </div>
                        <a class="shrink-0 btn btn-icon inline-flex btn-link-secondary" data-pc-toggle="collapse"
                            href="#pc_sidebar_userlink">
                            <svg class="pc-icon w-[22px] h-[22px]">
                                <use xlink:href="#custom-sort-outline"></use>
                            </svg>
                        </a>
                    </div>
                    <div class="hidden pc-user-links" id="pc_sidebar_userlink">
                        <div class="pt-3 *:flex *:items-center *:py-2 *:gap-2.5 hover:*:text-primary-500">
                            <a href="<?php echo e(route('client.update_account')); ?>">
                                <i class="text-lg leading-none ti ti-user"></i>
                                <span><?php echo e(t('frontend.client_nav.my_account', 'My Account')); ?></span>
                            </a>
                            <a href="#!">
                                <i class="text-lg leading-none ti ti-settings"></i>
                                <span><?php echo e(t('frontend.client_nav.settings', 'Settings')); ?></span>
                            </a>
                            <a href="#!">
                                <i class="text-lg leading-none ti ti-lock"></i>
                                <span><?php echo e(t('frontend.client_nav.lock_screen', 'Lock Screen')); ?></span>
                            </a>
                            <form method="POST" action="<?php echo e(route('client.logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" style="display: flex; align-items: center; gap: 5px;">
                                    <i class="text-lg leading-none ti ti-power"></i>
                                    <span><?php echo e(t('frontend.client_nav.logout', 'Logout')); ?></span>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <ul class="pc-navbar">
                <li class="pc-item pc-caption">
                    <label><?php echo e(t('frontend.client_nav.basic', 'Basic')); ?></label>
                    <svg class="pc-icon">
                        <use xlink:href="#custom-presentation-chart"></use>
                    </svg>
                </li>
                <li class="pc-item">
                    <a href="<?php echo e(route('client.home')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <svg class="pc-icon">
                                <use xlink:href="#custom-story"></use>
                            </svg>
                        </span>
                        <span class="pc-mtext"><?php echo e(t('frontend.client_nav.home', 'Home')); ?></span>
                    </a>
                </li>
                <li class="pc-item">
                    <a href="<?php echo e(route('client.domains.search')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <svg class="pc-icon">
                                <use xlink:href="#custom-story"></use>
                            </svg>
                        </span>
                        <span class="pc-mtext"><?php echo e(t('frontend.client_nav.domain_name_search', 'Domain Name Search')); ?></span>
                    </a>
                </li>
                <li class="pc-item">
                    <a href="<?php echo e(route('client.domains.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <svg class="pc-icon">
                                <use xlink:href="#custom-story"></use>
                            </svg>
                        </span>
                        <span class="pc-mtext"><?php echo e(t('frontend.client_domains.index.title', 'My Domains')); ?></span>
                    </a>
                </li>
                <li class="pc-item">
                    <a href="<?php echo e(route('client.subscriptions')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <svg class="pc-icon">
                                <use xlink:href="#custom-story"></use>
                            </svg>
                        </span>
                        <span class="pc-mtext"><?php echo e(t('frontend.client_nav.subscriptions', 'Subscriptions')); ?></span>
                    </a>
                </li>
                <li class="pc-item">
                    <a href="<?php echo e(route('client.invoices')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <svg class="pc-icon">
                                <use xlink:href="#custom-story"></use>
                            </svg>
                        </span>
                        <span class="pc-mtext"><?php echo e(t('frontend.client_nav.invoices', 'Invoices')); ?></span>
                    </a>
                </li>

            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\client\layouts\partials\nav.blade.php ENDPATH**/ ?>