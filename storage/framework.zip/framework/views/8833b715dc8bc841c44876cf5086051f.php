﻿<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto py-6">
        <h1 class="text-2xl font-bold mb-4">إدارة الشهادات</h1>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', 'App\\Models\\Testimonial')): ?>
            <a href="<?php echo e(route('dashboard.testimonials.create')); ?>" class="btn btn-primary mb-4">
                إضافة شهادة جديدة
            </a>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 p-4 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="table-responsive dt-responsive">
            <table class="table table-striped table-bordered nowrap">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>الصورة</th>
                        <th>الاسم (<?php echo e(app()->getLocale()); ?>)</th>
                        <th>عدد النجوم</th>
                        <th>نص الشهادة (<?php echo e(app()->getLocale()); ?>)</th>
                        <th>حالة الاعتماد</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>

                            
                            <td>
                                <?php
                                    // باستخدام العلاقة مع موديل Media (مع with('image') من الكنترولر)
                                    $src = $testimonial->image?->url;
                                ?>

                                <?php if($src): ?>
                                    <img src="<?php echo e($src); ?>" class="w-10 h-10 rounded-full object-cover" alt="صورة الشهادة">
                                <?php else: ?>
                                    <span class="text-xs text-gray-400">لا توجد صورة</span>
                                <?php endif; ?>
                            </td>

                            
                            <td>
                                <?php echo e($testimonial->translation()?->name ?? 'غير متوفر'); ?>

                            </td>

                            
                            <td><?php echo e($testimonial->star); ?></td>

                            
                            <td>
                                <?php echo e($testimonial->translation()?->feedback ?? 'لا يوجد نص'); ?>

                            </td>

                            
                            <td>
                                <?php if($testimonial->is_approved): ?>
                                    <span
                                        class="px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">
                                        معتمد
                                    </span>
                                <?php else: ?>
                                    <span
                                        class="px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-700">
                                        بانتظار الموافقة
                                    </span>
                                <?php endif; ?>
                            </td>

                            
                            <td style="display: flex; gap: 5px;">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', 'App\\Models\\Testimonial')): ?>
                                    <a href="<?php echo e(route('dashboard.testimonials.edit', $testimonial->id)); ?>"
                                        class="btn btn-sm btn-warning">
                                        تعديل
                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', 'App\\Models\\Testimonial')): ?>
                                    <form action="<?php echo e(route('dashboard.testimonials.destroy', $testimonial->id)); ?>"
                                        method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger"
                                            onclick="return confirm('هل أنت متأكد من حذف هذه الشهادة؟');">
                                            حذف
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            <?php echo e($testimonials->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\testimonials\index.blade.php ENDPATH**/ ?>