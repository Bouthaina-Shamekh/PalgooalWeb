<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">الرئيسية</a></li>
                <li class="breadcrumb-item" aria-current="page">السيرفرات</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">قائمة السيرفرات</h2>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card table-card">
                <?php if(session('connection_result')): ?>
                    <div class="alert alert-info mb-4"><?php echo e(session('connection_result')); ?></div>
                <?php endif; ?>
                <div class="card-header">
                    <div class="sm:flex items-center justify-between">
                        <h5 class="mb-3 sm:mb-0">قائمة السيرفرات</h5>
                        <div class="flex items-center gap-2">
                            <a href="<?php echo e(route('dashboard.servers.create')); ?>" class="btn btn-primary">
                                إضافة سيرفر جديد
                            </a>
                        </div>
                    </div>
                </div>

                
                <div class="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between mb-4 px-4">
                    <input
                        type="text"
                        placeholder="بحث عن السيرفرات..."
                        class="w-full sm:w-80 border rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/30"
                        disabled
                    />
                    <div class="flex items-center gap-2">
                        <label class="text-sm text-gray-500">لكل صفحة</label>
                        <select
                            class="border rounded-xl px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-primary/30"
                            disabled
                        >
                            <option value="10">10</option>
                            <option value="25">25</option>
                        </select>
                    </div>
                </div>

                <div class="card-body pt-3">
                    <div class="table-responsive">
                        <table class="table table-hover w-full">
                            <thead>
                                <tr>
                                    <th class="text-right">#</th>
                                    <th class="text-right">الاسم</th>
                                    <th class="text-right">النوع</th>
                                    <th class="text-right">IP</th>
                                    <th class="text-right">Hostname</th>
                                    <th class="text-right">الحالة</th>
                                    <th class="text-right">خيارات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $rowIndex = ($servers->firstItem() ?? 1) + $loop->index;
                                    ?>
                                    <tr>
                                        <td><?php echo e($rowIndex); ?></td>
                                        <td class="font-semibold"><?php echo e($server->name); ?></td>
                                        <td class="text-sm"><?php echo e($server->type); ?></td>
                                        <td><?php echo e($server->ip); ?></td>
                                        <td><?php echo e($server->hostname); ?></td>
                                        <td>
                                            <?php if($server->is_active): ?>
                                                <span class="badge bg-emerald-500/10 text-emerald-600 rounded-full text-xs px-2 py-0.5">مفعل</span>
                                            <?php else: ?>
                                                <span class="badge bg-gray-500/10 text-gray-600 rounded-full text-xs px-2 py-0.5">معطل</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="whitespace-nowrap">
                                            <a href="<?php echo e(route('dashboard.servers.edit', $server)); ?>" class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary" title="تعديل">
                                                <i class="ti ti-edit text-xl leading-none"></i>
                                            </a>
                                            <form action="<?php echo e(route('dashboard.servers.destroy', $server)); ?>" method="POST" style="display:inline-block" onsubmit="return confirm('هل أنت متأكد من الحذف؟');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary" title="حذف">
                                                    <i class="ti ti-trash text-xl leading-none"></i>
                                                </button>
                                            </form>
                                            <a href="<?php echo e(route('dashboard.servers.test-connection', $server)); ?>" class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary" title="فحص الاتصال">
                                                <i class="ti ti-plug text-xl leading-none"></i>
                                            </a>
                                            <a href="<?php echo e(route('dashboard.servers.accounts', $server)); ?>" class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary" title="عرض المواقع">
                                                <i class="ti ti-list-details text-xl leading-none"></i>
                                            </a>
                                            <?php if($server->type == 'cpanel'): ?>
                                                <a href="<?php echo e(route('dashboard.servers.sso-whm', $server)); ?>" target="_blank" class="w-8 h-8 rounded-xl inline-flex items-center justify-center btn-link-secondary" title="دخول السيرفر (SSO)">
                                                    <i class="ti ti-login text-xl leading-none"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-gray-500 py-8">لا يوجد سيرفرات.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-4">
                        <?php echo e($servers->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views/dashboard/management/servers/index.blade.php ENDPATH**/ ?>