<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.plan_categories.index')); ?>">Plan Categories</a></li>
                <li class="breadcrumb-item" aria-current="page">Edit Category</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">Edit Plan Category</h2>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Category Information</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('dashboard.plan_categories.update', ['plan_category' => $category->id])); ?>"
                        method="POST" class="grid grid-cols-12 gap-x-6 gap-y-4">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        
                        <div class="col-span-12 md:col-span-6 flex items-center mt-2">
                            <label class="form-label mr-2">Active</label>
                            <input type="checkbox" name="is_active" value="1" class="form-checkbox"
                                <?php echo e(old('is_active', $category->is_active) ? 'checked' : ''); ?>>
                        </div>

                        
                        <div class="col-span-12">
                            <h5 class="mb-2 font-bold">Translations</h5>
                            <?php
                                $locales = $languages ?? [
                                    (object) ['code' => 'ar', 'name' => 'العربية'],
                                    (object) ['code' => 'en', 'name' => 'English'],
                                ];
                            ?>

                            
                            <ul class="flex border-b mb-4 space-x-2 rtl:space-x-reverse" id="langTabs" role="tablist">
                                <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button type="button" onclick="showLangTab('<?php echo e($lang->code); ?>')"
                                        class="px-4 py-2 rounded-t focus:outline-none transition-all <?php if($loop->first): ?> bg-white border-t border-l border-r font-bold <?php else: ?> bg-gray-200 text-gray-600 <?php endif; ?>"
                                        id="tab-<?php echo e($lang->code); ?>">
                                        <?php echo e($lang->name); ?>

                                    </button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                            <input type="hidden" name="active_locale" id="active_locale" value="<?php echo e($locales[0]->code); ?>">

                            
                            <div class="tab-content" id="langTabsContent">
                                <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $trans = $category->translations->where('locale', $lang->code)->first(); ?>
                                    <div id="pane-<?php echo e($lang->code); ?>" class="lang-pane <?php if($loop->first): ?> block <?php else: ?> hidden <?php endif; ?>">
                                        <div class="col-span-12 md:col-span-6">
                                            <label class="form-label">Title (<?php echo e($lang->name); ?>) *</label>
                                            <input type="text" name="translations[<?php echo e($lang->code); ?>][title]"
                                                class="form-control"
                                                value="<?php echo e(old('translations.' . $lang->code . '.title', $trans?->title)); ?>"
                                                required placeholder="Enter the title in <?php echo e($lang->name); ?>">
                                            <?php $__errorArgs = ['translations.' . $lang->code . '.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-span-12 md:col-span-6">
                                            <label class="form-label">Slug (<?php echo e($lang->name); ?>)</label>
                                            <input type="text" name="translations[<?php echo e($lang->code); ?>][slug]"
                                                class="form-control"
                                                value="<?php echo e(old('translations.' . $lang->code . '.slug', $trans?->slug)); ?>"
                                                placeholder="مثال: web-hosting - اتركه فارغًا للتوليد الآلي">
                                            <?php $__errorArgs = ['translations.' . $lang->code . '.slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-span-12">
                                            <label class="form-label">Description (<?php echo e($lang->name); ?>)</label>
                                            <textarea name="translations[<?php echo e($lang->code); ?>][description]" class="form-control" rows="2"
                                                placeholder="Optional description in <?php echo e($lang->name); ?>"><?php echo e(old('translations.' . $lang->code . '.description', $trans?->description)); ?></textarea>
                                            <?php $__errorArgs = ['translations.' . $lang->code . '.description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        
                        <div class="col-span-12 flex items-center justify-end gap-3 mt-4">
                            <a href="<?php echo e(route('dashboard.plan_categories.index')); ?>" class="btn btn-light">Cancel</a>
                            <button type="submit" class="btn btn-primary">Update Category</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <script>
        function showLangTab(locale) {
            document.querySelectorAll('.lang-pane').forEach(pane => {
                pane.classList.add('hidden');
                pane.classList.remove('block');
            });
            document.getElementById('pane-' + locale).classList.remove('hidden');
            document.getElementById('pane-' + locale).classList.add('block');

            document.getElementById('active_locale').value = locale;

            document.querySelectorAll('[id^="tab-"]').forEach(btn => {
                btn.classList.remove('bg-white', 'border-t', 'border-l', 'border-r', 'font-bold');
                btn.classList.add('bg-gray-200', 'text-gray-600');
            });

            const activeBtn = document.getElementById('tab-' + locale);
            activeBtn.classList.add('bg-white', 'border-t', 'border-l', 'border-r', 'font-bold');
            activeBtn.classList.remove('bg-gray-200', 'text-gray-600');
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\plan_categories\edit.blade.php ENDPATH**/ ?>