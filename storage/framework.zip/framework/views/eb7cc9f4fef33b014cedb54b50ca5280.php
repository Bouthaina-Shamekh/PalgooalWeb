<?php if (isset($component)) { $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $attributes; } ?>
<?php $component = App\View\Components\ClientLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ClientLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        $requiredCount = $minNameservers ?? 2;
        $maxSlots = $maxNameservers ?? 12;
        $oldNs = array_values(old('nameservers', $nameservers ?? []));
        $displaySlots = min($maxSlots, max($requiredCount, count($oldNs)));
        $oldNs = array_pad($oldNs, $displaySlots, '');
        $oldIps = array_values(old('nameserver_ips', []));
        $oldIps = array_pad($oldIps, $displaySlots, '');
        $dnsModeMap = [
            'default' => t('frontend.client_domains.dns.snapshot_default', 'Provider default nameservers'),
            'custom' => t('frontend.client_domains.dns.snapshot_custom', 'Custom nameservers enabled'),
            'park' => t('frontend.client_domains.dns.snapshot_park', 'Parked at provider'),
        ];
        $dnsMode = $remoteDns['status'] ?? null;
        $dnsModeText = $dnsMode ? ($dnsModeMap[$dnsMode] ?? \Illuminate\Support\Str::title($dnsMode)) : t('frontend.client_domains.dns.snapshot_unknown', 'Unknown');
        $headingText = str_replace(':domain', $domain->domain_name, t('frontend.client_domains.dns.heading', 'Change DNS for :domain'));
        $fetchedAtText = !empty($remoteDns['fetched_at'])
            ? str_replace(':date', $remoteDns['fetched_at']->timezone(config('app.timezone', 'UTC'))->format('Y-m-d H:i'), t('frontend.client_domains.dns.snapshot_fetched', 'Fetched at :date'))
            : null;
        $syncDateText = $domain->dns_last_synced_at
            ? str_replace(':date', $domain->dns_last_synced_at->timezone(config('app.timezone', 'UTC'))->format('Y-m-d H:i'), t('frontend.client_domains.dns.sync_date', 'Last sync with registrar on :date'))
            : null;
        $syncNoteText = $domain->dns_last_note
            ? str_replace(':note', $domain->dns_last_note, t('frontend.client_domains.dns.sync_note', 'Last note: :note'))
            : null;
        $formSubtitleText = str_replace(':max', (string) $maxSlots, t('frontend.client_domains.dns.form_subtitle', 'Provide at least two nameservers. You can add up to :max nameservers.'));
        $validationMinText = str_replace(':n', (string) $requiredCount, t('frontend.client_domains.dns.validation_min', 'Please provide at least :n nameservers.'));
        $validationMaxText = str_replace(':n', (string) $maxSlots, t('frontend.client_domains.dns.validation_max', 'You can add up to :n nameservers.'));
    ?>

    <div class="page-header">
        <div class="page-block">
            <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('client.home')); ?>"><?php echo e(t('frontend.client_nav.home', 'Home')); ?></a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('client.domains.index')); ?>"><?php echo e(t('frontend.client_domains.index.title', 'My Domains')); ?></a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <?php echo e(t('frontend.client_domains.dns.title', 'Change DNS')); ?>

                        </li>
                    </ul>
                    <div class="page-header-title">
                        <h2 class="mb-1"><?php echo e($headingText); ?></h2>
                        <p class="mb-0 text-sm text-muted">
                            <?php echo e(t('frontend.client_domains.dns.subtitle', 'Update your nameservers and sync them directly with the registrar.')); ?>

                        </p>
                    </div>
                </div>
                <a href="<?php echo e(route('client.domains.index')); ?>" class="btn btn-light-secondary">
                    <i class="ti ti-arrow-left me-1"></i>
                    <?php echo e(t('frontend.client_domains.dns.back', 'Back to Domains')); ?>

                </a>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <ul class="mb-0 list-disc ps-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-12 gap-x-6 gap-y-6">
        <div class="col-span-12 xl:col-span-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><?php echo e(t('frontend.client_domains.dns.snapshot_title', 'Registrar Snapshot')); ?></h5>
                </div>
                <div class="card-body space-y-4">
                    <div class="rounded-2xl border border-theme-border dark:border-themedark-border p-4">
                        <div class="text-xs uppercase tracking-wide text-muted mb-2">
                            <?php echo e(t('frontend.client_domains.dns.snapshot_provider', 'Provider')); ?>

                        </div>
                        <div class="font-medium text-body">
                            <?php echo e($remoteDns['provider'] ? \Illuminate\Support\Str::title($remoteDns['provider']) : t('frontend.client_domains.dns.snapshot_unavailable', 'Unavailable')); ?>

                        </div>
                    </div>

                    <div class="rounded-2xl border border-theme-border dark:border-themedark-border p-4">
                        <div class="text-xs uppercase tracking-wide text-muted mb-2">
                            <?php echo e(t('frontend.client_domains.dns.snapshot_mode', 'Current Mode')); ?>

                        </div>
                        <div class="font-medium text-body"><?php echo e($dnsModeText); ?></div>
                    </div>

                    <?php if(!empty($remoteDns['error'])): ?>
                        <div class="rounded-2xl border border-danger-200 bg-danger-50 p-4 text-danger-700 text-sm">
                            <?php echo e($remoteDns['error']); ?>

                        </div>
                    <?php else: ?>
                        <div class="rounded-2xl border border-theme-border dark:border-themedark-border p-4">
                            <div class="text-xs uppercase tracking-wide text-muted mb-3">
                                <?php echo e(t('frontend.client_domains.dns.snapshot_nameservers', 'Nameservers At Registrar')); ?>

                            </div>
                            <div class="space-y-2">
                                <?php $__empty_1 = true; $__currentLoopData = ($remoteDns['nameservers'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nameserver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="rounded-xl bg-theme-bodybg dark:bg-themedark-bodybg px-3 py-2 text-sm font-medium text-body">
                                        <?php echo e($nameserver); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="text-sm text-muted">
                                        <?php echo e(t('frontend.client_domains.dns.snapshot_empty', 'No nameservers were returned by the registrar.')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if(!empty($remoteDns['fetched_at'])): ?>
                        <div class="text-xs text-muted">
                            <?php echo e($fetchedAtText); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><?php echo e(t('frontend.client_domains.dns.sync_title', 'Last Sync')); ?></h5>
                </div>
                <div class="card-body">
                    <?php if($domain->dns_last_synced_at): ?>
                        <div class="text-sm text-body mb-2">
                            <?php echo e($syncDateText); ?>

                        </div>
                        <?php if($domain->dns_last_note): ?>
                            <div class="text-sm text-muted">
                                <?php echo e($syncNoteText); ?>

                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="text-sm text-muted">
                            <?php echo e(t('frontend.client_domains.dns.sync_empty', 'This domain has not been synced yet.')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-span-12 xl:col-span-8">
            <form action="<?php echo e(route('client.domains.dns.update', $domain->id)); ?>" method="POST" class="card" novalidate>
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="card-header">
                    <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                        <div>
                            <h5 class="mb-1"><?php echo e(t('frontend.client_domains.dns.form_title', 'Nameserver Configuration')); ?></h5>
                            <p class="mb-0 text-sm text-muted">
                                <?php echo e($formSubtitleText); ?>

                            </p>
                        </div>
                        <button type="button" id="add-nameserver" class="btn btn-light-primary">
                            <i class="ti ti-plus me-1"></i>
                            <?php echo e(t('frontend.client_domains.dns.add_nameserver', 'Add Nameserver')); ?>

                        </button>
                    </div>
                </div>

                <div class="card-body space-y-6">
                    <div class="rounded-2xl border border-info-200 bg-info-50 p-4 text-sm text-info-800">
                        <div class="font-medium mb-1"><?php echo e(t('frontend.client_domains.dns.quick_guide_title', 'Quick Guide')); ?></div>
                        <p class="mb-1">
                            <?php echo e(t('frontend.client_domains.dns.quick_guide_nameservers', 'If your hosting company gave you ready-made nameservers, enter Nameserver 1 and Nameserver 2 only.')); ?>

                        </p>
                        <p class="mb-0">
                            <?php echo e(t('frontend.client_domains.dns.quick_guide_personal_dns', 'Use "Personal DNS (Optional)" only when you are creating branded nameservers such as ns1.yourdomain.com and the registrar asks for an IP address.')); ?>

                        </p>
                    </div>

                    <div id="nameserver-fields" class="grid grid-cols-1 gap-4 md:grid-cols-2" data-min="<?php echo e($requiredCount); ?>" data-max="<?php echo e($maxSlots); ?>" data-fixed-count="<?php echo e($requiredCount); ?>">
                        <?php $__currentLoopData = $oldNs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $nameserver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $isFixed = $index < $requiredCount;
                                $showPersonalDns = filled($oldIps[$index] ?? '');
                            ?>
                            <div class="space-y-2 ns-item" data-fixed="<?php echo e($isFixed ? 'true' : 'false'); ?>">
                                <label for="nameserver_<?php echo e($index); ?>" class="flex items-center gap-2 text-sm font-medium text-body">
                                    <span class="ns-label-text"><?php echo e(t('frontend.client_domains.dns.nameserver_label', 'Nameserver')); ?> <?php echo e($index + 1); ?></span>
                                    <span class="badge-placeholder badge bg-light-primary text-primary <?php echo e($isFixed ? '' : 'hidden'); ?>">
                                        <?php echo e(t('frontend.client_domains.dns.required', 'Required')); ?>

                                    </span>
                                </label>
                                <div class="flex gap-2">
                                    <input
                                        type="text"
                                        name="nameservers[<?php echo e($index); ?>]"
                                        id="nameserver_<?php echo e($index); ?>"
                                        value="<?php echo e($nameserver); ?>"
                                        class="form-control flex-1"
                                        inputmode="url"
                                        dir="ltr"
                                        placeholder="ns<?php echo e($index + 1); ?>.example.com"
                                        pattern="^([a-z0-9-]+\.)+[a-z]{2,}$"
                                        aria-invalid="false"
                                    />
                                    <button
                                        type="button"
                                        class="btn btn-light-danger remove-ns <?php echo e($isFixed ? 'opacity-0 pointer-events-none' : ''); ?>"
                                        data-fixed="<?php echo e($isFixed ? 'true' : 'false'); ?>"
                                        title="<?php echo e(t('frontend.client_domains.dns.remove', 'Remove')); ?>"
                                    >
                                        <i class="ti ti-x"></i>
                                    </button>
                                </div>
                                <p class="mb-0 text-xs text-muted"><?php echo e(t('frontend.client_domains.dns.example', 'Example: ns1.example.com')); ?></p>
                                <button type="button" class="toggle-glue btn btn-link p-0 text-start text-xs text-primary">
                                    <?php echo e($showPersonalDns ? t('frontend.client_domains.dns.hide_personal_dns', 'Hide Personal DNS') : t('frontend.client_domains.dns.show_personal_dns', 'Use Personal DNS (Optional)')); ?>

                                </button>
                                <div class="glue-ip-wrap <?php echo e($showPersonalDns ? '' : 'hidden'); ?>">
                                    <label for="nameserver_ip_<?php echo e($index); ?>" class="text-xs font-medium text-body">
                                        <?php echo e(t('frontend.client_domains.dns.glue_ip', 'Personal DNS IP')); ?>

                                    </label>
                                    <input
                                        type="text"
                                        name="nameserver_ips[<?php echo e($index); ?>]"
                                        id="nameserver_ip_<?php echo e($index); ?>"
                                        value="<?php echo e($oldIps[$index] ?? ''); ?>"
                                        class="form-control mt-2"
                                        inputmode="decimal"
                                        dir="ltr"
                                        placeholder="192.0.2.10"
                                    />
                                    <p class="mb-0 mt-2 text-xs text-warning-600">
                                        <?php echo e(t('frontend.client_domains.dns.glue_help', 'Only fill this if the registrar asked you to create Personal DNS / branded nameservers such as ns1.all-in1.net.')); ?>

                                    </p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                        <p class="mb-0 text-xs text-muted">
                            <?php echo e(t('frontend.client_domains.dns.form_help', 'DNS updates can take time to propagate after the registrar accepts the change.')); ?>

                        </p>
                        <p id="ns-counter" class="mb-0 text-xs text-muted"></p>
                    </div>

                    <div id="ns-errors" class="hidden rounded-2xl border border-danger-200 bg-danger-50 p-3 text-sm text-danger-700" role="alert" aria-live="polite"></div>

                    <div>
                        <label for="dns-notes" class="form-label"><?php echo e(t('frontend.client_domains.dns.notes', 'Note (optional)')); ?></label>
                        <textarea id="dns-notes" name="notes" rows="4" class="form-control"
                            placeholder="<?php echo e(t('frontend.client_domains.dns.notes_placeholder', 'Share any context you want to keep with this DNS change.')); ?>"><?php echo e(old('notes', $domain->dns_last_note)); ?></textarea>
                    </div>
                </div>

                <div class="card-footer">
                    <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                        <div class="text-sm text-muted">
                            <?php echo e(t('frontend.client_domains.dns.footer_note', 'Changes are pushed to the registrar immediately when the provider accepts the request.')); ?>

                        </div>
                        <div class="flex gap-2">
                            <a href="<?php echo e(route('client.domains.index')); ?>" class="btn btn-light-secondary">
                                <?php echo e(t('frontend.client_domains.dns.cancel', 'Cancel')); ?>

                            </a>
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(t('frontend.client_domains.dns.submit', 'Save DNS Settings')); ?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <template id="ns-template">
        <div class="space-y-2 ns-item" data-fixed="false">
            <label class="flex items-center gap-2 text-sm font-medium text-body">
                <span class="ns-label-text"></span>
                <span class="badge-placeholder badge bg-light-primary text-primary hidden"></span>
            </label>
            <div class="flex gap-2">
                <input type="text" class="form-control flex-1" inputmode="url" dir="ltr" placeholder="" pattern="^([a-z0-9-]+\.)+[a-z]{2,}$" aria-invalid="false" />
                <button type="button" class="btn btn-light-danger remove-ns" data-fixed="false" title="<?php echo e(t('frontend.client_domains.dns.remove', 'Remove')); ?>">
                    <i class="ti ti-x"></i>
                </button>
            </div>
            <p class="mb-0 text-xs text-muted"><?php echo e(t('frontend.client_domains.dns.example', 'Example: ns1.example.com')); ?></p>
            <button type="button" class="toggle-glue btn btn-link p-0 text-start text-xs text-primary"><?php echo e(t('frontend.client_domains.dns.show_personal_dns', 'Use Personal DNS (Optional)')); ?></button>
            <div class="glue-ip-wrap hidden">
                <label class="text-xs font-medium text-body"><?php echo e(t('frontend.client_domains.dns.glue_ip', 'Personal DNS IP')); ?></label>
                <input type="text" class="form-control mt-2 glue-ip-input" inputmode="decimal" dir="ltr" placeholder="192.0.2.10" />
                <p class="mb-0 mt-2 text-xs text-warning-600"><?php echo e(t('frontend.client_domains.dns.glue_help', 'Only fill this if the registrar asked you to create Personal DNS / branded nameservers such as ns1.all-in1.net.')); ?></p>
            </div>
        </div>
    </template>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const fieldsContainer = document.getElementById('nameserver-fields');
            const addButton = document.getElementById('add-nameserver');
            const template = document.getElementById('ns-template');
            const errorsBox = document.getElementById('ns-errors');
            const counterEl = document.getElementById('ns-counter');

            if (!fieldsContainer || !template) {
                return;
            }

            const minCount = parseInt(fieldsContainer.dataset.min || '2', 10);
            const maxCount = parseInt(fieldsContainer.dataset.max || '12', 10);
            const baseCount = parseInt(fieldsContainer.dataset.fixedCount || '0', 10);
            const labelText = <?php echo json_encode(t('frontend.client_domains.dns.nameserver_label', 'Nameserver'), 512) ?>;
            const requiredBadge = <?php echo json_encode(t('frontend.client_domains.dns.required', 'Required'), 512) ?>;
            const minMessage = <?php echo json_encode($validationMinText, 15, 512) ?>;
            const maxMessage = <?php echo json_encode($validationMaxText, 15, 512) ?>;
            const fixMessage = <?php echo json_encode(t('frontend.client_domains.dns.validation_fix', 'Please fix the highlighted fields.'), 512) ?>;
            const glueMessage = <?php echo json_encode(t('frontend.client_domains.dns.validation_glue_ip', 'If you enabled Personal DNS for a nameserver, enter a valid IP address for it.')) ?>;
            const showPersonalDnsText = <?php echo json_encode(t('frontend.client_domains.dns.show_personal_dns', 'Use Personal DNS (Optional)'), 512) ?>;
            const hidePersonalDnsText = <?php echo json_encode(t('frontend.client_domains.dns.hide_personal_dns', 'Hide Personal DNS'), 512) ?>;
            const hostRegex = /^([a-z0-9-]+\.)+[a-z]{2,}$/i;
            const ipRegex = /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;

            const showError = (message) => {
                if (!message) {
                    errorsBox.classList.add('hidden');
                    errorsBox.textContent = '';
                    return;
                }

                errorsBox.textContent = message;
                errorsBox.classList.remove('hidden');
            };

            const syncGlueToggle = (item) => {
                const glueWrap = item.querySelector('.glue-ip-wrap');
                const toggleButton = item.querySelector('.toggle-glue');
                const glueInput = item.querySelector('.glue-ip-input') || glueWrap?.querySelector('input');

                if (!glueWrap || !toggleButton) {
                    return;
                }

                const expanded = !glueWrap.classList.contains('hidden');
                toggleButton.textContent = expanded ? hidePersonalDnsText : showPersonalDnsText;

                if (!expanded && glueInput && glueInput.value.trim() === '') {
                    glueInput.setAttribute('aria-invalid', 'false');
                    glueInput.classList.remove('border-danger-500');
                }
            };

            const updateLabels = () => {
                const items = fieldsContainer.querySelectorAll('.ns-item');

                items.forEach((item, index) => {
                    const label = item.querySelector('label');
                    const labelTextEl = item.querySelector('.ns-label-text');
                    const badge = item.querySelector('.badge-placeholder');
                    const input = item.querySelector('input');
                    const removeButton = item.querySelector('.remove-ns');
                    const glueWrap = item.querySelector('.glue-ip-wrap');
                    const glueInput = item.querySelector('.glue-ip-input') || glueWrap?.querySelector('input');
                    const isFixed = index < baseCount;

                    item.dataset.fixed = isFixed ? 'true' : 'false';

                    if (label) {
                        label.setAttribute('for', `nameserver_${index}`);
                    }

                    if (labelTextEl) {
                        labelTextEl.textContent = `${labelText} ${index + 1}`;
                    }

                    if (badge) {
                        badge.textContent = requiredBadge;
                        badge.classList.toggle('hidden', !isFixed);
                    }

                    if (input) {
                        input.id = `nameserver_${index}`;
                        input.name = `nameservers[${index}]`;
                        input.placeholder = `ns${index + 1}.example.com`;
                    }

                    if (glueInput) {
                        glueInput.id = `nameserver_ip_${index}`;
                        glueInput.name = `nameserver_ips[${index}]`;
                    }

                    if (removeButton) {
                        removeButton.dataset.fixed = isFixed ? 'true' : 'false';
                        removeButton.classList.toggle('opacity-0', isFixed);
                        removeButton.classList.toggle('pointer-events-none', isFixed);
                    }

                    syncGlueToggle(item);
                });

                counterEl.textContent = `${items.length}/${maxCount}`;
            };

            const validateAll = () => {
                let valid = true;
                const items = fieldsContainer.querySelectorAll('.ns-item');

                if (items.length < minCount) {
                    showError(minMessage);
                    valid = false;
                } else if (items.length > maxCount) {
                    showError(maxMessage);
                    valid = false;
                } else {
                    showError('');
                }

                items.forEach((item) => {
                    const input = item.querySelector('input');
                    const glueInput = item.querySelector('.glue-ip-input') || item.querySelector('.glue-ip-wrap input');
                    const inputValid = input.value.trim() === '' ? true : hostRegex.test(input.value.trim());

                    input.setAttribute('aria-invalid', inputValid ? 'false' : 'true');
                    input.classList.toggle('border-danger-500', !inputValid);

                    if (!inputValid) {
                        valid = false;
                    }

                    if (glueInput && glueInput.value.trim() !== '') {
                        const glueValid = ipRegex.test(glueInput.value.trim());
                        glueInput.setAttribute('aria-invalid', glueValid ? 'false' : 'true');
                        glueInput.classList.toggle('border-danger-500', !glueValid);

                        if (!glueValid) {
                            valid = false;
                            if (!errorsBox.textContent) {
                                showError(glueMessage);
                            }
                        }
                    } else if (glueInput) {
                        glueInput.setAttribute('aria-invalid', 'false');
                        glueInput.classList.remove('border-danger-500');
                    }
                });

                return valid;
            };

            const bindRemoveAction = (button) => {
                button.addEventListener('click', (event) => {
                    if (event.currentTarget.dataset.fixed === 'true') {
                        return;
                    }

                    event.currentTarget.closest('.ns-item')?.remove();
                    updateLabels();
                    validateAll();
                });
            };

            const bindGlueToggle = (button) => {
                button.addEventListener('click', (event) => {
                    const item = event.currentTarget.closest('.ns-item');
                    const glueWrap = item?.querySelector('.glue-ip-wrap');

                    if (!item || !glueWrap) {
                        return;
                    }

                    glueWrap.classList.toggle('hidden');
                    syncGlueToggle(item);
                });
            };

            const addField = (value = '') => {
                const count = fieldsContainer.querySelectorAll('.ns-item').length;

                if (count >= maxCount) {
                    showError(maxMessage);
                    return;
                }

                const node = template.content.firstElementChild.cloneNode(true);
                const input = node.querySelector('input');
                const removeButton = node.querySelector('.remove-ns');
                const glueInput = node.querySelector('.glue-ip-input');
                const toggleButton = node.querySelector('.toggle-glue');

                input.value = value;
                if (glueInput) {
                    glueInput.value = '';
                }
                bindRemoveAction(removeButton);
                if (toggleButton) {
                    bindGlueToggle(toggleButton);
                }
                fieldsContainer.appendChild(node);

                updateLabels();
                validateAll();
                input.focus();
            };

            fieldsContainer.querySelectorAll('.remove-ns').forEach(bindRemoveAction);
            fieldsContainer.querySelectorAll('.toggle-glue').forEach(bindGlueToggle);

            addButton?.addEventListener('click', () => addField(''));

            fieldsContainer.addEventListener('input', (event) => {
                if (event.target.matches('input[type="text"]')) {
                    updateLabels();
                    validateAll();
                }
            });

            fieldsContainer.closest('form')?.addEventListener('submit', (event) => {
                if (!validateAll()) {
                    event.preventDefault();
                    showError(fixMessage);
                    fieldsContainer.querySelector('[aria-invalid="true"]')?.focus();
                }
            });

            updateLabels();
            validateAll();
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $attributes = $__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__attributesOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $component = $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\client\domains\dns.blade.php ENDPATH**/ ?>