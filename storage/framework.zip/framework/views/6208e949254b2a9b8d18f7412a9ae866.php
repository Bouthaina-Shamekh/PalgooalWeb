<?php
    $wrapperClass = $wrapperClass ?? 'flex items-center gap-2 group';
    $imageClass = $imageClass ?? 'h-10 w-auto transition-transform group-hover:scale-105 will-change-transform';
    $logoSrc = $settings?->logo
        ? asset('storage/' . $settings->logo)
        : asset('assets/tamplate/images/logo.svg');
    $logoAlt = $settings?->resolved_site_title ?: config('app.name', 'Palgoals');
?>

<a href="<?php echo e(url('/')); ?>" class="<?php echo e($wrapperClass); ?>">
    <img
        src="<?php echo e($logoSrc); ?>"
        alt="<?php echo e($logoAlt); ?>"
        loading="eager"
        fetchpriority="high"
        class="<?php echo e($imageClass); ?>"
    />
</a>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\front\layouts\partials\header-brand.blade.php ENDPATH**/ ?>