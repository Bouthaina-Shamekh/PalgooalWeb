<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto px-4 py-8">
        <div class="mb-6">
            <a href="<?php echo e(route('dashboard.orders.index')); ?>" class="text-blue-600 hover:underline">&larr; الرجوع لقائمة
                الطلبات</a>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">تفاصيل الطلب</h2>
            <div class="mb-4">
                <span class="font-semibold text-gray-600">رقم الطلب:</span> <span
                    class="font-mono"><?php echo e($order->order_number); ?></span>
            </div>
            <div class="mb-4">
                <span class="font-semibold text-gray-600">الحالة:</span> <span><?php echo e(__($order->status)); ?></span>
            </div>
            <div class="mb-4">
                <span class="font-semibold text-gray-600">العميل:</span> <?php echo e($order->client->first_name ?? '-'); ?>

            </div>
            <div class="mb-4">
                <span class="font-semibold text-gray-600">تاريخ الإنشاء:</span>
                <?php echo e($order->created_at->format('Y-m-d H:i')); ?>

            </div>
            <!-- الفواتير المرتبطة -->
            <div class="mt-8">
                <h3 class="text-lg font-bold mb-3 text-gray-700">الفواتير المرتبطة</h3>
                <?php if($order->invoices && $order->invoices->count()): ?>
                    <?php $__currentLoopData = $order->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-6 border rounded p-4 bg-gray-50">
                            <div class="mb-2">
                                <span class="font-semibold text-gray-600">رقم الفاتورة:</span> <span
                                    class="font-mono"><?php echo e($invoice->number); ?></span>
                            </div>
                            <div class="mb-2">
                                <span class="font-semibold text-gray-600">الحالة:</span>
                                <span><?php echo e(__($invoice->status)); ?></span>
                            </div>
                            <div class="mb-2">
                                <span class="font-semibold text-gray-600">الإجمالي:</span>
                                $<?php echo e(number_format($invoice->total_cents / 100, 2)); ?> <?php echo e($invoice->currency); ?>

                            </div>
                            <div class="mb-2">
                                <span class="font-semibold text-gray-600">تاريخ الاستحقاق:</span>
                                <?php echo e($invoice->due_date ? $invoice->due_date->format('Y-m-d') : '-'); ?>

                            </div>
                            <!-- جدول بنود الفاتورة -->
                            <div class="mt-4">
                                <h4 class="font-bold text-gray-700 mb-2">بنود الفاتورة:</h4>
                                <?php if($invoice->items && $invoice->items->count()): ?>
                                    <table class="min-w-full divide-y divide-gray-200 mb-2">
                                        <thead class="bg-gray-50">
                                            <tr>
                                                <th class="px-2 py-1 text-right text-xs font-bold text-gray-600">الوصف
                                                </th>
                                                <th class="px-2 py-1 text-right text-xs font-bold text-gray-600">الكمية
                                                </th>
                                                <th class="px-2 py-1 text-right text-xs font-bold text-gray-600">سعر
                                                    الوحدة
                                                </th>
                                                <th class="px-2 py-1 text-right text-xs font-bold text-gray-600">
                                                    الإجمالي
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody class="bg-white divide-y divide-gray-100">
                                            <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="px-2 py-1"><?php echo e($item->description); ?></td>
                                                    <td class="px-2 py-1"><?php echo e($item->qty); ?></td>
                                                    <td class="px-2 py-1">
                                                        $<?php echo e(number_format($item->unit_price_cents / 100, 2)); ?></td>
                                                    <td class="px-2 py-1">
                                                        $<?php echo e(number_format($item->total_cents / 100, 2)); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="text-gray-400">لا توجد بنود لهذه الفاتورة.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="text-gray-400">لا توجد فواتير مرتبطة بهذا الطلب.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\orders\invoices.blade.php ENDPATH**/ ?>