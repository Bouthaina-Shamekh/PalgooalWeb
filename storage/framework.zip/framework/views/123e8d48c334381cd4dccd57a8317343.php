<?php
    $plansArray = [];
    foreach ($plans as $plan) {
        $plansArray[$plan->id] = $plan->price_cents;
    }
    $clientsArray = [];
    foreach ($clients as $c) {
        $clientsArray[$c->id] = [
            'email' => $c->email ?? '',
            'first_name' => $c->first_name ?? '',
            'last_name' => $c->last_name ?? '',
        ];
    }
?>
<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.subscriptions.index')); ?>">الاشتراكات</a></li>
                <li class="breadcrumb-item" aria-current="page">إضافة اشتراك</li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0">إضافة اشتراك جديد</h2>
            </div>
        </div>
    </div>
    <!-- [ breadcrumb ] end -->
    <!-- [ Main Content ] start -->
    <div class="grid grid-cols-12 gap-x-6">
        <div class="col-span-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">المعلومات الأساسية</h5>
                </div>
                <div class="card-body">
                    <?php if(session('ok')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('ok')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('dashboard.subscriptions.store')); ?>" method="POST"
                        class="grid grid-cols-12 gap-x-6">
                        <?php echo csrf_field(); ?>

                        <div class="col-span-12 md:col-span-6">
                            <div class="mb-3">
                                <label class="form-label">العميل</label>
                                <select name="client_id" class="form-select" required>
                                    <option value="">-- اختر عميل --</option>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($client->id); ?>"
                                            <?php echo e(old('client_id') == $client->id ? 'selected' : ''); ?>>
                                            <?php echo e($client->first_name); ?> <?php echo e($client->last_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['client_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-span-12 md:col-span-6">
                            <div class="mb-3">
                                <label class="form-label">الخطة</label>
                                <select name="plan_id" class="form-select" required>
                                    <option value="">-- اختر خطة --</option>
                                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($plan->id); ?>"
                                            <?php echo e(old('plan_id') == $plan->id ? 'selected' : ''); ?>><?php echo e($plan->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['plan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-span-12 md:col-span-6">
                            <div class="mb-3">
                                <label class="form-label">السعر ($)</label>
                                <input type="number" name="price" class="form-control" min="0" step="0.01"
                                    required value="<?php echo e(old('price')); ?>">
                                <small class="text-muted">أدخل السعر بالدولار (مثال: 15.00)</small>
                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-span-12 md:col-span-6">
                            <div class="mb-3">
                                <label class="form-label">السيرفر</label>
                                <select name="server_id" class="form-select" required>
                                    <option value="">-- اختر سيرفر --</option>
                                    <?php $__currentLoopData = $servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($server->id); ?>"
                                            <?php echo e(old('server_id') == $server->id ? 'selected' : ''); ?>>
                                            <?php echo e($server->name); ?>

                                            (<?php echo e($server->ip ?? $server->hostname); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['server_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-span-12 md:col-span-6">
                            <div class="mb-3">
                                <label class="form-label">اسم المستخدم (Username)</label>
                                <div class="flex items-center gap-2">
                                    <input type="text" name="username" class="form-control"
                                        value="<?php echo e(old('username')); ?>">
                                    <button type="button" id="suggestUsernameBtn"
                                        class="btn btn-outline-secondary">اقتراح</button>
                                </div>
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-span-12 md:col-span-6">
                            <div class="mb-3">
                                <label class="form-label">نوع الدومين</label>
                                <select name="domain_option" class="form-select" required>
                                    <option value="new" <?php echo e(old('domain_option') == 'new' ? 'selected' : ''); ?>>تسجيل
                                        دومين جديد</option>
                                    <option value="subdomain"
                                        <?php echo e(old('domain_option') == 'subdomain' ? 'selected' : ''); ?>>
                                        استخدام سب-دومين</option>
                                    <option value="existing"
                                        <?php echo e(old('domain_option') == 'existing' ? 'selected' : ''); ?>>
                                        دومين خاص بالعميل</option>
                                </select>
                                <?php $__errorArgs = ['domain_option'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-span-12 md:col-span-6">
                            <div class="mb-3">
                                <label class="form-label">اسم الدومين</label>
                                <input type="text" name="domain_name" class="form-control"
                                    value="<?php echo e(old('domain_name')); ?>"
                                    placeholder="مثال: example.com أو client.palgoals.com">
                                <?php $__errorArgs = ['domain_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-span-12 md:col-span-6">
                            <div class="mb-3">
                                <label class="form-label">تاريخ البداية</label>
                                <input type="date" name="starts_at" class="form-control" required
                                    value="<?php echo e(old('starts_at')); ?>">
                                <?php $__errorArgs = ['starts_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-span-12 md:col-span-6">
                            <div class="mb-3">
                                <label class="form-label">تاريخ الاستحقاق القادم</label>
                                <input type="date" name="next_due_date" class="form-control"
                                    value="<?php echo e(old('next_due_date')); ?>">
                                <?php $__errorArgs = ['next_due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-span-12 md:col-span-6">
                            <div class="mb-3">
                                <label class="form-label">تاريخ النهاية</label>
                                <input type="date" name="ends_at" class="form-control"
                                    value="<?php echo e(old('ends_at')); ?>">
                                <?php $__errorArgs = ['ends_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-span-12 md:col-span-6">
                            <div class="mb-3">
                                <label class="form-label">الحالة</label>
                                <select name="status" class="form-select" required>
                                    <option value="pending" <?php echo e(old('status') == 'pending' ? 'selected' : ''); ?>>معلق
                                    </option>
                                    <option value="active" <?php echo e(old('status') == 'active' ? 'selected' : ''); ?>>نشط
                                    </option>
                                    <option value="suspended" <?php echo e(old('status') == 'suspended' ? 'selected' : ''); ?>>
                                        موقوف
                                    </option>
                                    <option value="cancelled" <?php echo e(old('status') == 'cancelled' ? 'selected' : ''); ?>>
                                        ملغي
                                    </option>
                                    <option value="expired" <?php echo e(old('status') == 'expired' ? 'selected' : ''); ?>>منتهي
                                    </option>
                                </select>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-span-12 text-right mt-4">
                            <button type="submit" class="btn btn-primary">حفظ</button>
                            <a href="<?php echo e(route('dashboard.subscriptions.index')); ?>" class="btn btn-light">إلغاء</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- [ Main Content ] end -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php
    $plansArray = [];
    foreach ($plans as $plan) {
        $plansArray[$plan->id] = $plan->price ?? 0;
    }
?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const planSelect = document.querySelector('select[name="plan_id"]');
        const priceInput = document.querySelector('input[name="price"]');
        const plans = <?php echo json_encode($plansArray, 15, 512) ?>;
        if (planSelect && priceInput) {
            planSelect.addEventListener('change', function() {
                const selected = this.value;
                if (plans[selected]) {
                    priceInput.value = plans[selected];
                }
            });
        }
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const btn = document.getElementById('suggestUsernameBtn');
        const usernameInput = document.querySelector('input[name="username"]');
        const domainField = document.querySelector('input[name="domain_name"]');
        const clientSelect = document.querySelector('select[name="client_id"]');

        btn?.addEventListener('click', function() {
            const payload = {
                domain_name: domainField?.value || null,
                client_id: clientSelect?.value || null,
                preferred_username: usernameInput?.value || null,
                _token: '<?php echo e(csrf_token()); ?>'
            };
            btn.disabled = true;
            fetch('<?php echo e(route('dashboard.subscriptions.username-suggest')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify(payload)
            }).then(r => r.json()).then(data => {
                if (data && data.username) {
                    usernameInput.value = data.username;
                }
            }).catch(err => console.error(err)).finally(() => btn.disabled = false);
        });
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const clientSelect = document.querySelector('select[name="client_id"]');
        const usernameInput = document.querySelector('input[name="username"]');
        const clients = <?php echo json_encode($clientsArray, 15, 512) ?>;

        function sanitizeBase(s) {
            if (!s) return '';
            return String(s).toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 12);
        }

        clientSelect?.addEventListener('change', function() {
            const id = this.value;
            if (!id) return;
            if (!usernameInput) return;
            // لا نُعدّل إذا أدخل المستخدم قيمة يدوياً
            if (usernameInput.value && String(usernameInput.value).trim() !== '') return;
            // إن كان هناك دومين تم إدخاله في الحقل، استخدمه كأساس
            const domainField = document.querySelector('input[name="domain_name"]');
            if (domainField && domainField.value && domainField.value.trim() !== '') {
                const base = sanitizeBase(domainField.value.replace(/\./g, '')) || ('user');
                usernameInput.value = base;
                return;
            }
            const c = clients[id] || {};
            let base = '';
            if (c.email && c.email.indexOf('@') !== -1) {
                base = c.email.split('@')[0];
            } else {
                base = (c.first_name || '') + (c.last_name || '');
            }
            base = sanitizeBase(base) || ('user');
            usernameInput.value = base + id;
        });
    });
</script>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\management\subscriptions\create.blade.php ENDPATH**/ ?>