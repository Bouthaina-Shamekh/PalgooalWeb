<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name' => 'User',
    'size' => 48,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name' => 'User',
    'size' => 48,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $displayName = trim($name ?? '');
    $segments = preg_split('/\s+/u', $displayName, -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $initials = collect($segments)->map(fn ($segment) => mb_strtoupper(mb_substr($segment, 0, 1)))->take(2)->implode('');
    if ($initials === '') {
        $initials = 'U';
    }

    $hash = md5($displayName !== '' ? $displayName : 'user');
    $background = substr($hash, 0, 6);
    $textColor = 'FFFFFF';
    $fontSize = 42;

    $svg = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100">
    <rect width="100" height="100" rx="50" fill="#$background"></rect>
    <text x="50" y="58" font-size="$fontSize" fill="#$textColor" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-weight="600">$initials</text>
</svg>
SVG;

    $avatar = 'data:image/svg+xml;base64,' . base64_encode($svg);
?>

<img src="<?php echo e($avatar); ?>"
    alt="<?php echo e($displayName !== '' ? $displayName : __('User avatar')); ?>"
    width="<?php echo e((int) $size); ?>"
    height="<?php echo e((int) $size); ?>"
    <?php echo e($attributes->merge(['class' => 'rounded-full object-cover'])); ?> />
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\components\dashboard\avatar.blade.php ENDPATH**/ ?>