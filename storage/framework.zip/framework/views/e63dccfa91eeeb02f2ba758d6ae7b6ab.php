<div class="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg mb-8 border border-gray-200 dark:border-gray-700 space-y-6">
    <?php if(session()->has('success')): ?>
        <div class="flex items-center gap-3 bg-green-100 text-green-900 border border-green-300 dark:bg-green-800/20 dark:text-green-100 dark:border-green-600 px-4 py-3 rounded-lg shadow transition-all duration-300" role="alert">
            <svg class="w-5 h-5 text-green-600 dark:text-green-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
            </svg>
            <span class="text-sm font-medium"><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <div class="flex justify-between items-center">
        <h3 class="text-xl font-semibold text-gray-800 dark:text-white"><?php echo e(ucfirst(str_replace('-', ' ', $section->key))); ?></h3>
        <button onclick="confirmDeleteSection(<?php echo e($section->id); ?>)" class="text-red-600 hover:underline text-sm">
            <?php echo e(t('section.Delete', 'Delete')); ?>

        </button>
    </div>

    <div class="col-span-12 md:col-span-2 mb-4">
        <label class="form-label"><?php echo e(t('section.Section_Arrangement', 'Section Arrangement')); ?></label>
        <input type="number" wire:model.defer="order" class="form-control" placeholder="<?php echo e(t('section.Example:', 'Example: 1, 2, 3')); ?>" />
    </div>

    
    <div class="flex flex-wrap gap-2 mt-4">
        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button wire:click="setActiveLang('<?php echo e($lang->code); ?>')"
                class="px-4 py-2 text-sm font-medium rounded-lg transition <?php echo e($activeLang === $lang->code ? 'bg-primary text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-primary hover:text-white'); ?>">
                <?php echo e($lang->native); ?>

            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-6 flex flex-wrap items-center gap-3 border-b border-gray-200 dark:border-gray-700 pb-3">
        <button type="button" wire:click="setActiveTab('content')"
            class="px-3 py-1.5 text-sm font-semibold rounded-md transition <?php echo e($activeTab === 'content' ? 'bg-primary text-white shadow' : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-primary/80 hover:text-white'); ?>">
            <?php echo e(t('section.Content_Tab', 'Content')); ?>

        </button>
        <button type="button" wire:click="setActiveTab('style')"
            class="px-3 py-1.5 text-sm font-semibold rounded-md transition <?php echo e($activeTab === 'style' ? 'bg-primary text-white shadow' : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-primary/80 hover:text-white'); ?>">
            <?php echo e(t('section.Style_Tab', 'Style')); ?>

        </button>
    </div>

    <?php if($activeTab === 'content'): ?>
        <div wire:key="features-2-content-<?php echo e($activeLang); ?>" class="grid grid-cols-12 gap-6">
            <div class="col-span-12 md:col-span-6 mb-4">
                <label class="form-label"><?php echo e(t('section.Title', 'Title')); ?></label>
                <input type="text" wire:model.defer="translationsData.<?php echo e($activeLang); ?>.title" class="form-control" placeholder="<?php echo e(t('section.Title', 'Title')); ?>" />
            </div>

            <div class="col-span-12 md:col-span-6 mb-4">
                <label class="form-label"><?php echo e(t('section.Brief_description', 'Brief description')); ?></label>
                <input type="text" wire:model.defer="translationsData.<?php echo e($activeLang); ?>.subtitle" class="form-control" placeholder="<?php echo e(t('section.Brief_description', 'Brief description')); ?>" />
            </div>

            <div class="col-span-12 md:col-span-6 mb-4">
                <label class="form-label"><?php echo e(t('section.Button_Text', 'Button Text')); ?></label>
                <input type="text" wire:model.defer="translationsData.<?php echo e($activeLang); ?>.button_text" class="form-control" placeholder="<?php echo e(t('section.Button_Text', 'Button Text')); ?>" />
            </div>

            <div class="col-span-12 md:col-span-6 mb-4">
                <label class="form-label"><?php echo e(t('section.Button_URL', 'Button URL')); ?></label>
                <input type="text" wire:model.defer="translationsData.<?php echo e($activeLang); ?>.button_url" class="form-control" placeholder="https://example.com" />
            </div>

            <div class="col-span-12 space-y-4">
                <?php $__currentLoopData = $translationsData[$activeLang]['features'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-start border border-dashed border-gray-300 dark:border-gray-700 p-4 rounded-xl relative bg-gray-50 dark:bg-gray-900/60">
                        <div class="md:col-span-1">
                            <label class="form-label"><?php echo e(t('section.Icon_html', 'Icon (SVG/HTML)')); ?></label>
                            <textarea wire:model.defer="translationsData.<?php echo e($activeLang); ?>.features.<?php echo e($index); ?>.icon"
                                class="form-textarea w-full h-28 rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800"
                                placeholder="<svg>...</svg>"></textarea>
                        </div>

                        <div>
                            <label class="form-label"><?php echo e(t('section.Feature_Title', 'Feature Title')); ?></label>
                            <input type="text" wire:model.defer="translationsData.<?php echo e($activeLang); ?>.features.<?php echo e($index); ?>.title"
                                class="form-control" placeholder="<?php echo e(t('section.Feature_Title', 'Feature Title')); ?>" />
                        </div>

                        <div>
                            <label class="form-label"><?php echo e(t('section.Feature_Description', 'Feature Description')); ?></label>
                            <textarea wire:model.defer="translationsData.<?php echo e($activeLang); ?>.features.<?php echo e($index); ?>.description"
                                class="form-textarea w-full h-24 rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800"
                                placeholder="<?php echo e(t('section.Feature_Description', 'Feature Description')); ?>"></textarea>
                        </div>

                        <button type="button" wire:click="removeFeature('<?php echo e($activeLang); ?>', <?php echo e($index); ?>)"
                            class="absolute -top-2 -left-2 bg-red-500 text-white text-sm rounded-full w-7 h-7 flex items-center justify-center hover:bg-red-600 transition">
                            &times;
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="text-end">
                    <button type="button" wire:click="addFeature('<?php echo e($activeLang); ?>')" class="btn btn-primary">
                        <?php echo e(t('section.Add_Feature', '+Add Feature')); ?>

                    </button>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div wire:key="features-2-style-<?php echo e($activeLang); ?>" class="grid grid-cols-12 gap-6">
            <?php
                $selectedVariant = $translationsData[$activeLang]['background_variant'] ?? 'white';
                $selectedPreset = $backgroundPresets[$selectedVariant] ?? $backgroundPresets['white'];
            ?>

            <div class="col-span-12 lg:col-span-6 space-y-4">
                <label class="form-label"><?php echo e(t('section.Background_Color', 'Background Style')); ?></label>

                <div class="rounded-xl border border-gray-200 dark:border-gray-700 p-4 flex flex-col gap-4">
                    <div class="flex flex-wrap items-center justify-between gap-4">
                        <div class="flex items-center gap-3">
                            <span class="h-12 w-12 rounded-full border border-black/10 dark:border-white/10 <?php echo e($selectedPreset['classes'] ?? ''); ?>"
                                title="<?php echo e(strtoupper($selectedPreset['preview'] ?? '#FFFFFF')); ?>">
                            </span>
                            <div class="flex flex-col gap-1">
                                <div class="text-sm font-semibold text-gray-800 dark:text-gray-200 flex items-center gap-2">
                                    <?php echo e(t('section.palette.' . $selectedVariant, $selectedPreset['label'] ?? 'White')); ?>

                                    <span class="text-xs font-normal text-gray-500 dark:text-gray-400">
                                        <?php echo e(strtoupper($selectedPreset['preview'] ?? '#FFFFFF')); ?>

                                    </span>
                                </div>
                                <div class="text-xs text-gray-500 dark:text-gray-400">
                                    <?php echo e(t('section.Selected_Background', 'Selected background')); ?>

                                </div>
                            </div>
                        </div>
                        <button type="button"
                            wire:click="resetBackgroundVariant('<?php echo e($activeLang); ?>')"
                            wire:loading.attr="disabled"
                            <?php if($selectedVariant === 'white'): ?> disabled <?php endif; ?>
                            class="px-3 py-1.5 text-xs font-medium rounded-md border border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition disabled:opacity-50 disabled:cursor-not-allowed">
                            <?php echo e(t('section.Reset_to_default', 'Reset')); ?>

                        </button>
                    </div>
                    <div class="text-xs text-gray-500 dark:text-gray-400">
                        <?php echo e(t('section.Background_Color_Hint', 'Choose a color from the palette or reset to the default white background.')); ?>

                    </div>
                </div>

                <div class="space-y-3">
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-200">
                        <?php echo e(t('section.Select_Background_Variant', 'Choose a background variant')); ?>

                    </label>
                    <select
                        wire:model.live="translationsData.<?php echo e($activeLang); ?>.background_variant"
                        class="form-select w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-sm text-gray-800 dark:text-gray-100 focus:ring focus:ring-primary/30 focus:border-primary"
                    >
                        <?php $__currentLoopData = $backgroundGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupLabel => $keys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <optgroup label="<?php echo e(t('section.palette.' . \Illuminate\Support\Str::slug($groupLabel), $groupLabel)); ?>">
                                <?php $__currentLoopData = $keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presetKey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $preset = $backgroundPresets[$presetKey] ?? null;
                                    ?>
                                    <?php if(!$preset) continue; ?>
                                    <option value="<?php echo e($presetKey); ?>">
                                        <?php echo e(t('section.palette.' . $presetKey, $preset['label'])); ?>

                                        (<?php echo e(strtoupper($preset['preview'] ?? '')); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <p class="text-xs text-gray-500 dark:text-gray-400">
                    <?php echo e(t('section.Background_Color_Help', 'Pick a preset from the list above or reset to the default white background.')); ?>

                </p>
            </div>

            <div class="col-span-12 lg:col-span-6">
                <?php
                    $previewClasses = $selectedPreset['classes'] ?? $backgroundPresets['white']['classes'];
                ?>
                <label class="form-label"><?php echo e(t('section.Live_Preview', 'Live preview')); ?></label>
                <div class="rounded-xl border border-dashed border-gray-300 dark:border-gray-700 p-6 <?php echo e($previewClasses); ?>">
                    <p class="text-sm <?php echo e(str_contains($previewClasses, 'text-white') ? 'text-white/80' : 'text-gray-700 dark:text-gray-200'); ?>">
                        <?php echo e(t('section.Style_Preview_Message', 'Preview how the section background will look.')); ?>

                    </p>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="text-end">
        <button wire:click="updateFeatures2Section" class="btn btn-primary">
            <?php echo e(t('section.Save_changes', 'Save changes')); ?>

        </button>
    </div>
</div>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\livewire\admin\sections\features-2.blade.php ENDPATH**/ ?>