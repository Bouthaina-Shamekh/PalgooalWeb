<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb = $attributes; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>"><?php echo e(t('dashboard.Home', 'Home')); ?></a>
                </li>
                <li class="breadcrumb-item"><a
                        href="<?php echo e(route('dashboard.services.index')); ?>"><?php echo e(t('dashboard.services', 'Services')); ?></a>
                </li>
            </ul>
            <div class="page-header-title">
                <h2 class="mb-0"><?php echo e(t('dashboard.All_Services', 'ALL Services')); ?></h2>
            </div>
        </div>
    </div>
    <!-- [ breadcrumb ] end -->

    <div class="container mx-auto py-6">
        <h1 class="text-2xl font-bold mb-4">إدارة الخدمات</h1>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', 'App\\Models\\Service')): ?>
            <a href="<?php echo e(route('dashboard.services.create')); ?>" class="btn btn-primary mb-4">➕ إضافة خدمة جديدة</a>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 p-4 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="table-responsive dt-responsive">
            <table class="table table-striped table-bordered nowrap">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>الأيقونة</th>
                        <th>العنوان (<?php echo e(app()->getLocale()); ?>)</th>
                        <th>الترتيب</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <img src="<?php echo e(asset('storage/' . $service->icon)); ?>" class="w-10 h-10">
                            </td>
                            <td>
                                <?php echo e($service->translation()?->title); ?>

                            </td>
                            <td><?php echo e($service->order); ?></td>
                            <td style="display: flex; gap: 5px;">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', 'App\\Models\\Service')): ?>
                                    <a href="<?php echo e(route('dashboard.services.edit', $service->id)); ?>"
                                        class="btn btn-sm btn-warning">تعديل</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', 'App\\Models\\Service')): ?>
                                    <form action="<?php echo e(route('dashboard.services.destroy', $service->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">حذف</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            <?php echo e($services->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $attributes = $__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__attributesOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\dashboard\services\index.blade.php ENDPATH**/ ?>