<section class="bg-blue-100 py-16 text-center">
    <div class="container mx-auto">
        <h1 class="text-4xl font-bold mb-4"><?php echo e($data['title'] ?? 'عنوان الترحيب'); ?></h1>
        <p class="text-lg text-gray-700"><?php echo e($data['subtitle'] ?? 'نص ترحيبي مختصر'); ?></p>
    </div>
</section>
<?php /**PATH C:\Users\lenovo\Desktop\aa\PalgooalWeb\resources\views\front\sections\hero.blade.php ENDPATH**/ ?>